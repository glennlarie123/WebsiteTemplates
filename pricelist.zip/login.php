<?php
require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $username = isset($_POST['username'])
        ? trim($_POST['username'])
        : '';

    $password = isset($_POST['password'])
        ? (string)$_POST['password']
        : '';

    $config = app_config();
    $user = null;

    foreach ($config['users'] as $u) {
        if (($u['username'] ?? '') === $username) {
            $user = $u;
            break;
        }
    }

    if (
        $user &&
        !empty($user['is_active']) &&
        password_verify(
            $password,
            $user['password_hash'] ?? ''
        )
    ) {

        session_regenerate_id(true);

        $_SESSION['user_logged_in'] = true;
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        header('Location: db_select');
        exit;
    }

    $error_message = 'Invalid system credentials. Access denied.';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <link rel="icon" type="image" href="img/dhlogo.png">
    

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1, shrink-to-fit=no"
    >

    <title>DIONS HARDWARE Login</title>

<link rel="icon" type="image" href="img/dhlogo.png">

    <!-- Bootstrap -->
    <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        crossorigin="anonymous"
    >

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        crossorigin="anonymous"
    >

    <link
        rel="stylesheet"
        href="assets/bootstrap-theme.css"
    >

    <style>

        /* =========================================================
           DIONS HARDWARE LOGIN PAGE
        ========================================================= */

        :root {
            --primary: #fbbf24;
            --primary-dark: #d97706;

            --bg-dark: #020617;
            --bg-mid: #0f172a;

            --card: rgba(15, 23, 42, 0.88);

            --border: rgba(148, 163, 184, 0.18);

            --text: #f8fafc;
            --muted: #94a3b8;
        }


        /* =========================================================
           BASE
        ========================================================= */

        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        html,
        body {
            width: 100%;
            min-height: 100%;
        }

        body {

            margin: 0;

            min-height: 100vh;

            display: flex;
            align-items: center;
            justify-content: center;

            overflow-x: hidden;

            color: var(--text);

            background:
                radial-gradient(
                    circle at 15% 20%,
                    rgba(251, 191, 36, 0.10),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 85% 80%,
                    rgba(59, 130, 246, 0.10),
                    transparent 30%
                ),
                linear-gradient(
                    135deg,
                    #020617 0%,
                    #0f172a 50%,
                    #111827 100%
                );

            font-family:
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Roboto,
                Arial,
                sans-serif;
        }


        /* =========================================================
           ANIMATED BACKGROUND
        ========================================================= */

        .background-icons {

            position: fixed;

            inset: 0;

            overflow: hidden;

            pointer-events: none;

            z-index: 0;
        }

        .floating-icon {

            position: absolute;

            color: rgba(251, 191, 36, 0.08);

            font-size: 42px;

            animation:
                floatIcon 14s infinite ease-in-out;

            filter:
                drop-shadow(
                    0 0 12px rgba(251, 191, 36, 0.05)
                );
        }

        .floating-icon:nth-child(1) {
            left: 7%;
            top: 15%;
            animation-duration: 16s;
        }

        .floating-icon:nth-child(2) {
            left: 18%;
            top: 75%;
            font-size: 30px;
            animation-duration: 12s;
            animation-delay: -4s;
        }

        .floating-icon:nth-child(3) {
            left: 30%;
            top: 25%;
            font-size: 52px;
            animation-duration: 19s;
            animation-delay: -8s;
        }

        .floating-icon:nth-child(4) {
            left: 48%;
            top: 82%;
            font-size: 35px;
            animation-duration: 15s;
            animation-delay: -5s;
        }

        .floating-icon:nth-child(5) {
            left: 63%;
            top: 14%;
            font-size: 48px;
            animation-duration: 18s;
            animation-delay: -7s;
        }

        .floating-icon:nth-child(6) {
            left: 76%;
            top: 65%;
            font-size: 34px;
            animation-duration: 13s;
            animation-delay: -2s;
        }

        .floating-icon:nth-child(7) {
            left: 88%;
            top: 28%;
            font-size: 55px;
            animation-duration: 20s;
            animation-delay: -10s;
        }

        .floating-icon:nth-child(8) {
            left: 93%;
            top: 88%;
            font-size: 28px;
            animation-duration: 11s;
            animation-delay: -3s;
        }

        @keyframes floatIcon {

            0% {
                transform:
                    translate3d(0, 0, 0)
                    rotate(0deg);
            }

            25% {
                transform:
                    translate3d(20px, -30px, 0)
                    rotate(8deg);
            }

            50% {
                transform:
                    translate3d(-15px, -55px, 0)
                    rotate(-8deg);
            }

            75% {
                transform:
                    translate3d(25px, -25px, 0)
                    rotate(5deg);
            }

            100% {
                transform:
                    translate3d(0, 0, 0)
                    rotate(0deg);
            }
        }


        /* =========================================================
           BACKGROUND GLOW
        ========================================================= */

        .background-glow {

            position: fixed;

            width: 420px;
            height: 420px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(251, 191, 36, 0.08),
                    transparent 70%
                );

            filter: blur(15px);

            pointer-events: none;

            z-index: 1;

            animation:
                glowMove 12s infinite alternate ease-in-out;
        }

        @keyframes glowMove {

            0% {
                transform: translate(-180px, -100px);
            }

            100% {
                transform: translate(180px, 120px);
            }
        }


        /* =========================================================
           LOGIN WRAPPER
        ========================================================= */

        .login-wrapper {

            position: relative;

            z-index: 10;

            width: 100%;

            max-width: 430px;

            padding: 20px;

            animation:
                loginAppear .7s ease-out;
        }

        @keyframes loginAppear {

            from {
                opacity: 0;
                transform:
                    translateY(25px)
                    scale(.97);
            }

            to {
                opacity: 1;
                transform:
                    translateY(0)
                    scale(1);
            }
        }


        /* =========================================================
           LOGIN CARD
        ========================================================= */

        .login-card {

            position: relative;

            width: 100%;

            padding: 42px 38px 35px;

            background:
                linear-gradient(
                    145deg,
                    rgba(30, 41, 59, 0.94),
                    rgba(15, 23, 42, 0.94)
                );

            border: 1px solid var(--border);

            border-radius: 20px;

            box-shadow:
                0 35px 80px rgba(0, 0, 0, .45),
                0 0 0 1px rgba(255, 255, 255, .015);

            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);

            overflow: hidden;
        }

        .login-card::before {

            content: "";

            position: absolute;

            left: 0;
            top: 0;

            width: 100%;
            height: 3px;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    var(--primary),
                    transparent
                );
        }


        /* =========================================================
           BRAND
        ========================================================= */

        .brand {

            text-align: center;

            margin-bottom: 32px;
        }

        .brand-icon {

            width: 64px;
            height: 64px;

            margin: 0 auto 17px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 16px;

            color: #111827;

            background:
                linear-gradient(
                    135deg,
                    #fbbf24,
                    #f59e0b
                );

            box-shadow:
                0 10px 30px rgba(245, 158, 11, .25);

            font-size: 26px;

            animation:
                iconPulse 3s infinite ease-in-out;
        }

        @keyframes iconPulse {

            0%,
            100% {
                transform: translateY(0);

                box-shadow:
                    0 10px 30px rgba(245, 158, 11, .20);
            }

            50% {
                transform: translateY(-4px);

                box-shadow:
                    0 15px 35px rgba(245, 158, 11, .35);
            }
        }

        .brand-name {

            margin: 0;

            color: #ffffff;

            font-size: 1.45rem;

            font-weight: 800;

            letter-spacing: .12em;
        }

        .brand-subtitle {

            margin-top: 7px;

            color: var(--muted);

            font-size: .72rem;

            font-weight: 500;

            letter-spacing: .13em;

            text-transform: uppercase;
        }


        /* =========================================================
           LOGIN HEADING
        ========================================================= */

        .login-title {

            margin-bottom: 5px;

            color: #ffffff;

            font-size: 1.15rem;

            font-weight: 700;

            text-align: center;
        }

        .login-description {

            margin-bottom: 27px;

            color: var(--muted);

            font-size: .78rem;

            text-align: center;
        }


        /* =========================================================
           ERROR MESSAGE
        ========================================================= */

        .login-error {

            display: flex;

            align-items: center;

            gap: 10px;

            margin-bottom: 20px;

            padding: 11px 13px;

            color: #fecaca;

            background:
                rgba(127, 29, 29, .22);

            border:
                1px solid rgba(248, 113, 113, .18);

            border-radius: 10px;

            font-size: .78rem;
        }

        .login-error i {
            color: #f87171;
            flex-shrink: 0;
        }


        /* =========================================================
           FORM
        ========================================================= */

        .form-group {
            margin-bottom: 19px;
        }

        .form-label {

            display: block;

            margin-bottom: 7px;

            color: #cbd5e1;

            font-size: .72rem;

            font-weight: 700;

            letter-spacing: .06em;

            text-transform: uppercase;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {

            position: absolute;

            left: 14px;
            top: 50%;

            transform: translateY(-50%);

            color: #64748b;

            font-size: .86rem;

            pointer-events: none;

            transition:
                color .2s ease;

            z-index: 2;
        }

        .login-card .form-control {

            width: 100%;

            height: 48px;

            padding:
                10px 43px;

            color: #f8fafc;

            background:
                rgba(2, 6, 23, .65);

            border:
                1px solid #334155;

            border-radius: 10px;

            font-size: .86rem;

            transition:
                border-color .2s ease,
                box-shadow .2s ease,
                background .2s ease;
        }

        .login-card .form-control::placeholder {
            color: #475569;
        }

        .login-card .form-control:focus {

            color: #ffffff;

            background:
                rgba(2, 6, 23, .85);

            border-color:
                var(--primary);

            outline: none;

            box-shadow:
                0 0 0 3px rgba(251, 191, 36, .10);
        }

        .input-wrapper:focus-within .input-icon {
            color: var(--primary);
        }


        /* =========================================================
           PASSWORD TOGGLE
        ========================================================= */

        .password-toggle {

            position: absolute;

            right: 10px;
            top: 50%;

            width: 32px;
            height: 32px;

            display: flex;
            align-items: center;
            justify-content: center;

            transform: translateY(-50%);

            color: #64748b;

            background: transparent;

            border: 0;

            border-radius: 7px;

            cursor: pointer;

            transition:
                color .2s ease,
                background .2s ease;

            z-index: 3;
        }

        .password-toggle:hover {

            color: var(--primary);

            background:
                rgba(255, 255, 255, .05);
        }

        .password-toggle:focus {
            outline: none;

            box-shadow:
                0 0 0 2px rgba(251, 191, 36, .15);
        }


        /* =========================================================
           LOGIN BUTTON
        ========================================================= */

        .btn-login {

            position: relative;

            width: 100%;

            height: 49px;

            margin-top: 7px;

            display: flex;

            align-items: center;
            justify-content: center;

            gap: 9px;

            color: #111827;

            background:
                linear-gradient(
                    135deg,
                    #fbbf24,
                    #f59e0b
                );

            border: none;

            border-radius: 10px;

            font-size: .82rem;

            font-weight: 800;

            letter-spacing: .08em;

            text-transform: uppercase;

            box-shadow:
                0 8px 20px rgba(245, 158, 11, .18);

            overflow: hidden;

            transition:
                transform .2s ease,
                box-shadow .2s ease,
                filter .2s ease;
        }

        .btn-login::before {

            content: "";

            position: absolute;

            top: 0;
            left: -100%;

            width: 60%;
            height: 100%;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    rgba(255, 255, 255, .3),
                    transparent
                );

            transform: skewX(-20deg);

            transition:
                left .55s ease;
        }

        .btn-login:hover {

            color: #111827;

            transform: translateY(-2px);

            filter: brightness(1.05);

            box-shadow:
                0 12px 28px rgba(245, 158, 11, .28);
        }

        .btn-login:hover::before {
            left: 130%;
        }

        .btn-login:active {
            transform: translateY(0);
        }


        /* =========================================================
           SECURITY FOOTER
        ========================================================= */

        .security-note {

            display: flex;

            align-items: center;
            justify-content: center;

            gap: 6px;

            margin-top: 24px;

            color: #64748b;

            font-size: .68rem;
        }

        .security-note i {
            color: #22c55e;
        }


        /* =========================================================
           COPYRIGHT
        ========================================================= */

        .copyright {

            margin-top: 18px;

            color: #475569;

            font-size: .65rem;

            text-align: center;
        }


        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 575.98px) {

            body {
                padding: 10px;
            }

            .login-wrapper {

                max-width: 390px;

                padding: 10px;
            }

            .login-card {

                padding:
                    32px 23px 27px;

                border-radius: 16px;
            }

            .brand {
                margin-bottom: 25px;
            }

            .brand-icon {

                width: 56px;
                height: 56px;

                margin-bottom: 13px;

                font-size: 22px;

                border-radius: 14px;
            }

            .brand-name {
                font-size: 1.2rem;
            }

            .brand-subtitle {
                font-size: .62rem;
            }

            .login-title {
                font-size: 1.05rem;
            }

            .floating-icon {
                font-size: 30px !important;
            }
        }


        /* =========================================================
           VERY SMALL DEVICES
        ========================================================= */

        @media (max-height: 650px) {

            .login-card {

                padding-top: 25px;
                padding-bottom: 22px;
            }

            .brand {
                margin-bottom: 18px;
            }

            .brand-icon {

                width: 48px;
                height: 48px;

                margin-bottom: 9px;
            }

            .form-group {
                margin-bottom: 13px;
            }

            .security-note {
                margin-top: 15px;
            }

            .copyright {
                margin-top: 10px;
            }
        }


        /* =========================================================
           ACCESSIBILITY
        ========================================================= */

        @media (prefers-reduced-motion: reduce) {

            *,
            *::before,
            *::after {

                animation-duration: .01ms !important;

                animation-iteration-count: 1 !important;

                transition-duration: .01ms !important;
            }
        }

    </style>

</head>


<body>


    <!-- =========================================================
         ANIMATED BACKGROUND
    ========================================================= -->

    <div class="background-icons">

        <i class="floating-icon fas fa-box"></i>

        <i class="floating-icon fas fa-barcode"></i>

        <i class="floating-icon fas fa-warehouse"></i>

        <i class="floating-icon fas fa-cubes"></i>

        <i class="floating-icon fas fa-truck"></i>

        <i class="floating-icon fas fa-chart-line"></i>

        <i class="floating-icon fas fa-shopping-cart"></i>

        <i class="floating-icon fas fa-boxes"></i>

    </div>


    <div class="background-glow"></div>


    <!-- =========================================================
         LOGIN
    ========================================================== -->

    <div class="login-wrapper">

        <div class="login-card">


            <!-- =================================================
                 BRAND
            ================================================== -->

            <div class="brand">

                <div class="">
                                                        <img 
    src="img/dhlogo.png" 
    alt="Dions Hardware Logo"
    style="
        display: block;
        width: auto;
        max-width: 70%;
        height: auto;
        max-height: 90px;
        margin: 0 auto 15px;
        object-fit: contain;
    "
>
                </div>

                <h1 class="brand-name">
                    DIONS HARDWARE
                </h1>

                <div class="brand-subtitle">
                    Inventory &amp; Business Management Portal
                </div>

            </div>


            <!-- =================================================
                 LOGIN HEADING
            ================================================== -->

            <div class="login-title">
                Welcome Back
            </div>

            <div class="login-description">
                Sign in to access your business dashboard
            </div>


            <!-- =================================================
                 ERROR
            ================================================== -->

            <?php if ($error_message): ?>

                <div
                    class="login-error"
                    role="alert"
                >

                    <i class="fas fa-exclamation-circle"></i>

                    <span>
                        <?= htmlspecialchars($error_message) ?>
                    </span>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 LOGIN FORM
            ================================================== -->

            <form
                method="POST"
                autocomplete="on"
            >

                <?= csrf_field() ?>


                <!-- USERNAME -->

                <div class="form-group">

                    <label
                        for="username"
                        class="form-label"
                    >
                        User ID
                    </label>

                    <div class="input-wrapper">

                        <i class="input-icon fas fa-user"></i>

                        <input
                            type="text"
                            id="username"
                            name="username"
                            class="form-control"
                            placeholder="Enter your user ID"
                            autocomplete="username"
                            required
                            autofocus
                        >

                    </div>

                </div>


                <!-- PASSWORD -->

                <div class="form-group">

                    <label
                        for="password"
                        class="form-label"
                    >
                        Password
                    </label>

                    <div class="input-wrapper">

                        <i class="input-icon fas fa-lock"></i>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="form-control"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            id="togglePassword"
                            aria-label="Show password"
                        >
                            <i class="fas fa-eye"></i>
                        </button>

                    </div>

                </div>


                <!-- LOGIN BUTTON -->

                <button
                    type="submit"
                    class="btn btn-login"
                >

                    <i class="fas fa-sign-in-alt"></i>

                    <span>
                        Sign In
                    </span>

                </button>

            </form>


            <!-- =================================================
                 SECURITY
            ================================================== -->

            <div class="security-note">

                <i class="fas fa-shield-alt"></i>

                <span>
                    Secure authenticated access
                </span>

            </div>

        </div>


        <!-- COPYRIGHT -->

        <div class="copyright">

            &copy; <?= date('Y') ?> DIONS HARDWARE

        </div>

    </div>


    <!-- =========================================================
         PASSWORD VISIBILITY
    ========================================================== -->

    <script>

        (function () {

            const toggle =
                document.getElementById('togglePassword');

            const password =
                document.getElementById('password');

            if (!toggle || !password) {
                return;
            }

            toggle.addEventListener('click', function () {

                const isPassword =
                    password.getAttribute('type') === 'password';

                password.setAttribute(
                    'type',
                    isPassword ? 'text' : 'password'
                );

                const icon =
                    toggle.querySelector('i');

                if (icon) {

                    icon.classList.toggle(
                        'fa-eye',
                        !isPassword
                    );

                    icon.classList.toggle(
                        'fa-eye-slash',
                        isPassword
                    );

                }

                toggle.setAttribute(
                    'aria-label',
                    isPassword
                        ? 'Hide password'
                        : 'Show password'
                );

            });

        })();

    </script>

</body>
</html>
