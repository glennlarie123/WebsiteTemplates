<?php
// reports.php — Sales, Spending, Loss, P&L, Top/Low sellers

require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_login();

require_once __DIR__ . '/includes/store_db_mysqli.php';
require_once __DIR__ . '/includes/report_queries_mysqli.php';

$db = require_active_store();
$store = get_active_store();

$view  = $_GET['view'] ?? 'sales';
$start = $_GET['start'] ?? date('Y-m-01');
$end   = $_GET['end'] ?? date('Y-m-t');
$year  = (int)($_GET['year'] ?? date('Y'));
$month = (int)($_GET['month'] ?? date('n'));

$error = '';
$success = '';

/* =========================================================
   RECORD LOSS
   ========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'record_loss'
) {
    verify_csrf();

    if (current_user()['role'] !== 'admin') {

        $error = 'Only admins can record stock losses.';

    } else {

        $product_id = (int)($_POST['product_id'] ?? 0);
        $qty        = (int)($_POST['quantity'] ?? 0);

        $reason = preg_replace(
            '/[^a-zA-Z0-9 _-]/',
            '',
            trim($_POST['reason'] ?? '')
        );

        if ($product_id <= 0 || $qty <= 0 || $reason === '') {

            $error = 'Product, quantity, and reason are all required.';

        } else {

            $ref = 'LOSS-' . date('Ymd') . '-' .
                   strtoupper(bin2hex(random_bytes(2)));

            $db->prepared_query(
                "
                INSERT INTO stock_movements
                (
                    product_id,
                    transaction_type,
                    reference_no,
                    quantity,
                    movement_date,
                    remarks,
                    user_id
                )
                VALUES (?, 'OUT', ?, ?, NOW(), ?, ?)
                ",
                'isisi',
                $product_id,
                $ref,
                $qty,
                'LOSS:' . $reason,
                $_SESSION['user_id']
            );

            $success = "Loss recorded as {$ref}.";
        }
    }
}


/* =========================================================
   FETCH REPORT DATA
   ========================================================= */

$data = [];

switch ($view) {

    case 'sales':
        $data = get_daily_sales($db, $start, $end);
        break;

    case 'monthly':
        $data = get_monthly_sales($db, $year);
        break;

    case 'spending':
        $data = get_spending($db, $start, $end);
        break;

    case 'loss':
        $data = get_losses($db, $start, $end);
        break;

    case 'pl':
        $data = get_pl_snapshot($db, $year);
        break;

    case 'top':
        $data = get_top_sellers($db, $year, $month);
        break;

    case 'low':
        $data = get_low_sellers($db, $year, $month);
        break;
}


/* =========================================================
   PRODUCT LIST
   ========================================================= */

$products = $db->fetch_all(
    "
    SELECT product_id, product_name
    FROM table_product
    WHERE product_name IS NOT NULL
    ORDER BY product_name
    "
);


/* =========================================================
   PAGE
   ========================================================= */

$page_title = 'Reports · INGCO Dealer Portal';
$active_nav = 'reports';

require __DIR__ . '/includes/header_bootstrap.php';
?>

<style>

```css
/* =========================================================
   JINFATS REPORTS
   DARK YELLOW / GOLD BRAND THEME
========================================================= */

:root {
    --jinfats-gold: #c99a00;
    --jinfats-gold-light: #e0b52a;
    --jinfats-gold-dark: #9f7900;

    --jinfats-gold-soft: rgba(201,154,0,.10);
    --jinfats-gold-border: rgba(201,154,0,.22);
    --jinfats-gold-glow: rgba(201,154,0,.12);

    --report-bg: rgba(255,255,255,.025);
    --report-bg-hover: rgba(255,255,255,.045);
    --report-border: rgba(255,255,255,.075);

    --report-text: #e7e5df;
    --report-muted: #8f938f;
    --report-dim: #626866;

    --report-success: #65b985;
    --report-danger: #d87575;
    --report-warning: #d8ad3d;
}


/* =========================================================
   PAGE
========================================================= */

.reports-page {
    padding-bottom: 35px;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.reports-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;

    gap: 22px;
    margin-bottom: 24px;
}


/* =========================================================
   TITLE
========================================================= */

.reports-title-wrapper {
    display: flex;
    align-items: center;
    gap: 14px;
}

.reports-title-icon {
    width: 48px;
    height: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background:
        linear-gradient(
            145deg,
            rgba(201,154,0,.17),
            rgba(201,154,0,.055)
        );

    border: 1px solid rgba(201,154,0,.27);

    color: var(--jinfats-gold-light);

    font-size: 19px;

    box-shadow:
        0 8px 22px rgba(0,0,0,.16),
        inset 0 1px 0 rgba(255,255,255,.035);
}

.reports-title {
    margin: 0;

    color: #f3f1e9;

    font-size: 26px;
    font-weight: 750;

    letter-spacing: -.4px;
}

.reports-subtitle {
    margin: 5px 0 0;

    color: var(--report-muted);

    font-size: 12px;
    line-height: 1.55;
}

.reports-store {
    color: var(--jinfats-gold-light);
    font-weight: 700;
}


/* =========================================================
   REPORT NAVIGATION
========================================================= */

.report-navigation {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;

    gap: 6px;
}

.report-nav-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    gap: 7px;

    min-height: 34px;

    padding: 7px 12px;

    border-radius: 8px !important;

    border-color: rgba(255,255,255,.085) !important;

    background: rgba(255,255,255,.018) !important;

    color: #9da29e !important;

    font-size: 10px;
    font-weight: 700;

    transition:
        background .18s ease,
        border-color .18s ease,
        color .18s ease,
        transform .18s ease,
        box-shadow .18s ease;
}

.report-nav-btn i {
    font-size: 10px;
}

.report-nav-btn:hover {
    transform: translateY(-1px);

    background: rgba(255,255,255,.045) !important;

    border-color: rgba(201,154,0,.25) !important;

    color: #e0d8bd !important;
}

.report-nav-btn.active {
    background:
        linear-gradient(
            135deg,
            rgba(201,154,0,.17),
            rgba(201,154,0,.07)
        ) !important;

    border-color: rgba(201,154,0,.40) !important;

    color: var(--jinfats-gold-light) !important;

    box-shadow:
        0 4px 14px rgba(201,154,0,.07),
        inset 0 1px 0 rgba(255,255,255,.035);
}


/* =========================================================
   ALERTS
========================================================= */

.report-alert {
    display: flex;
    align-items: center;
    gap: 10px;

    margin-bottom: 18px;

    padding: 11px 14px;

    border-radius: 9px;

    font-size: 12px;

    background: rgba(255,255,255,.025);
}

.report-alert .alert-icon {
    font-size: 14px;
}

.report-alert .close {
    margin-left: auto;

    color: inherit;
    opacity: .65;
}


/* =========================================================
   FILTER CARD
========================================================= */

.report-filter-card {
    margin-bottom: 19px;

    overflow: hidden;

    border: 1px solid var(--report-border);
    border-radius: 13px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.035),
            rgba(255,255,255,.018)
        );

    box-shadow:
        0 8px 28px rgba(0,0,0,.12),
        inset 0 1px 0 rgba(255,255,255,.025);
}

.report-filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 14px 18px;

    border-bottom: 1px solid rgba(255,255,255,.055);
}

.report-filter-title {
    display: flex;
    align-items: center;

    gap: 8px;

    margin: 0;

    color: #e2e0d8;

    font-size: 12px;
    font-weight: 750;
}

.report-filter-title i {
    color: var(--jinfats-gold-light);
}

.report-filter-description {
    color: var(--report-dim);

    font-size: 10px;
}

.report-filter-body {
    padding: 16px 18px;
}

.report-filter-form {
    display: flex;
    align-items: flex-end;

    flex-wrap: wrap;

    gap: 12px;
}


/* =========================================================
   FILTER FIELDS
========================================================= */

.report-field {
    min-width: 150px;
}

.report-field label {
    display: block;

    margin-bottom: 6px;

    color: #747a76;

    font-size: 9px;
    font-weight: 750;

    text-transform: uppercase;
    letter-spacing: .65px;
}

.report-field .form-control {
    height: 36px;

    border-radius: 7px;

    border: 1px solid rgba(255,255,255,.08);

    background: rgba(0,0,0,.13);

    color: #dddcd5;

    font-size: 11px;

    transition:
        border-color .18s ease,
        box-shadow .18s ease,
        background .18s ease;
}

.report-field .form-control:hover {
    border-color: rgba(255,255,255,.13);
}

.report-field .form-control:focus {
    border-color: rgba(201,154,0,.55);

    background: rgba(0,0,0,.18);

    color: #f0eee7;

    box-shadow:
        0 0 0 .14rem rgba(201,154,0,.09),
        0 4px 12px rgba(0,0,0,.12);
}


/* =========================================================
   SELECT ARROWS
========================================================= */

.report-field select.form-control {
    cursor: pointer;
}


/* =========================================================
   RUN REPORT BUTTON
========================================================= */

.report-run-btn {
    height: 36px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    gap: 7px;

    padding: 0 15px;

    border: 1px solid rgba(201,154,0,.40) !important;
    border-radius: 7px;

    background:
        linear-gradient(
            135deg,
            #c99a00,
            #aa8200
        ) !important;

    color: #17140a !important;

    font-size: 10px;
    font-weight: 800;

    box-shadow:
        0 5px 14px rgba(201,154,0,.13),
        inset 0 1px 0 rgba(255,255,255,.15);

    transition:
        transform .18s ease,
        box-shadow .18s ease,
        filter .18s ease;
}

.report-run-btn:hover {
    transform: translateY(-1px);

    filter: brightness(1.08);

    box-shadow:
        0 7px 18px rgba(201,154,0,.19),
        inset 0 1px 0 rgba(255,255,255,.18);
}


/* =========================================================
   LOSS CARD
========================================================= */

.loss-card {
    margin-bottom: 19px;

    overflow: hidden;

    border: 1px solid rgba(216,117,117,.16);
    border-radius: 13px;

    background:
        linear-gradient(
            145deg,
            rgba(216,117,117,.035),
            rgba(255,255,255,.018)
        );

    box-shadow:
        0 7px 24px rgba(0,0,0,.10);
}

.loss-header {
    display: flex;
    align-items: center;

    gap: 10px;

    padding: 14px 18px;

    border-bottom: 1px solid rgba(216,117,117,.10);
}

.loss-icon {
    width: 34px;
    height: 34px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background: rgba(216,117,117,.09);

    color: var(--report-danger);

    font-size: 13px;
}

.loss-title {
    margin: 0;

    color: #d98787;

    font-size: 12px;
    font-weight: 750;
}

.loss-description {
    margin: 3px 0 0;

    color: var(--report-dim);

    font-size: 10px;
}

.loss-body {
    padding: 16px 18px;
}

.loss-form {
    display: flex;
    align-items: flex-end;

    flex-wrap: wrap;

    gap: 12px;
}

.loss-field {
    min-width: 170px;
}

.loss-field.quantity-field {
    min-width: 85px;
    width: 85px;
}

.loss-field label {
    display: block;

    margin-bottom: 6px;

    color: #747a76;

    font-size: 9px;
    font-weight: 750;

    text-transform: uppercase;
    letter-spacing: .65px;
}

.loss-field .form-control {
    height: 36px;

    border-radius: 7px;

    border: 1px solid rgba(255,255,255,.08);

    background: rgba(0,0,0,.13);

    color: #dddcd5;

    font-size: 11px;
}

.loss-field .form-control:focus {
    border-color: rgba(216,117,117,.45);

    box-shadow: 0 0 0 .14rem rgba(216,117,117,.07);
}

.loss-submit-btn {
    height: 36px;

    border-radius: 7px;

    border: 1px solid rgba(201,154,0,.35) !important;

    background: rgba(201,154,0,.12) !important;

    color: var(--jinfats-gold-light) !important;

    font-size: 10px;
    font-weight: 750;

    transition: all .18s ease;
}

.loss-submit-btn:hover {
    background: rgba(201,154,0,.20) !important;

    border-color: rgba(201,154,0,.50) !important;

    transform: translateY(-1px);
}


/* =========================================================
   RESULT CARD
========================================================= */

.report-result-card {
    overflow: hidden;

    border: 1px solid var(--report-border);
    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.032),
            rgba(255,255,255,.018)
        );

    box-shadow:
        0 9px 32px rgba(0,0,0,.13),
        inset 0 1px 0 rgba(255,255,255,.025);
}

.report-result-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 15px;

    padding: 16px 20px;

    border-bottom: 1px solid rgba(255,255,255,.065);
}

.report-heading-wrapper {
    display: flex;
    align-items: center;

    gap: 11px;
}

.report-heading-icon {
    width: 35px;
    height: 35px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background:
        linear-gradient(
            145deg,
            rgba(201,154,0,.15),
            rgba(201,154,0,.055)
        );

    border: 1px solid rgba(201,154,0,.13);

    color: var(--jinfats-gold-light);

    font-size: 12px;
}

.report-result-title {
    margin: 0;

    color: #eeece5;

    font-size: 13px;
    font-weight: 750;
}

.report-result-subtitle {
    margin: 3px 0 0;

    color: var(--report-dim);

    font-size: 10px;
}

.report-result-header .badge {
    padding: 5px 8px;

    border-radius: 20px;

    background: rgba(201,154,0,.08);

    border: 1px solid rgba(201,154,0,.14);

    color: var(--jinfats-gold-light);

    font-size: 9px;
    font-weight: 800;
    letter-spacing: .4px;
}

.report-result-body {
    padding: 0;
}


/* =========================================================
   REPORT TABLE
========================================================= */

.report-table {
    width: 100%;

    margin: 0;

    color: var(--report-text);
}

.report-table thead th {
    padding: 12px 20px;

    background:
        linear-gradient(
            180deg,
            rgba(255,255,255,.025),
            rgba(255,255,255,.012)
        );

    border-top: 0;

    border-bottom: 1px solid rgba(255,255,255,.075);

    color: #737975;

    font-size: 9px;
    font-weight: 800;

    text-transform: uppercase;
    letter-spacing: .65px;

    white-space: nowrap;
}

.report-table tbody td {
    padding: 13px 20px;

    border-top: 1px solid rgba(255,255,255,.042);

    color: #bfc3bf;

    font-size: 11px;

    vertical-align: middle;
}

.report-table tbody tr {
    transition:
        background .16s ease,
        box-shadow .16s ease;
}

.report-table tbody tr:hover {
    background:
        linear-gradient(
            90deg,
            rgba(201,154,0,.035),
            rgba(255,255,255,.018)
        );
}

.report-table tbody tr:hover td:first-child {
    box-shadow: inset 2px 0 0 rgba(201,154,0,.45);
}

.report-table .number {
    font-variant-numeric: tabular-nums;
}

.report-table .money {
    color: #deddd6;

    font-weight: 650;

    font-variant-numeric: tabular-nums;
}


/* =========================================================
   FINANCIAL COLORS
========================================================= */

.report-table .positive {
    color: var(--report-success) !important;
}

.report-table .warning {
    color: var(--report-warning) !important;
}

.report-table .negative {
    color: var(--report-danger) !important;
}

.report-table .profit {
    color: #d8b53f !important;

    font-weight: 800;
}


/* =========================================================
   DATE
========================================================= */

.table-date {
    display: inline-flex;
    align-items: center;

    gap: 7px;

    color: #c5c8c4;

    font-weight: 550;
}

.table-date i {
    color: var(--jinfats-gold-dark);

    font-size: 9px;
}


/* =========================================================
   PRODUCT NAME
========================================================= */

.product-name {
    color: #deddd7;

    font-weight: 650;

    transition: color .16s ease;
}

.report-table tbody tr:hover .product-name {
    color: var(--jinfats-gold-light);
}


/* =========================================================
   LOSS REASON
========================================================= */

.reason-badge {
    display: inline-block;

    max-width: 300px;

    overflow: hidden;

    padding: 5px 8px;

    border-radius: 6px;

    background: rgba(216,117,117,.055);

    border: 1px solid rgba(216,117,117,.10);

    color: #d99595;

    font-size: 10px;

    text-overflow: ellipsis;
    white-space: nowrap;
}


/* =========================================================
   EMPTY STATE
========================================================= */

.report-empty {
    padding: 58px 20px;

    text-align: center;
}

.report-empty-icon {
    width: 57px;
    height: 57px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin: 0 auto 15px;

    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            rgba(255,255,255,.045),
            rgba(255,255,255,.018)
        );

    border: 1px solid rgba(255,255,255,.055);

    color: #666d68;

    font-size: 21px;
}

.report-empty-title {
    margin: 0 0 5px;

    color: #c9cbc6;

    font-size: 13px;
    font-weight: 700;
}

.report-empty-text {
    margin: 0;

    color: #606762;

    font-size: 10px;
}


/* =========================================================
   RESULT FOOTER
========================================================= */

.report-result-footer {
    padding: 10px 20px;

    border-top: 1px solid rgba(255,255,255,.045);

    background: rgba(0,0,0,.06);

    color: #626863;

    font-size: 9px;
}

.report-result-footer i {
    color: var(--jinfats-gold-dark);
}

.report-result-footer strong {
    color: #aeb2ad;
    font-weight: 650;
}


/* =========================================================
   BOOTSTRAP FORM FIXES
========================================================= */

.reports-page .form-control::placeholder {
    color: #5f6561;
}

.reports-page .form-control option {
    background: #22241f;
    color: #e5e3da;
}


/* =========================================================
   RESPONSIVE — TABLET
========================================================= */

@media (max-width: 992px) {

    .reports-header {
        flex-direction: column;
    }

    .report-navigation {
        width: 100%;

        justify-content: flex-start;
    }
}


/* =========================================================
   RESPONSIVE — MOBILE
========================================================= */

@media (max-width: 768px) {

    .reports-title {
        font-size: 22px;
    }

    .reports-header {
        gap: 15px;
    }

    .report-navigation {
        display: grid;

        grid-template-columns: repeat(2, 1fr);

        width: 100%;
    }

    .report-nav-btn {
        width: 100%;
    }

    .report-filter-header {
        align-items: flex-start;

        flex-direction: column;

        gap: 4px;
    }

    .report-filter-form,
    .loss-form {
        align-items: stretch;

        flex-direction: column;
    }

    .report-field,
    .loss-field,
    .loss-field.quantity-field {
        width: 100%;

        min-width: 0;
    }

    .report-run-btn,
    .loss-submit-btn {
        width: 100%;
    }

    .report-table {
        min-width: 650px;
    }

    .report-result-header {
        padding: 14px 15px;
    }

    .report-table thead th,
    .report-table tbody td {
        padding-left: 14px;
        padding-right: 14px;
    }
}


/* =========================================================
   RESPONSIVE — SMALL MOBILE
========================================================= */

@media (max-width: 480px) {

    .reports-title-wrapper {
        gap: 10px;
    }

    .reports-title-icon {
        width: 40px;
        height: 40px;

        font-size: 17px;
    }

    .reports-title {
        font-size: 20px;
    }

    .reports-subtitle {
        font-size: 10px;
    }

    .report-navigation {
        grid-template-columns: 1fr 1fr;
    }

    .report-nav-btn {
        min-height: 33px;

        padding: 7px 5px;

        font-size: 9px;
    }

    .report-nav-btn i {
        font-size: 9px;
    }

    .report-filter-body,
    .loss-body {
        padding: 14px;
    }

    .report-result-title {
        font-size: 12px;
    }

    .report-result-subtitle {
        font-size: 9px;
    }

    .report-result-header .badge {
        font-size: 8px;
    }

    .report-result-footer {
        padding: 10px 14px;
    }
}
```


</style>


<div class="reports-page">

    <!-- =====================================================
         HEADER
    ====================================================== -->

    <div class="reports-header">

        <div class="reports-title-wrapper">

            <div class="reports-title-icon">
                <i class="fas fa-chart-line"></i>
            </div>

            <div>

                <h2 class="reports-title">
                    Reports
                </h2>

                <div class="reports-subtitle">
                    Analyze sales, spending, losses, profitability,
                    and product performance for
                    <span class="reports-store">
                        <?= htmlspecialchars($store['store_name'] ?? '—') ?>
                    </span>
                </div>

            </div>

        </div>


        <!-- Report Navigation -->

        <div class="report-navigation">

            <a href="?view=sales&start=<?= date('Y-m-01') ?>&end=<?= date('Y-m-d') ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'sales' ? 'active' : '' ?>">
                <i class="fas fa-chart-bar"></i>
                Daily Sales
            </a>

            <a href="?view=monthly&year=<?= $year ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'monthly' ? 'active' : '' ?>">
                <i class="fas fa-calendar-alt"></i>
                Monthly
            </a>

            <a href="?view=spending&start=<?= htmlspecialchars($start) ?>&end=<?= htmlspecialchars($end) ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'spending' ? 'active' : '' ?>">
                <i class="fas fa-shopping-cart"></i>
                Cost
            </a>

            <a href="?view=loss&start=<?= htmlspecialchars($start) ?>&end=<?= htmlspecialchars($end) ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'loss' ? 'active' : '' ?>">
                <i class="fas fa-exclamation-triangle"></i>
                Loss
            </a>

            <a href="?view=pl&year=<?= $year ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'pl' ? 'active' : '' ?>">
                <i class="fas fa-file-invoice-dollar"></i>
                P&amp;L
            </a>

            <a href="?view=top&year=<?= $year ?>&month=<?= $month ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'top' ? 'active' : '' ?>">
                <i class="fas fa-arrow-up"></i>
                Top Sellers
            </a>

            <a href="?view=low&year=<?= $year ?>&month=<?= $month ?>"
               class="btn btn-sm btn-outline-light report-nav-btn <?= $view === 'low' ? 'active' : '' ?>">
                <i class="fas fa-arrow-down"></i>
                Low Sellers
            </a>

        </div>

    </div>


    <!-- =====================================================
         ALERTS
    ====================================================== -->

    <?php if ($error): ?>

        <div class="alert alert-danger report-alert alert-dismissible fade show">

            <i class="fas fa-exclamation-circle alert-icon"></i>

            <span>
                <?= htmlspecialchars($error) ?>
            </span>

            <button type="button"
                    class="close"
                    data-dismiss="alert">
                <span>&times;</span>
            </button>

        </div>

    <?php endif; ?>


    <?php if ($success): ?>

        <div class="alert alert-success report-alert alert-dismissible fade show">

            <i class="fas fa-check-circle alert-icon"></i>

            <span>
                <?= htmlspecialchars($success) ?>
            </span>

            <button type="button"
                    class="close"
                    data-dismiss="alert">
                <span>&times;</span>
            </button>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         FILTERS
    ====================================================== -->

    <div class="report-filter-card">

        <div class="report-filter-header">

            <div>

                <h3 class="report-filter-title">
                    <i class="fas fa-sliders-h"></i>
                    Report Filters
                </h3>

            </div>

            <span class="report-filter-description">
                Choose the period you want to analyze.
            </span>

        </div>


        <div class="report-filter-body">

            <form method="GET" class="report-filter-form">

                <input type="hidden"
                       name="view"
                       value="<?= htmlspecialchars($view) ?>">


                <?php if (in_array($view, ['sales', 'spending', 'loss'], true)): ?>

                    <div class="report-field">

                        <label>Start Date</label>

                        <input type="date"
                               name="start"
                               class="form-control"
                               value="<?= htmlspecialchars($start) ?>">

                    </div>


                    <div class="report-field">

                        <label>End Date</label>

                        <input type="date"
                               name="end"
                               class="form-control"
                               value="<?= htmlspecialchars($end) ?>">

                    </div>


                <?php else: ?>

                    <div class="report-field">

                        <label>Year</label>

                        <select name="year"
                                class="form-control">

                            <?php for ($y = (int)date('Y'); $y >= 2024; $y--): ?>

                                <option value="<?= $y ?>"
                                    <?= $year === $y ? 'selected' : '' ?>>
                                    <?= $y ?>
                                </option>

                            <?php endfor; ?>

                        </select>

                    </div>


                    <?php if (in_array($view, ['top', 'low'], true)): ?>

                        <div class="report-field">

                            <label>Month</label>

                            <select name="month"
                                    class="form-control">

                                <?php for ($m = 1; $m <= 12; $m++): ?>

                                    <option value="<?= $m ?>"
                                        <?= $month === $m ? 'selected' : '' ?>>
                                        <?= date('F', mktime(0, 0, 0, $m, 1)) ?>
                                    </option>

                                <?php endfor; ?>

                            </select>

                        </div>

                    <?php endif; ?>

                <?php endif; ?>


                <button type="submit"
                        class="btn btn-warning report-run-btn">

                    <i class="fas fa-sync-alt"></i>

                    Run Report

                </button>

            </form>

        </div>

    </div>


    <!-- =====================================================
         LOSS RECORDING
    ====================================================== -->

    <?php if ($view === 'loss' && current_user()['role'] === 'admin'): ?>

        <div class="loss-card">

            <div class="loss-header">

                <div class="loss-icon">
                    <i class="fas fa-box-open"></i>
                </div>

                <div>

                    <h3 class="loss-title">
                        Record Stock Loss / Damage
                    </h3>

                    <p class="loss-description">
                        Record damaged, expired, missing, or otherwise
                        unusable stock.
                    </p>

                </div>

            </div>


            <div class="loss-body">

                <form method="POST"
                      class="loss-form"
                      onsubmit="return confirm('Record this stock loss?');">

                    <?= csrf_field() ?>

                    <input type="hidden"
                           name="action"
                           value="record_loss">


                    <div class="loss-field">

                        <label>Product</label>

                        <select name="product_id"
                                class="form-control"
                                required>

                            <option value="">
                                — Select Product —
                            </option>

                            <?php foreach ($products as $pr): ?>

                                <option value="<?= (int)$pr['product_id'] ?>">
                                    <?= htmlspecialchars($pr['product_name']) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="loss-field quantity-field">

                        <label>Qty Lost</label>

                        <input type="number"
                               name="quantity"
                               min="1"
                               class="form-control"
                               required>

                    </div>


                    <div class="loss-field">

                        <label>Reason</label>

                        <input type="text"
                               name="reason"
                               class="form-control"
                               placeholder="e.g. damaged, expired"
                               required>

                    </div>


                    <button type="submit"
                            class="btn btn-warning loss-submit-btn">

                        <i class="fas fa-plus-circle mr-1"></i>

                        Record Loss

                    </button>

                </form>

            </div>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         REPORT RESULTS
    ====================================================== -->

    <div class="report-result-card">

        <?php

        $report_titles = [
            'sales'    => 'Daily Sales',
            'monthly'  => 'Monthly Sales',
            'spending' => 'Purchases / Inbound Spending',
            'loss'     => 'Stock Loss / Damage / Write-offs',
            'pl'       => 'Profit & Loss Snapshot',
            'top'      => 'Top Selling Products',
            'low'      => 'Low Selling Products'
        ];

        $report_icons = [
            'sales'    => 'fa-chart-bar',
            'monthly'  => 'fa-calendar-alt',
            'spending' => 'fa-shopping-cart',
            'loss'     => 'fa-exclamation-triangle',
            'pl'       => 'fa-file-invoice-dollar',
            'top'      => 'fa-trophy',
            'low'      => 'fa-chart-line'
        ];

        $report_title = $report_titles[$view] ?? 'Report';
        $report_icon  = $report_icons[$view] ?? 'fa-chart-bar';

        ?>

        <div class="report-result-header">

            <div class="report-heading-wrapper">

                <div class="report-heading-icon">
                    <i class="fas <?= $report_icon ?>"></i>
                </div>

                <div>

                    <h3 class="report-result-title">
                        <?= htmlspecialchars($report_title) ?>
                    </h3>

                    <p class="report-result-subtitle">

                        <?php if (in_array($view, ['sales', 'spending', 'loss'], true)): ?>

                            <?= htmlspecialchars($start) ?>
                            &nbsp;—&nbsp;
                            <?= htmlspecialchars($end) ?>

                        <?php elseif ($view === 'monthly' || $view === 'pl'): ?>

                            Year <?= (int)$year ?>

                        <?php elseif (in_array($view, ['top', 'low'], true)): ?>

                            <?= date('F', mktime(0, 0, 0, $month, 1)) ?>
                            <?= (int)$year ?>

                        <?php endif; ?>

                    </p>

                </div>

            </div>


            <span class="badge badge-secondary">
                <?= count($data) ?> RECORD<?= count($data) !== 1 ? 'S' : '' ?>
            </span>

        </div>


        <div class="report-result-body">


            <!-- =================================================
                 DAILY SALES
            ================================================== -->

            <?php if ($view === 'sales'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Date</th>
                                <th>Transactions</th>
                                <th>Items Sold</th>

                                <th class="text-right">
                                    Gross Sales
                                </th>

                                <th class="text-right">
                                    Net Income
                                </th>

                                <th class="text-right">
                                    Discounts
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>
                                        <span class="table-date">
                                            <i class="far fa-calendar"></i>
                                            <?= htmlspecialchars($r['report_date']) ?>
                                        </span>
                                    </td>

                                    <td class="number">
                                        <?= (int)$r['transactions'] ?>
                                    </td>

                                    <td class="number">
                                        <?= (int)$r['items_sold'] ?>
                                    </td>

                                    <td class="text-right money">
                                        ₱<?= number_format($r['gross_sales'], 2) ?>
                                    </td>

                                    <td class="text-right money positive">
                                        ₱<?= number_format($r['net_income'], 2) ?>
                                    </td>

                                    <td class="text-right money warning">
                                        ₱<?= number_format($r['discounts_given'], 2) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="6">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-chart-bar"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No sales found
                                            </h4>

                                            <p class="report-empty-text">
                                                No sales were recorded for the selected date range.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            <!-- =================================================
                 MONTHLY SALES
            ================================================== -->

            <?php elseif ($view === 'monthly'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Month</th>
                                <th>Transactions</th>

                                <th class="text-right">
                                    Gross Sales
                                </th>

                                <th class="text-right">
                                    Net Income
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>
                                        <span class="table-date">
                                            <i class="far fa-calendar-alt"></i>
                                            <?= htmlspecialchars($r['month_name']) ?>
                                            <?= (int)$r['yr'] ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= (int)$r['transactions'] ?>
                                    </td>

                                    <td class="text-right money">
                                        ₱<?= number_format($r['gross_sales'], 2) ?>
                                    </td>

                                    <td class="text-right money positive">
                                        ₱<?= number_format($r['net_income'], 2) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="4">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-calendar-alt"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No monthly data
                                            </h4>

                                            <p class="report-empty-text">
                                                There is no sales data available for this year.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            <!-- =================================================
                 SPENDING
            ================================================== -->

            <?php elseif ($view === 'spending'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Date</th>
                                <th>Deliveries</th>

                                <th class="text-right">
                                    Total Spending
                                </th>

                                <th class="text-right">
                                    Units Received
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>
                                        <span class="table-date">
                                            <i class="far fa-calendar"></i>
                                            <?= htmlspecialchars($r['report_date']) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= (int)$r['deliveries'] ?>
                                    </td>

                                    <td class="text-right money warning">
                                        ₱<?= number_format($r['total_spending'], 2) ?>
                                    </td>

                                    <td class="text-right">
                                        <?= (int)$r['units_received'] ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="4">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-shopping-cart"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No spending found
                                            </h4>

                                            <p class="report-empty-text">
                                                No inbound spending was recorded for this period.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            <!-- =================================================
                 LOSS
            ================================================== -->

            <?php elseif ($view === 'loss'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Date</th>
                                <th>Reason</th>

                                <th class="text-right">
                                    Units Lost
                                </th>

                                <th class="text-right">
                                    Loss Amount
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>
                                        <span class="table-date">
                                            <i class="far fa-calendar"></i>
                                            <?= htmlspecialchars($r['report_date']) ?>
                                        </span>
                                    </td>

                                    <td>

                                        <span class="reason-badge">

                                            <?= htmlspecialchars(
                                                str_replace(
                                                    'LOSS:',
                                                    '',
                                                    $r['loss_reason']
                                                )
                                            ) ?>

                                        </span>

                                    </td>

                                    <td class="text-right negative">
                                        <?= (int)$r['units_lost'] ?>
                                    </td>

                                    <td class="text-right money negative">
                                        ₱<?= number_format($r['loss_amount'], 2) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="4">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-check-circle"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No stock losses
                                            </h4>

                                            <p class="report-empty-text">
                                                No stock losses or damages were recorded for this period.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            <!-- =================================================
                 P&L
            ================================================== -->

            <?php elseif ($view === 'pl'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Month</th>

                                <th class="text-right">
                                    Net Income
                                </th>

                                <th class="text-right">
                                    Spending
                                </th>

                                <th class="text-right">
                                    Loss
                                </th>

                                <th class="text-right">
                                    Net Profit
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>
                                        <span class="table-date">
                                            <i class="far fa-calendar-alt"></i>
                                            <?= htmlspecialchars($r['month_name']) ?>
                                        </span>
                                    </td>

                                    <td class="text-right money positive">
                                        ₱<?= number_format($r['net_income'], 2) ?>
                                    </td>

                                    <td class="text-right money warning">
                                        ₱<?= number_format($r['total_spending'], 2) ?>
                                    </td>

                                    <td class="text-right money negative">
                                        ₱<?= number_format($r['total_loss'], 2) ?>
                                    </td>

                                    <td class="text-right money profit">
                                        ₱<?= number_format($r['net_profit'], 2) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="5">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No P&amp;L data
                                            </h4>

                                            <p class="report-empty-text">
                                                No financial data is available for this year.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            <!-- =================================================
                 TOP SELLERS
            ================================================== -->

            <?php elseif ($view === 'top'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Product</th>

                                <th class="text-right">
                                    Qty Sold
                                </th>

                                <th class="text-right">
                                    Revenue
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>

                                        <span class="product-name">
                                            <?= htmlspecialchars(
                                                $r['product_name'] ??
                                                '(unnamed product)'
                                            ) ?>
                                        </span>

                                    </td>

                                    <td class="text-right positive">
                                        <?= (int)$r['total_qty_sold'] ?>
                                    </td>

                                    <td class="text-right money positive">
                                        ₱<?= number_format($r['total_revenue'], 2) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="3">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-trophy"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No product sales
                                            </h4>

                                            <p class="report-empty-text">
                                                No products were sold during the selected month.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>


            <!-- =================================================
                 LOW SELLERS
            ================================================== -->

            <?php elseif ($view === 'low'): ?>

                <div class="table-responsive">

                    <table class="table report-table datatable">

                        <thead>
                            <tr>

                                <th>Product</th>

                                <th class="text-right">
                                    Qty Sold
                                </th>

                                <th class="text-right">
                                    Revenue
                                </th>

                            </tr>
                        </thead>


                        <tbody>

                            <?php foreach ($data as $r): ?>

                                <tr>

                                    <td>

                                        <span class="product-name">
                                            <?= htmlspecialchars(
                                                $r['product_name'] ??
                                                '(unnamed product)'
                                            ) ?>
                                        </span>

                                    </td>

                                    <td class="text-right negative">
                                        <?= (int)$r['total_qty_sold'] ?>
                                    </td>

                                    <td class="text-right money">
                                        ₱<?= number_format($r['total_revenue'], 2) ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <?php if (!$data): ?>

                                <tr>
                                    <td colspan="3">

                                        <div class="report-empty">

                                            <div class="report-empty-icon">
                                                <i class="fas fa-chart-line"></i>
                                            </div>

                                            <h4 class="report-empty-title">
                                                No product data
                                            </h4>

                                            <p class="report-empty-text">
                                                No product sales data is available for the selected month.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>


        <?php if ($data): ?>

            <div class="report-result-footer">

                <i class="fas fa-info-circle mr-1"></i>

                Showing <?= count($data) ?>
                report record<?= count($data) !== 1 ? 's' : '' ?>
                for
                <strong><?= htmlspecialchars($store['store_name'] ?? '—') ?></strong>.

            </div>

        <?php endif; ?>

    </div>

</div>


<?php require __DIR__ . '/includes/footer_bootstrap.php'; ?>