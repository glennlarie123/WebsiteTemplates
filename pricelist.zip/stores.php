<?php
// stores.php — admin only. View registered stores/tenants.
// NOTE: Removing stores (registered or database) is intentionally not
// supported from this page. Store removal must be handled manually.

require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_role('admin');

require_once __DIR__ . '/includes/store_db_mysqli.php';

$config = app_config();
$stores = $config['stores'];
$active_store_id = (int)($_SESSION['active_store_id'] ?? 0);

$page_title = 'Stores · INGCO Dealer Portal';
$active_nav = 'stores';

require __DIR__ . '/includes/header_bootstrap.php';
?>

<style>
    /* =========================
       STORES PAGE
    ========================= */

    .stores-page {
        padding-bottom: 30px;
    }

    /* Page Header */
    .stores-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        margin-bottom: 24px;
    }

    .stores-title-wrapper {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .stores-title-icon {
        width: 46px;
        height: 46px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        background: rgba(255, 193, 7, 0.12);
        color: #ffc107;
        font-size: 21px;
        border: 1px solid rgba(255, 193, 7, 0.18);
    }

    .stores-title {
        margin: 0;
        font-size: 26px;
        font-weight: 700;
        letter-spacing: -0.3px;
    }

    .stores-subtitle {
        margin: 4px 0 0;
        font-size: 13px;
        color: #94a3b8;
    }

    /* Buttons */
    .store-actions {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .store-switch-btn {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 8px 14px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        transition: all .2s ease;
    }

    .store-switch-btn:hover {
        transform: translateY(-1px);
    }

    /* Statistics */
    .store-summary {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 14px;
        margin-bottom: 20px;
    }

    .summary-card {
        position: relative;
        overflow: hidden;
        padding: 17px 18px;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.025);
        border: 1px solid rgba(255, 255, 255, 0.07);
    }

    .summary-card::after {
        content: "";
        position: absolute;
        width: 70px;
        height: 70px;
        right: -30px;
        bottom: -35px;
        border-radius: 50%;
        background: rgba(255, 193, 7, 0.08);
    }

    .summary-label {
        display: block;
        margin-bottom: 5px;
        color: #94a3b8;
        font-size: 12px;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: .5px;
    }

    .summary-value {
        color: #f8fafc;
        font-size: 22px;
        font-weight: 700;
    }

    /* Main Card */
    .stores-card {
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.07);
        border-radius: 14px;
        background: rgba(255, 255, 255, 0.025);
        box-shadow: 0 8px 30px rgba(0, 0, 0, .12);
    }

    .stores-card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 17px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.07);
    }

    .stores-card-title {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
        color: #f8fafc;
    }

    .stores-card-description {
        margin: 3px 0 0;
        color: #64748b;
        font-size: 12px;
    }

    .store-count {
        padding: 4px 9px;
        border-radius: 20px;
        background: rgba(255, 193, 7, .10);
        border: 1px solid rgba(255, 193, 7, .15);
        color: #ffc107;
        font-size: 11px;
        font-weight: 700;
    }

    /* Table */
    .stores-table {
        margin: 0;
        color: #e2e8f0;
    }

    .stores-table thead th {
        padding: 13px 20px;
        background: rgba(255, 255, 255, .018);
        border-top: 0;
        border-bottom: 1px solid rgba(255, 255, 255, .07);
        color: #64748b;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .6px;
        white-space: nowrap;
    }

    .stores-table tbody td {
        padding: 16px 20px;
        vertical-align: middle;
        border-top: 1px solid rgba(255, 255, 255, .045);
        font-size: 13px;
    }

    .stores-table tbody tr {
        transition: background .18s ease;
    }

    .stores-table tbody tr:hover {
        background: rgba(255, 255, 255, .025);
    }

    /* Store Name */
    .store-name-wrapper {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .store-icon {
        width: 38px;
        height: 38px;
        flex: 0 0 38px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 9px;
        background: rgba(255, 193, 7, .10);
        border: 1px solid rgba(255, 193, 7, .14);
        color: #ffc107;
        font-size: 16px;
    }

    .store-name {
        color: #f8fafc;
        font-weight: 600;
        line-height: 1.3;
    }

    .store-id {
        margin-top: 3px;
        color: #64748b;
        font-size: 11px;
    }

    /* Active Badge */
    .active-store-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        margin-left: 7px;
        padding: 4px 8px;
        border-radius: 20px;
        background: rgba(40, 167, 69, .10);
        border: 1px solid rgba(40, 167, 69, .18);
        color: #4ade80;
        font-size: 9px;
        font-weight: 800;
        letter-spacing: .4px;
        vertical-align: middle;
    }

    .active-store-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: #4ade80;
        box-shadow: 0 0 7px rgba(74, 222, 128, .6);
    }

    /* Database */
    .database-name {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 6px 9px;
        border-radius: 7px;
        background: rgba(255, 255, 255, .025);
        border: 1px solid rgba(255, 255, 255, .055);
        color: #94a3b8;
        font-family: monospace;
        font-size: 12px;
    }

    .database-icon {
        color: #64748b;
        font-size: 11px;
    }

    /* Empty State */
    .empty-state {
        padding: 55px 20px;
        text-align: center;
    }

    .empty-icon {
        width: 58px;
        height: 58px;
        margin: 0 auto 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 14px;
        background: rgba(255, 255, 255, .035);
        color: #64748b;
        font-size: 23px;
    }

    .empty-title {
        margin: 0 0 5px;
        color: #e2e8f0;
        font-size: 15px;
        font-weight: 600;
    }

    .empty-description {
        margin: 0;
        color: #64748b;
        font-size: 12px;
    }

    /* Footer Note */
    .stores-note {
        display: flex;
        align-items: flex-start;
        gap: 9px;
        margin-top: 14px;
        padding: 12px 14px;
        border-radius: 9px;
        background: rgba(59, 130, 246, .045);
        border: 1px solid rgba(59, 130, 246, .08);
        color: #64748b;
        font-size: 11px;
        line-height: 1.5;
    }

    .stores-note i {
        margin-top: 2px;
        color: #60a5fa;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .stores-header {
            align-items: flex-start;
            flex-direction: column;
        }

        .store-actions {
            width: 100%;
        }

        .store-switch-btn {
            width: 100%;
            justify-content: center;
        }

        .store-summary {
            grid-template-columns: 1fr;
        }

        .stores-title {
            font-size: 22px;
        }

        .stores-card-header {
            padding: 15px;
        }

        .stores-table thead th,
        .stores-table tbody td {
            padding-left: 15px;
            padding-right: 15px;
        }

        .stores-table {
            min-width: 600px;
        }
    }

    @media (max-width: 480px) {
        .stores-title-icon {
            width: 40px;
            height: 40px;
        }

        .stores-title-wrapper {
            gap: 10px;
        }

        .stores-subtitle {
            font-size: 12px;
        }
    }
</style>

<div class="stores-page">

    <!-- Page Header -->
    <div class="stores-header">

        <div class="stores-title-wrapper">

            <div class="stores-title-icon">
                <i class="fas fa-store"></i>
            </div>

            <div>
                <h2 class="stores-title">Stores</h2>
                <p class="stores-subtitle">
                    Manage and view registered stores and their databases.
                </p>
            </div>

        </div>

        <div class="store-actions">
            <a href="db_select"
               class="btn btn-outline-light store-switch-btn">
                <i class="fas fa-exchange-alt"></i>
                <span>Switch Store</span>
            </a>
        </div>

    </div>


    <!-- Summary -->
    <div class="store-summary">

        <div class="summary-card">
            <span class="summary-label">Registered Stores</span>
            <span class="summary-value"><?= count($stores) ?></span>
        </div>

        <div class="summary-card">
            <span class="summary-label">Active Store</span>
            <span class="summary-value">
                <?php
                $active_store_name = 'None';

                foreach ($stores as $s) {
                    if ((int)$s['store_id'] === $active_store_id) {
                        $active_store_name = $s['store_name'];
                        break;
                    }
                }

                echo htmlspecialchars($active_store_name);
                ?>
            </span>
        </div>

        <div class="summary-card">
            <span class="summary-label">Access Level</span>
            <span class="summary-value">Administrator</span>
        </div>

    </div>


    <!-- Stores Table -->
    <div class="stores-card">

        <div class="stores-card-header">

            <div>
                <h3 class="stores-card-title">
                    Registered Stores
                </h3>

                <p class="stores-card-description">
                    Each store maintains its own separate data.
                </p>
            </div>

            <span class="store-count">
                <?= count($stores) ?> STORE<?= count($stores) !== 1 ? 'S' : '' ?>
            </span>

        </div>


        <div class="table-responsive">

            <table class="table stores-table">

                <thead>
                    <tr>
                        <th>Store</th>
                        <th>Database</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if ($stores): ?>

                        <?php foreach ($stores as $s): ?>

                            <?php
                            $store_id = (int)$s['store_id'];
                            $is_active = ($store_id === $active_store_id);
                            ?>

                            <tr>

                                <!-- Store -->
                                <td>

                                    <div class="store-name-wrapper">

                                        <div class="store-icon">
                                            <i class="fas fa-store-alt"></i>
                                        </div>

                                        <div>

                                            <div class="store-name">

                                                <?= htmlspecialchars($s['store_name']) ?>

                                                <?php if ($is_active): ?>

                                                    <span class="active-store-badge">
                                                        <span class="active-store-dot"></span>
                                                        ACTIVE
                                                    </span>

                                                <?php endif; ?>

                                            </div>

                                            <div class="store-id">
                                                Store ID #<?= $store_id ?>
                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <!-- Database -->
                                <td>

                                    <span class="database-name">

                                        <i class="fas fa-database database-icon"></i>

                                        <?= htmlspecialchars($s['db_name']) ?>

                                    </span>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="2">

                                <div class="empty-state">

                                    <div class="empty-icon">
                                        <i class="fas fa-store-slash"></i>
                                    </div>

                                    <h4 class="empty-title">
                                        No stores registered
                                    </h4>

                                    <p class="empty-description">
                                        There are currently no stores available in the system.
                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


    <!-- Information -->
    <div class="stores-note">

        <i class="fas fa-info-circle"></i>

        <span>
            Each store operates independently with its own products,
            prices, inventory, and sales history. Changes made within
            one store do not affect another store.
        </span>

    </div>

</div>

<?php require __DIR__ . '/includes/footer_bootstrap.php'; ?>
