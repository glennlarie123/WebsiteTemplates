<?php
// logout.php
require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();

$_SESSION = array();
session_destroy();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

header("Location: login");
exit;
