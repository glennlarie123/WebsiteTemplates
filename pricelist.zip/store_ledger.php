<?php
// store_ledger.php — REMOVED / stub page
require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_role('admin');

$page_title = 'Store Ledger · INGCO Dealer Portal';
$active_nav = 'ledger';
require __DIR__ . '/includes/header_bootstrap.php';
?>

<div class="card">
    <div class="card-body">
        <p>The ledger (spending/stock-loss tracking) was removed when the database was reconciled to <code>pricelist_database.txt</code> — <code>store_transactions</code>, <code>store_transaction_items</code>, and <code>system_stores</code> no longer exist.</p>
        <a href="index.php" class="btn btn-outline-light btn-sm">← Back to Dashboard</a>
    </div>
</div>

<?php require __DIR__ . '/includes/footer_bootstrap.php'; ?>
