<?php
// db_import.php — admin only. Import a .sql file either into the
// currently connected store's database, or as a brand-new store (creates
// the database, imports into it, registers it in config/app_config.json,
// and connects the session to it).
require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_role('admin');
require_once __DIR__ . '/includes/store_db_mysqli.php';

$config = app_config();
$active_store = null;
if (!empty($_SESSION['active_store_id'])) {
    foreach ($config['stores'] as $s) {
        if ((int)$s['store_id'] === (int)$_SESSION['active_store_id']) { $active_store = $s; break; }
    }
}

$max_upload_bytes = 20 * 1024 * 1024; // 20MB safety cap
$import_success = '';
$import_error = '';

// Same statement-splitting approach as before -- mysqli::query() can't
// reliably run a whole multi-statement .sql file in one call (that's what
// multi_query() is for, and it doesn't play nicely with mixed DDL/DML or
// error reporting per-statement), so this tracks quoted strings/identifiers,
// comments, and DELIMITER changes to split it into individual statements
// that get run one at a time via query().
function split_sql_statements(string $sql): array {
    $statements = [];
    $delimiter = ';';
    $buffer = '';
    $len = strlen($sql);
    $i = 0;
    $inSingle = $inDouble = $inBacktick = $inLineComment = $inBlockComment = false;

    while ($i < $len) {
        $ch = $sql[$i];
        $two = substr($sql, $i, 2);

        if ($inLineComment) {
            $buffer .= $ch;
            if ($ch === "\n") $inLineComment = false;
            $i++;
            continue;
        }
        if ($inBlockComment) {
            if ($two === '*/') { $buffer .= $two; $i += 2; $inBlockComment = false; continue; }
            $buffer .= $ch; $i++;
            continue;
        }
        if ($inSingle || $inDouble) {
            $quote = $inSingle ? "'" : '"';
            if ($ch === '\\' && $i + 1 < $len) { $buffer .= $ch . $sql[$i + 1]; $i += 2; continue; }
            $buffer .= $ch;
            if ($ch === $quote) { $inSingle = $inDouble = false; }
            $i++;
            continue;
        }
        if ($inBacktick) {
            $buffer .= $ch;
            if ($ch === '`') $inBacktick = false;
            $i++;
            continue;
        }

        if ($two === '--' && ($i + 2 >= $len || $sql[$i + 2] === ' ' || $sql[$i + 2] === "\t" || $sql[$i + 2] === "\n")) {
            $buffer .= $two; $i += 2; $inLineComment = true;
            continue;
        }
        if ($ch === '#') { $buffer .= $ch; $i++; $inLineComment = true; continue; }
        if ($two === '/*') { $buffer .= $two; $i += 2; $inBlockComment = true; continue; }
        if ($ch === "'") { $inSingle = true; $buffer .= $ch; $i++; continue; }
        if ($ch === '"') { $inDouble = true; $buffer .= $ch; $i++; continue; }
        if ($ch === '`') { $inBacktick = true; $buffer .= $ch; $i++; continue; }

        if (trim($buffer) === '' && stripos(substr($sql, $i, 10), 'DELIMITER') === 0) {
            $eol = strpos($sql, "\n", $i);
            if ($eol === false) $eol = $len;
            $line = trim(substr($sql, $i, $eol - $i));
            if (preg_match('/^DELIMITER\s+(\S+)/i', $line, $m)) {
                $delimiter = $m[1];
                $i = $eol + 1;
                $buffer = '';
                continue;
            }
        }

        $delimLen = strlen($delimiter);
        if (substr($sql, $i, $delimLen) === $delimiter) {
            $stmt = trim($buffer);
            if ($stmt !== '') $statements[] = $stmt;
            $buffer = '';
            $i += $delimLen;
            continue;
        }

        $buffer .= $ch;
        $i++;
    }

    $tail = trim($buffer);
    if ($tail !== '') $statements[] = $tail;

    return $statements;
}

// MySQL/MariaDB implicitly commits the current transaction whenever a DDL
// statement (CREATE/DROP/ALTER/TRUNCATE/RENAME) runs -- schema dumps like
// Navicat exports are almost entirely DDL. If we wrap such a file in
// begin_transaction()/commit(), the first DDL statement silently ends that
// transaction; mysqli doesn't surface this, so a later commit() either
// no-ops or reports success on a transaction that no longer exists, which
// would misrepresent what actually happened. Detecting DDL up front lets us
// skip the (illusory) transaction wrapping for files that contain it, rather
// than wrapping unconditionally and reporting a false failure/success after
// the fact.
function statements_contain_ddl(array $statements): bool {
    foreach ($statements as $s) {
        if (preg_match('/^\s*(CREATE|DROP|ALTER|TRUNCATE|RENAME)\b/i', $s)) {
            return true;
        }
    }
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import_sql') {
    verify_csrf();

    $target_mode = ($_POST['target_mode'] ?? 'current') === 'new' ? 'new' : 'current';
    $new_store_name = trim($_POST['new_store_name'] ?? '');
    $new_db_name = '';

    if ($target_mode === 'current' && !$active_store) {
        $import_error = 'No store is currently connected. Choose "Create a new store" below instead.';
    } elseif ($target_mode === 'new') {
        if ($new_store_name === '') {
            $import_error = 'Store name is required.';
        } else {
            $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '_', $new_store_name));
            $slug = trim($slug, '_');
            $new_db_name = 'store_' . $slug;
            if ($slug === '' || !preg_match('/^[a-zA-Z0-9_]{1,64}$/', $new_db_name)) {
                $import_error = 'Could not derive a valid database name from that store name -- use letters/numbers.';
            } else {
                foreach ($config['stores'] as $s) {
                    if ($s['db_name'] === $new_db_name || strcasecmp($s['store_name'], $new_store_name) === 0) {
                        $import_error = 'A store with that name already exists.';
                        break;
                    }
                }
            }
        }
    }

    if (!$import_error && ($_POST['confirm_understand'] ?? '') !== 'yes') {
        $import_error = 'Please check the confirmation box to proceed.';
    }
    if (!$import_error && (!isset($_FILES['sql_file']) || $_FILES['sql_file']['error'] !== UPLOAD_ERR_OK)) {
        $import_error = 'No file uploaded, or the upload failed.';
    }

    if (!$import_error) {
        $file = $_FILES['sql_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($ext !== 'sql') {
            $import_error = 'Only .sql files are accepted.';
        } elseif ($file['size'] > $max_upload_bytes) {
            $import_error = 'File is too large (max 20MB).';
        }
    }

    if (!$import_error) {
        $sql = file_get_contents($file['tmp_name']);
        if ($sql === false || trim($sql) === '') {
            $import_error = 'Could not read the uploaded file, or it was empty.';
        } else {
            $statements = split_sql_statements($sql);
            if (!$statements) {
                $import_error = 'No SQL statements were found in the file.';
            } else {
                $executed = 0;
                $current_stmt = '';
                $target_conn = null;      // mysqli connection (raw handle), not PDO
                $in_transaction = false;  // mysqli has no inTransaction(); we track it ourselves
                $has_ddl = statements_contain_ddl($statements);
                try {
                    if ($target_mode === 'new') {
                        create_database_if_missing($new_db_name);
                        $target_conn = connect_store_proc($new_db_name);
                    } else {
                        $target_conn = connect_store_proc($active_store['db_name']);
                    }

                    // Only wrap in a transaction when the file is pure
                    // data statements (no DDL) -- see statements_contain_ddl()
                    // above for why a transaction around DDL is illusory and
                    // would misrepresent the outcome on a fully successful run.
                    if (!$has_ddl) {
                        $target_conn->begin_transaction();
                        $in_transaction = true;
                    }
                    foreach ($statements as $current_stmt) {
                        $target_conn->query($current_stmt);
                        $executed++;
                    }
                    if (!$has_ddl) {
                        $target_conn->commit();
                        $in_transaction = false;
                    }

                    if ($target_mode === 'new') {
                        $new_id = $config['next_store_id'] ?? (count($config['stores']) + 1);
                        $config['stores'][] = ['store_id' => $new_id, 'store_name' => $new_store_name, 'db_name' => $new_db_name];
                        $config['next_store_id'] = $new_id + 1;
                        save_app_config($config);
                        $_SESSION['active_store_id'] = $new_id;
                        $import_success = "New store '{$new_store_name}' created — {$executed} statement(s) executed. You're now connected to it.";
                    } else {
                        $import_success = "Import completed successfully — {$executed} statement(s) executed.";
                    }
                    flash('success', 'Database import completed.');
                } catch (\mysqli_sql_exception $e) {
                    if ($in_transaction && $target_conn) {
                        $target_conn->rollback();
                    }
                    error_log('DB import failed: ' . $e->getMessage());
                    $preview = substr($current_stmt, 0, 150);
                    if (strlen($current_stmt) > 150) $preview .= '…';
                    $rollback_note = $has_ddl
                        ? ' — this file contains schema changes (CREATE/ALTER/DROP/etc.), which auto-commit individually in MySQL: the ' . $executed . ' statement(s) that ran before this one already applied and were NOT undone.'
                        : ' — this was a data-only import; any INSERT/UPDATE/DELETE changes were rolled back since no schema changes occurred.';
                    $import_error = 'Import failed on statement ' . ($executed + 1) . ' of ' . count($statements)
                        . ': ' . $e->getMessage() . ' — near: ' . $preview . $rollback_note;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Import Database · JINFATS ENTERPRISES</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/ui-fixes.css">
</head>
<body>
<div class="container">
    <div class="header">
        <div><span class="brand">JINFATS</span> <span class="header-sub">Import Database</span></div>
        <a href="<?= $active_store ? 'index.php' : 'db_select.php' ?>" class="btn-cancel">← Back</a>
    </div>

    <div class="card" style="border-left: 4px solid #f43f5e; margin-bottom:16px;">
        <strong style="color:#f43f5e;">⚠ This runs raw SQL directly against a live database.</strong>
        <p style="color:#94a3b8; margin-bottom:0;">
            There is no undo button. Take a fresh backup before importing, and only upload a .sql file you trust completely.
        </p>
    </div>

    <?php if ($import_error): ?>
        <div class="flash flash-error"><?= htmlspecialchars($import_error) ?></div>
    <?php endif; ?>
    <?php if ($import_success): ?>
        <div class="flash flash-success"><?= htmlspecialchars($import_success) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="form-card" style="max-width:520px;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="import_sql">

        <label>Import into
            <select name="target_mode" id="target_mode" onchange="document.getElementById('new_store_fields').style.display = this.value === 'new' ? 'block' : 'none';">
                <?php if ($active_store): ?>
                    <option value="current">Current store — <?= htmlspecialchars($active_store['store_name']) ?></option>
                <?php endif; ?>
                <option value="new" <?= !$active_store ? 'selected' : '' ?>>Create a new store</option>
            </select>
        </label>

        <div id="new_store_fields" style="<?= $active_store ? 'display:none;' : '' ?>">
            <label>New store name
                <input type="text" name="new_store_name" value="<?= htmlspecialchars($new_store_name ?? '') ?>" placeholder="e.g. Cagayan de Oro Branch">
            </label>
        </div>

        <label>SQL file (.sql, max 20MB)
            <input type="file" name="sql_file" accept=".sql" required>
        </label>
        <label style="display:flex; align-items:center; gap:8px; margin-top:12px;">
            <input type="checkbox" name="confirm_understand" value="yes" required>
            I have a backup and understand this will change the database.
        </label>
        <button type="submit" class="btn-save" style="margin-top:16px;" onclick="return confirm('Run this SQL file now? This cannot be undone.');">⚡ Import Now</button>
        <a href="<?= $active_store ? 'index.php' : 'db_select.php' ?>" class="btn-cancel">Cancel</a>
    </form>
</div>
</body>
</html>