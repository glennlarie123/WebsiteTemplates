<?php
// product_form.php — product detail + admin inline editor
require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_login();
require_once __DIR__ . '/includes/store_db_mysqli.php';
$db = require_active_store();
$store = get_active_store();

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$is_admin = (current_user()['role'] ?? '') === 'admin';
$msg = '';
$err = '';

// Handle update
if ($is_admin && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_product') {
    verify_csrf();
    $price = (float)($_POST['product_price'] ?? 0);
    $cost  = (float)($_POST['product_cost'] ?? 0);
    $qty   = (int)($_POST['product_quantity'] ?? 0);
    $avail = isset($_POST['product_availability']) ? 1 : 0;
    $earnings = $price - $cost;

    $db->prepared_query("
        UPDATE table_product 
        SET product_price = ?, product_cost = ?, product_quantity = ?, product_availability = ?, product_earnings = ?
        WHERE product_id = ?
    ", 'ddidid', $price, $cost, $qty, $avail, $earnings, $product_id);
    $msg = 'Product updated successfully.';
}

$product = $db->fetch_row('
    SELECT p.product_id as id, p.product_name as name, p.item_no as itemNo, p.product_brand as brand,
           COALESCE(p.product_cost, 0) as cost, COALESCE(p.product_price, 0) as price,
           p.product_quantity as qty, p.product_availability as availability,
           c.category_name as categoryName
    FROM table_product p
    LEFT JOIN table_category c ON p.category_id = c.category_id
    WHERE p.product_id = ?
', 'i', $product_id);

if (!$product || $product['name'] === null) {
    http_response_code(404);
    die('Product not found.');
}

$page_title = 'Product Details · INGCO Dealer Portal';
$active_nav = 'products';
require __DIR__ . '/includes/header_bootstrap.php';
?>

<h2 class="mb-1"><?= htmlspecialchars($product['name']) ?></h2>
<div class="small text-muted mb-3">Store: <strong><?= htmlspecialchars($store['store_name'] ?? '—') ?></strong></div>

<?php if ($msg): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?= htmlspecialchars($msg) ?>
        <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
    </div>
<?php endif; ?>
<?php if ($err): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?= htmlspecialchars($err) ?>
        <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
    </div>
<?php endif; ?>

<div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">SKU</div>
                <div class="text-monospace text-warning"><?= $product['itemNo'] !== null ? htmlspecialchars($product['itemNo']) : '<span class="text-muted">—</span>' ?></div>
            </div>
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">Category</div>
                <div><?= htmlspecialchars($product['categoryName'] ?? '—') ?></div>
            </div>
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">Brand</div>
                <div><?= htmlspecialchars($product['brand'] ?? '—') ?></div>
            </div>
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">Quantity in Stock</div>
                <div><?= (int)$product['qty'] ?></div>
            </div>
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">Cost</div>
                <div>₱<?= number_format($product['cost'], 2) ?></div>
            </div>
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">Price</div>
                <div>₱<?= number_format($product['price'], 2) ?></div>
            </div>
            <div class="col-md-4 col-lg-2 mb-3">
                <div class="small text-muted text-uppercase">Availability</div>
                <div><?= (int)$product['availability'] ? '<span class="text-success">Active</span>' : '<span class="text-muted">Hidden</span>' ?></div>
            </div>
        </div>
    </div>
</div>

<?php if ($is_admin): ?>
<div class="card mb-3 border-left-warning" style="border-left:4px solid #ffbe00;">
    <div class="card-body">
        <strong class="text-warning">Edit Product</strong>
        <form method="POST" class="mt-3">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_product">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label class="small text-muted text-uppercase d-block">Base Price (₱)</label>
                    <input type="number" step="0.01" name="product_price" class="form-control" value="<?= number_format($product['price'], 2, '.', '') ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="small text-muted text-uppercase d-block">Base Cost (₱)</label>
                    <input type="number" step="0.01" name="product_cost" class="form-control" value="<?= number_format($product['cost'], 2, '.', '') ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="small text-muted text-uppercase d-block">Stock Qty</label>
                    <input type="number" name="product_quantity" class="form-control" value="<?= (int)$product['qty'] ?>" required>
                </div>
                <div class="col-md-3 mb-3 d-flex align-items-center pt-3">
                    <label class="d-flex align-items-center gap-2 mb-0" style="gap:8px; cursor:pointer;">
                        <input type="checkbox" name="product_availability" value="1" <?= (int)$product['availability'] ? 'checked' : '' ?>>
                        <span>Available for sale</span>
                    </label>
                </div>
            </div>
            <button type="submit" class="btn btn-warning font-weight-bold">Save Changes</button>
        </form>
    </div>
</div>
<?php endif; ?>

<a href="products.php" class="btn btn-outline-secondary btn-sm">← Back to Catalog</a>

<?php require __DIR__ . '/includes/footer_bootstrap.php'; ?>
