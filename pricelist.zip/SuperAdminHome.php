<title>Sales Report</title>
<?php
/**
 * Sales Dashboard
 * ------------------------------------------------------------
 * Production-ready sales reporting dashboard.
 *
 * Existing database tables used:
 *   - stock_movements
 *   - table_product
 *
 * Existing includes:
 *   - SuperAdminHeaders.php
 *   - SuperAdminFooters.php
 *   - ../database/connection.php
 */

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

include "includes/db_mysqli.php";

/* ============================================================
   CONFIGURATION
   ============================================================ */

if (!defined('CURRENCY_SYMBOL')) {
    define('CURRENCY_SYMBOL', '₱');
}

if (!defined('DEFAULT_LOW_STOCK_THRESHOLD')) {
    define('DEFAULT_LOW_STOCK_THRESHOLD', 10);
}

date_default_timezone_set('Asia/Manila');


/* ============================================================
   HELPER FUNCTIONS
   ============================================================ */

/**
 * Format money.
 */
function money($amount)
{
    $amount = (float) $amount;

    $sign = $amount < 0 ? '-' : '';

    return $sign . CURRENCY_SYMBOL . number_format(abs($amount), 2);
}


/**
 * Escape HTML.
 */
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


/**
 * Execute a prepared statement and return result.
 */
function executeQuery($conn, $sql, $types = '', $params = [])
{
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return false;
    }

    if ($types !== '' && !empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return false;
    }

    $result = mysqli_stmt_get_result($stmt);

    mysqli_stmt_close($stmt);

    return $result;
}


/**
 * Validate YYYY-MM-DD date.
 */
function validDate($date)
{
    if (!is_string($date) || $date === '') {
        return false;
    }

    $dt = DateTime::createFromFormat('Y-m-d', $date);

    return $dt !== false && $dt->format('Y-m-d') === $date;
}


/**
 * Format quantity without unnecessary decimals.
 */
function formatQty($quantity)
{
    $quantity = (float) $quantity;

    if (floor($quantity) == $quantity) {
        return number_format($quantity, 0);
    }

    return number_format($quantity, 2);
}


/**
 * Get product image URL.
 */
function productImage($path)
{
    $path = trim((string) $path);

    if ($path === '') {
        return '../img/no-image.png';
    }

    return '../' . ltrim($path, '/');
}


/* ============================================================
   DATE / FILTER INPUT
   ============================================================ */

$today     = date('Y-m-d');
$monthStart = date('Y-m-01');
$yearStart  = date('Y-01-01');

$fromDate = isset($_GET['from_date']) && $_GET['from_date'] !== ''
    ? trim($_GET['from_date'])
    : $monthStart;

$toDate = isset($_GET['to_date']) && $_GET['to_date'] !== ''
    ? trim($_GET['to_date'])
    : $today;

$threshold = isset($_GET['low_stock'])
    ? max(0, (int) $_GET['low_stock'])
    : DEFAULT_LOW_STOCK_THRESHOLD;


/* Validate dates */

if (!validDate($fromDate)) {
    $fromDate = $monthStart;
}

if (!validDate($toDate)) {
    $toDate = $today;
}


/* Swap dates if reversed */

$fromObj = DateTime::createFromFormat('Y-m-d', $fromDate);
$toObj   = DateTime::createFromFormat('Y-m-d', $toDate);

if ($fromObj && $toObj && $fromObj > $toObj) {
    [$fromDate, $toDate] = [$toDate, $fromDate];
}


/* SQL datetime boundaries */

$rangeStart = $fromDate . ' 00:00:00';
$rangeEnd   = $toDate . ' 23:59:59';


/* Number of selected days */

$selectedStart = new DateTime($fromDate);
$selectedEnd   = new DateTime($toDate);

$selectedDays = $selectedStart->diff($selectedEnd)->days + 1;


/* ============================================================
   INITIAL DATA
   ============================================================ */

$summary = [
    'units_sold'        => 0,
    'revenue'           => 0.0,
    'cost'              => 0.0,
    'net'               => 0.0,
    'orders'            => 0,
    'product_lines'     => 0,
    'average_order'     => 0.0,
    'average_daily'     => 0.0,
    'margin_pct'        => 0.0,
    'loss_units'        => 0,
    'loss_amount'       => 0.0,
    'loss_products'     => 0,
];

$dailyTrend = [];
$topSellers = [];
$lowStock   = [];
$lossSales  = [];


/* ============================================================
   1. OVERALL SALES SUMMARY
   ============================================================ */

$sql = "
SELECT
    COALESCE(SUM(sm.quantity), 0) AS units_sold,

    COALESCE(
        SUM(sm.quantity * p.product_price),
        0
    ) AS revenue,

    COALESCE(
        SUM(sm.quantity * p.product_cost),
        0
    ) AS cost,

    COUNT(DISTINCT sm.reference_no) AS orders,

    COUNT(DISTINCT sm.product_id) AS product_lines

FROM stock_movements sm

INNER JOIN table_product p
    ON p.product_id = sm.product_id

WHERE sm.transaction_type = 'OUT'
  AND sm.movement_date BETWEEN ? AND ?
";

$result = executeQuery(
    $conn,
    $sql,
    "ss",
    [$rangeStart, $rangeEnd]
);

if ($result && ($row = mysqli_fetch_assoc($result))) {

    $summary['units_sold'] =
        (float) $row['units_sold'];

    $summary['revenue'] =
        (float) $row['revenue'];

    $summary['cost'] =
        (float) $row['cost'];

    $summary['orders'] =
        (int) $row['orders'];

    $summary['product_lines'] =
        (int) $row['product_lines'];
}


/* ============================================================
   CALCULATED VALUES
   SAME LOGIC AS PERFORMANCE SALES
   ============================================================ */

$summary['net'] =
    $summary['revenue'] - $summary['cost'];

$summary['average_order'] =
    $summary['orders'] > 0
        ? $summary['revenue'] / $summary['orders']
        : 0;

$summary['average_daily'] =
    $selectedDays > 0
        ? $summary['revenue'] / $selectedDays
        : 0;

$summary['margin_pct'] =
    $summary['revenue'] > 0
        ? ($summary['net'] / $summary['revenue']) * 100
        : 0;

$isProfit =
    $summary['net'] >= 0;


/* ============================================================
   2. DAILY SALES TREND
   ============================================================ */

$sql = "
    SELECT
        DATE(sm.movement_date) AS sale_date,

        COALESCE(SUM(sm.quantity), 0) AS units,

        COALESCE(
            SUM(sm.quantity * p.product_price),
            0
        ) AS revenue,

        COALESCE(
            SUM(sm.quantity * p.product_cost),
            0
        ) AS cost

    FROM stock_movements sm

    INNER JOIN table_product p
        ON p.product_id = sm.product_id

    WHERE sm.transaction_type = 'OUT'
      AND sm.movement_date BETWEEN ? AND ?

    GROUP BY DATE(sm.movement_date)

    ORDER BY sale_date ASC
";

$result = executeQuery(
    $conn,
    $sql,
    "ss",
    [$rangeStart, $rangeEnd]
);

if ($result) {

    while ($row = mysqli_fetch_assoc($result)) {

        $dailyTrend[] = [
            'date'    => $row['sale_date'],
            'units'   => (float) $row['units'],
            'revenue' => (float) $row['revenue'],
            'cost'    => (float) $row['cost'],
            'profit'  => (float) $row['revenue'] - (float) $row['cost'],
        ];
    }
}


/* ============================================================
   3. TOP SELLERS
   ============================================================ */

$sql = "
    SELECT
        p.product_id,
        p.product_name,
        p.product_img_path,

        SUM(sm.quantity) AS units_sold,

        SUM(
            sm.quantity * p.product_price
        ) AS revenue

    FROM stock_movements sm

    INNER JOIN table_product p
        ON p.product_id = sm.product_id

    WHERE sm.transaction_type = 'OUT'
      AND sm.movement_date BETWEEN ? AND ?

    GROUP BY
        p.product_id,
        p.product_name,
        p.product_img_path

    ORDER BY units_sold DESC

    LIMIT 10
";

$result = executeQuery(
    $conn,
    $sql,
    "ss",
    [$rangeStart, $rangeEnd]
);

if ($result) {

    while ($row = mysqli_fetch_assoc($result)) {
        $topSellers[] = $row;
    }
}


/* Highest number of units among Top Sellers */

$maxUnits = 0;

foreach ($topSellers as $seller) {
    $maxUnits = max(
        $maxUnits,
        (float) $seller['units_sold']
    );
}


/* ============================================================
   4. LOW STOCK
   ============================================================ */

$sql = "
    SELECT
        product_id,
        product_name,
        product_quantity,
        product_rack,
        item_no

    FROM table_product

    WHERE product_availability = 1
      AND product_quantity <= ?

    ORDER BY product_quantity ASC

    LIMIT 15
";

$result = executeQuery(
    $conn,
    $sql,
    "i",
    [$threshold]
);

if ($result) {

    while ($row = mysqli_fetch_assoc($result)) {
        $lowStock[] = $row;
    }
}


/* ============================================================
   5. SALES BELOW COST
   ============================================================ */

$sql = "
    SELECT

        p.product_id,
        p.product_name,

        SUM(sm.quantity) AS units_sold,

        p.product_price,
        p.product_cost,

        SUM(
            sm.quantity *
            (p.product_cost - p.product_price)
        ) AS loss_amount

    FROM stock_movements sm

    INNER JOIN table_product p
        ON p.product_id = sm.product_id

    WHERE sm.transaction_type = 'OUT'
      AND sm.movement_date BETWEEN ? AND ?

      AND p.product_price < p.product_cost

    GROUP BY
        p.product_id,
        p.product_name,
        p.product_price,
        p.product_cost

    ORDER BY loss_amount DESC
";

$result = executeQuery(
    $conn,
    $sql,
    "ss",
    [$rangeStart, $rangeEnd]
);

if ($result) {

    while ($row = mysqli_fetch_assoc($result)) {

        $lossSales[] = $row;

        $summary['loss_units'] +=
            (float) $row['units_sold'];

        $summary['loss_amount'] +=
            (float) $row['loss_amount'];
    }

    $summary['loss_products'] = count($lossSales);
}


/* ============================================================
   CHART DATA
   ============================================================ */

$trendLabels  = [];
$trendRevenue = [];
$trendCost    = [];
$trendProfit  = [];
$trendUnits   = [];

foreach ($dailyTrend as $day) {

    $trendLabels[] =
        date('M j', strtotime($day['date']));

    $trendRevenue[] =
        round((float) $day['revenue'], 2);

    $trendCost[] =
        round((float) $day['cost'], 2);

    $trendProfit[] =
        round((float) $day['profit'], 2);

    $trendUnits[] =
        round((float) $day['units'], 2);
}


/* ============================================================
   PROFIT VISUALIZATION
   ============================================================ */

if ($summary['revenue'] > 0) {

    $profitRatio =
        ($summary['net'] / $summary['revenue']) * 100;

    $profitPosition =
        max(
            0,
            min(
                100,
                50 + ($profitRatio / 2)
            )
        );

} else {

    $profitPosition = 50;
}


/* ============================================================
   CLOSE CONNECTION
   ============================================================ */

mysqli_close($conn);

?>

<!-- =========================================================
     EXTERNAL LIBRARIES
========================================================= -->

<link
    rel="stylesheet"
    href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css"
>

<script
    src="https://code.jquery.com/jquery-3.7.1.min.js">
</script>

<script
    src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js">
</script>

<script
    src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js">
</script>


<style>

/* ============================================================
   DASHBOARD
   ============================================================ */

.sales-dashboard {
    --primary: #0d6efd;
    --success: #198754;
    --danger: #dc3545;
    --warning: #ffc107;
    --purple: #6f42c1;
    --orange: #fd7e14;

    --text: #212529;
    --muted: #6c757d;

    --border: #e9ecef;
    --soft: #f8f9fa;

    color: var(--text);
}


/* Main card */

.sales-dashboard .dashboard-shell {
    border: 0;
    border-radius: 16px;
    overflow: hidden;
    background: #fff;
}


/* ============================================================
   HEADER
   ============================================================ */

.sales-dashboard .dashboard-header {
    padding: 24px;
    background:
        linear-gradient(
            135deg,
            #ffffff 0%,
            #f8fbff 100%
        );
    border-bottom: 1px solid var(--border);
}

.sales-dashboard .dashboard-title {
    font-size: 23px;
    font-weight: 800;
    margin: 0;
}

.sales-dashboard .dashboard-subtitle {
    color: var(--muted);
    font-size: 13px;
    margin-top: 4px;
}


/* Refresh */

.sales-dashboard .refresh-btn {
    width: 42px;
    height: 42px;
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}


/* ============================================================
   FILTER PANEL
   ============================================================ */

.sales-dashboard .filter-panel {
    background: #fff;
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 18px;
    margin-top: 20px;
}

.sales-dashboard .filter-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .05em;
    font-weight: 700;
    color: var(--muted);
    margin-bottom: 6px;
}

.sales-dashboard .filter-control {
    min-height: 42px;
    border-radius: 9px;
}

.sales-dashboard .quick-range {
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
}


/* ============================================================
   KPI CARDS
   ============================================================ */

.sales-dashboard .kpi-card {
    position: relative;
    height: 100%;
    padding: 20px;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: #fff;
    overflow: hidden;
    transition:
        transform .2s ease,
        box-shadow .2s ease;
}

.sales-dashboard .kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0,0,0,.06);
}

.sales-dashboard .kpi-card::after {
    content: "";
    position: absolute;
    right: -22px;
    bottom: -28px;

    width: 90px;
    height: 90px;

    border-radius: 50%;
    opacity: .06;

    background: currentColor;
}

.sales-dashboard .kpi-card.revenue {
    color: var(--primary);
}

.sales-dashboard .kpi-card.cost {
    color: var(--orange);
}

.sales-dashboard .kpi-card.profit {
    color: var(--success);
}

.sales-dashboard .kpi-card.loss {
    color: var(--danger);
}

.sales-dashboard .kpi-card.units {
    color: var(--purple);
}

.sales-dashboard .kpi-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
}

.sales-dashboard .kpi-icon {
    width: 40px;
    height: 40px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 10px;
    background: currentColor;
    color: #fff;

    font-size: 18px;
}

.sales-dashboard .kpi-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .06em;
    color: var(--muted);
    font-weight: 700;
}

.sales-dashboard .kpi-value {
    color: var(--text);
    font-size: clamp(20px, 2vw, 28px);
    font-weight: 800;
    line-height: 1.2;
    margin-top: 14px;
    word-break: break-word;
}

.sales-dashboard .kpi-value.positive {
    color: var(--success);
}

.sales-dashboard .kpi-value.negative {
    color: var(--danger);
}

.sales-dashboard .kpi-footer {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    margin-top: 10px;
    color: var(--muted);
    font-size: 11px;
}


/* ============================================================
   SECTION CARDS
   ============================================================ */

.sales-dashboard .section-card {
    height: 100%;
    border: 1px solid var(--border);
    border-radius: 14px;
    background: #fff;
    overflow: hidden;
}

.sales-dashboard .section-header {
    padding: 16px 18px;
    border-bottom: 1px solid var(--border);
    background: #fff;
}

.sales-dashboard .section-title {
    font-size: 14px;
    font-weight: 800;
    margin: 0;
}

.sales-dashboard .section-subtitle {
    display: block;
    color: var(--muted);
    font-size: 11px;
    margin-top: 3px;
}

.sales-dashboard .section-body {
    padding: 18px;
}


/* ============================================================
   PROFIT GAUGE
   ============================================================ */

.sales-dashboard .profit-summary {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.sales-dashboard .profit-number {
    font-size: 25px;
    font-weight: 800;
}

.sales-dashboard .profit-number.profit {
    color: var(--success);
}

.sales-dashboard .profit-number.loss {
    color: var(--danger);
}

.sales-dashboard .profit-badge {
    border-radius: 999px;
    padding: 7px 12px;
    font-size: 11px;
    font-weight: 700;
}

.sales-dashboard .profit-track {
    position: relative;
    height: 14px;
    margin-top: 18px;

    border-radius: 999px;
    background:
        linear-gradient(
            90deg,
            #dc3545 0%,
            #ffc107 50%,
            #198754 100%
        );

    box-shadow:
        inset 0 0 0 1px rgba(0,0,0,.08);
}

.sales-dashboard .profit-center {
    position: absolute;
    top: -5px;
    bottom: -5px;
    left: 50%;

    width: 2px;
    background: #212529;
    opacity: .7;
}

.sales-dashboard .profit-needle {
    position: absolute;
    top: -7px;

    width: 28px;
    height: 28px;

    border-radius: 50%;
    background: #fff;

    border: 4px solid #212529;

    transform: translateX(-50%);

    box-shadow: 0 3px 10px rgba(0,0,0,.18);

    transition: left .4s ease;
}


/* ============================================================
   BEST SELLERS
   ============================================================ */

.sales-dashboard .seller-row {
    display: flex;
    align-items: center;
    gap: 12px;

    padding: 11px 0;

    border-bottom: 1px solid #f1f3f5;
}

.sales-dashboard .seller-row:last-child {
    border-bottom: 0;
}

.sales-dashboard .seller-rank {
    width: 27px;
    text-align: center;

    font-size: 12px;
    font-weight: 800;

    color: #adb5bd;
}

.sales-dashboard .seller-rank.top {
    color: var(--primary);
}

.sales-dashboard .seller-thumb {
    width: 42px;
    height: 42px;

    flex: 0 0 42px;

    object-fit: cover;

    border-radius: 9px;

    background: #f1f3f5;
    border: 1px solid var(--border);
}

.sales-dashboard .seller-name {
    font-size: 13px;
    font-weight: 700;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sales-dashboard .seller-bar-track {
    height: 6px;
    margin-top: 6px;

    border-radius: 999px;

    background: #edf0f3;
    overflow: hidden;
}

.sales-dashboard .seller-bar-fill {
    height: 100%;

    border-radius: 999px;

    background:
        linear-gradient(
            90deg,
            #0d6efd,
            #4dabf7
        );

    transition: width .5s ease;
}

.sales-dashboard .seller-stat {
    min-width: 85px;
    text-align: right;
}


/* ============================================================
   LOW STOCK
   ============================================================ */

.sales-dashboard .stock-row {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 12px;

    padding: 11px 12px;

    margin-bottom: 8px;

    border: 1px solid var(--border);
    border-left: 4px solid var(--warning);

    border-radius: 10px;

    background: #fff;
}

.sales-dashboard .stock-row:last-child {
    margin-bottom: 0;
}

.sales-dashboard .stock-row.critical {
    border-left-color: var(--danger);
    background: #fff8f8;
}

.sales-dashboard .stock-name {
    font-size: 13px;
    font-weight: 700;
}

.sales-dashboard .stock-meta {
    color: var(--muted);
    font-size: 10px;
    margin-top: 2px;
}

.sales-dashboard .stock-qty {
    min-width: 42px;

    text-align: center;

    padding: 5px 8px;

    border-radius: 8px;

    font-size: 12px;
    font-weight: 800;

    background: #fff3cd;
    color: #856404;
}

.sales-dashboard .stock-row.critical .stock-qty {
    background: #f8d7da;
    color: var(--danger);
}


/* ============================================================
   CHART
   ============================================================ */

.sales-dashboard .chart-wrapper {
    position: relative;
    width: 100%;
    height: 330px;
}


/* ============================================================
   LOSS TABLE
   ============================================================ */

.sales-dashboard .loss-summary {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
}

.sales-dashboard .loss-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;

    padding: 6px 10px;

    border-radius: 999px;

    background: #fff1f2;
    color: var(--danger);

    font-size: 11px;
    font-weight: 700;
}

.sales-dashboard #lossTable {
    border-collapse: separate;
    border-spacing: 0;
}

.sales-dashboard #lossTable thead th {
    background: #f8f9fa;

    color: #495057;

    border-bottom: 1px solid var(--border);

    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.sales-dashboard #lossTable tbody td {
    vertical-align: middle;
    font-size: 13px;
}


/* DataTables */

.sales-dashboard .dataTables_wrapper {
    font-size: 12px;
}

.sales-dashboard .dataTables_filter input {
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 6px 10px;
}

.sales-dashboard .dataTables_paginate .paginate_button {
    border-radius: 6px !important;
}


/* ============================================================
   EMPTY STATES
   ============================================================ */

.sales-dashboard .empty-state {
    text-align: center;
    padding: 35px 15px;
    color: var(--muted);
}

.sales-dashboard .empty-icon {
    width: 48px;
    height: 48px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 10px;

    border-radius: 50%;

    background: #f1f3f5;

    font-size: 20px;
}


/* ============================================================
   RESPONSIVE
   ============================================================ */

@media (max-width: 767.98px) {

    .sales-dashboard .dashboard-header {
        padding: 16px;
    }

    .sales-dashboard .dashboard-title {
        font-size: 19px;
    }

    .sales-dashboard .filter-panel {
        padding: 14px;
    }

    .sales-dashboard .kpi-card {
        padding: 16px;
    }

    .sales-dashboard .kpi-value {
        font-size: 21px;
    }

    .sales-dashboard .seller-name {
        max-width: 140px;
    }

    .sales-dashboard .seller-stat {
        min-width: 65px;
    }

    .sales-dashboard .chart-wrapper {
        height: 260px;
    }

    .sales-dashboard .section-body {
        padding: 14px;
    }
}

</style>


<!-- =========================================================
     DASHBOARD
========================================================= -->

<div class="sales-dashboard">

    <div class="card shadow-sm mb-4 dashboard-shell">

        <!-- =====================================================
             HEADER
        ====================================================== -->

        <div class="dashboard-header">

            <div class="d-flex justify-content-between align-items-start gap-3">

                <div>

                    <h1 class="dashboard-title">
                        <i class="bi bi-bar-chart-line-fill text-primary me-2"></i>
                        Sales Dashboard
                    </h1>

                    <div class="dashboard-subtitle">
                        Monitor sales performance, profitability,
                        best sellers and inventory alerts.
                    </div>

                </div>

                <button
                    type="button"
                    onclick="refreshPage(this)"
                    class="btn btn-outline-primary refresh-btn"
                    title="Refresh dashboard"
                >
                    <i class="bi bi-arrow-clockwise"></i>
                </button>

            </div>
<?php
include __DIR__ . "/../database/connection.php";

$sql = "
SELECT product_name, product_img_path, product_quantity
FROM table_product
WHERE product_img_path IS NOT NULL
ORDER BY 
    CASE 
        WHEN product_quantity = 0 THEN 1
        WHEN product_quantity <= 5 THEN 2
        ELSE 3
    END,
    product_quantity ASC
LIMIT 5
";

$result = mysqli_query($conn, $sql);
?>

<div class="product-strip-wrapper">

  <div class="product-strip" id="productStrip">

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>

      <div class="product-item"
           data-name="<?= htmlspecialchars($row['product_name']) ?>"
           data-stock="<?= $row['product_quantity'] ?>">

        <img src="../<?= htmlspecialchars($row['product_img_path']) ?>">

        <div class="hover-info">
          <?= htmlspecialchars($row['product_name']) ?><br>
          Stock: <?= $row['product_quantity'] ?>
        </div>

      </div>

    <?php } ?>

  </div>

</div>

            <!-- =================================================
                 FILTER PANEL
            ================================================== -->

            <form
                method="GET"
                action="<?= e($_SERVER['PHP_SELF']) ?>"
                class="filter-panel"
                id="salesFilterForm"
            >

                <div class="row g-3">

                    <div class="col-lg-3 col-md-6">

                        <label class="filter-label">
                            From Date
                        </label>

                        <input
                            type="date"
                            name="from_date"
                            class="form-control filter-control"
                            value="<?= e($fromDate) ?>"
                            max="<?= e($today) ?>"
                        >

                    </div>


                    <div class="col-lg-3 col-md-6">

                        <label class="filter-label">
                            To Date
                        </label>

                        <input
                            type="date"
                            name="to_date"
                            class="form-control filter-control"
                            value="<?= e($toDate) ?>"
                            max="<?= e($today) ?>"
                        >

                    </div>


                    <div class="col-lg-3 col-md-6">

                        <label class="filter-label">
                            Low Stock Threshold
                        </label>

                        <input
                            type="number"
                            name="low_stock"
                            class="form-control filter-control"
                            min="0"
                            max="999999"
                            value="<?= (int) $threshold ?>"
                        >

                    </div>


                    <div class="col-lg-3 col-md-6 d-flex align-items-end">

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                            style="min-height:42px;border-radius:9px;"
                        >
                            <i class="bi bi-funnel-fill me-1"></i>
                            Apply Filters
                        </button>

                    </div>

                </div>


                <!-- Quick ranges -->

                <div class="d-flex flex-wrap gap-2 mt-3">

                    <span
                        class="text-muted small d-flex align-items-center me-1"
                    >
                        Quick range:
                    </span>

                    <button
                        type="button"
                        class="btn btn-sm btn-outline-secondary quick-range"
                        data-range="today"
                    >
                        Today
                    </button>

                    <button
                        type="button"
                        class="btn btn-sm btn-outline-secondary quick-range"
                        data-range="7"
                    >
                        Last 7 Days
                    </button>

                    <button
                        type="button"
                        class="btn btn-sm btn-outline-secondary quick-range"
                        data-range="30"
                    >
                        Last 30 Days
                    </button>

                    <button
                        type="button"
                        class="btn btn-sm btn-outline-secondary quick-range"
                        data-range="month"
                    >
                        This Month
                    </button>

                    <button
                        type="button"
                        class="btn btn-sm btn-outline-secondary quick-range"
                        data-range="year"
                    >
                        This Year
                    </button>

                </div>

            </form>

        </div>


        <!-- =====================================================
             BODY
        ====================================================== -->

        <div class="card-body p-3 p-lg-4" >


            <!-- =================================================
                 DATE RANGE INFO
            ================================================== -->

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">

                <div class="small text-muted">

                    <i class="bi bi-calendar3 me-1"></i>

                    <?= date('M j, Y', strtotime($fromDate)) ?>

                    <span class="mx-1">—</span>

                    <?= date('M j, Y', strtotime($toDate)) ?>

                </div>

                <div class="small text-muted">

                    <?= number_format($selectedDays) ?>
                    day<?= $selectedDays !== 1 ? 's' : '' ?>

                </div>

            </div>


            <!-- =================================================
                 KPI CARDS
            ================================================== -->

            <div class="row g-3 mb-4" style="display:none">

                <!-- Revenue -->

                <div class="col-xl-3 col-md-6">

                    <div class="kpi-card revenue">

                        <div class="kpi-top">

                            <div>

                                <div class="kpi-label">
                                    Revenue
                                </div>

                            </div>

                            <div class="kpi-icon">
                                <i class="bi bi-cash-stack"></i>
                            </div>

                        </div>

                        <div class="kpi-value">
                            <?= money($summary['revenue']) ?>
                        </div>

                        <div class="kpi-footer">

                            <span>
                                <?= number_format($summary['orders']) ?>
                                order<?= $summary['orders'] != 1 ? 's' : '' ?>
                            </span>

                            <span>
                                Avg <?= money($summary['average_order']) ?>
                            </span>

                        </div>

                    </div>

                </div>


                <!-- Cost -->

                <div class="col-xl-3 col-md-6">

                    <div class="kpi-card cost">

                        <div class="kpi-top">

                            <div>

                                <div class="kpi-label">
                                    Cost of Goods
                                </div>

                            </div>

                            <div class="kpi-icon">
                                <i class="bi bi-box-seam"></i>
                            </div>

                        </div>

                        <div class="kpi-value">
                            <?= money($summary['cost']) ?>
                        </div>

                        <div class="kpi-footer">

                            <span>
                                <?= formatQty($summary['units_sold']) ?>
                                units
                            </span>

                            <span>
                                COGS
                            </span>

                        </div>

                    </div>

                </div>


                <!-- Net -->

                <div class="col-xl-3 col-md-6">

                    <div class="kpi-card <?= $isProfit ? 'profit' : 'loss' ?>">

                        <div class="kpi-top">

                            <div>

                                <div class="kpi-label">
                                    <?= $isProfit ? 'Net Profit' : 'Net Loss' ?>
                                </div>

                            </div>

                            <div class="kpi-icon">

                                <i class="bi <?= $isProfit
                                    ? 'bi-graph-up-arrow'
                                    : 'bi-graph-down-arrow'
                                ?>"></i>

                            </div>

                        </div>

                        <div class="kpi-value <?= $isProfit
                            ? 'positive'
                            : 'negative'
                        ?>">

                            <?= money($summary['net']) ?>

                        </div>

                        <div class="kpi-footer">

                            <span>
                                <?= number_format($summary['margin_pct'], 1) ?>%
                                margin
                            </span>

                            <span>
                                <?= $isProfit ? 'Profitable' : 'Loss' ?>
                            </span>

                        </div>

                    </div>

                </div>


                <!-- Units -->

                <div class="col-xl-3 col-md-6">

                    <div class="kpi-card units">

                        <div class="kpi-top">

                            <div>

                                <div class="kpi-label">
                                    Units Sold
                                </div>

                            </div>

                            <div class="kpi-icon">
                                <i class="bi bi-basket3"></i>
                            </div>

                        </div>

                        <div class="kpi-value">

                            <?= formatQty($summary['units_sold']) ?>

                        </div>

                        <div class="kpi-footer">

                            <span>
                                <?= number_format($summary['product_lines']) ?>
                                product lines
                            </span>

                            <span>
                                <?= money($summary['average_daily']) ?>/day
                            </span>

                        </div>

                    </div>

                </div>

            </div>



            <!-- =================================================
                 SALES TREND
            ================================================== -->

            <div class="section-card mb-4">

                <div class="section-header">

                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                        <div>

                            <div class="section-title">

                                <i class="bi bi-graph-up-arrow text-primary me-2"></i>

                                Sales Performance

                            </div>

                            <span class="section-subtitle">
                                Revenue, cost and profit by day
                            </span>

                        </div>

                        <span class="badge bg-light text-dark border">

                            <?= number_format(count($dailyTrend)) ?>
                            active day<?= count($dailyTrend) != 1 ? 's' : '' ?>

                        </span>

                    </div>

                </div>

                <div class="section-body">

                    <?php if (empty($dailyTrend)): ?>

                        <div class="empty-state">

                            <div class="empty-icon">
                                <i class="bi bi-bar-chart"></i>
                            </div>

                            <div class="fw-semibold">
                                No sales data available
                            </div>

                            <div class="small">
                                There are no outbound sales within this date range.
                            </div>

                        </div>

                    <?php else: ?>

                        <div class="chart-wrapper">
                            <canvas id="salesTrendChart"></canvas>
                        </div>

                    <?php endif; ?>

                </div>

            </div>


            <!-- =================================================
                 BEST SELLERS + LOW STOCK
            ================================================== -->

            <div class="row g-3 mb-4">


                <!-- Best Sellers -->

                <div class="col-xl-7">

                    <div class="section-card">

                        <div class="section-header">

                            <div>

                                <div class="section-title">

                                    <i class="bi bi-trophy-fill text-warning me-2"></i>

                                    Best Sellers

                                </div>

                                <span class="section-subtitle">
                                    Top products ranked by units sold
                                </span>

                            </div>

                        </div>


                        <div class="section-body">

                            <?php if (empty($topSellers)): ?>

                                <div class="empty-state">

                                    <div class="empty-icon">
                                        <i class="bi bi-box"></i>
                                    </div>

                                    <div class="fw-semibold">
                                        No sales recorded
                                    </div>

                                    <div class="small">
                                        No outbound products were found in this period.
                                    </div>

                                </div>

                            <?php else: ?>

                                <?php foreach ($topSellers as $index => $seller): ?>

                                    <?php

                                    $sellerUnits =
                                        (float) $seller['units_sold'];

                                    $sellerPercent =
                                        $maxUnits > 0
                                            ? ($sellerUnits / $maxUnits) * 100
                                            : 0;

                                    ?>

                                    <div class="seller-row">

                                        <div class="seller-rank <?= $index < 3 ? 'top' : '' ?>">

                                            #<?= $index + 1 ?>

                                        </div>


                                        <img
                                            class="seller-thumb"
                                            src="<?= e(productImage($seller['product_img_path'])) ?>"
                                            alt="<?= e($seller['product_name']) ?>"
                                            loading="lazy"
                                            onerror="this.onerror=null;this.src='../img/no-image.png';"
                                        >


                                        <div class="flex-grow-1 min-w-0">

                                            <div
                                                class="seller-name"
                                                title="<?= e($seller['product_name']) ?>"
                                            >
                                                <?= e($seller['product_name']) ?>
                                            </div>

                                            <div class="seller-bar-track">

                                                <div
                                                    class="seller-bar-fill"
                                                    style="width:<?= round($sellerPercent, 1) ?>%;"
                                                ></div>

                                            </div>

                                        </div>


                                        <div class="seller-stat">

                                            <div class="fw-bold">
                                                <?= formatQty($sellerUnits) ?>
                                            </div>



                                        </div>

                                    </div>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>


                <!-- Low Stock -->

                <div class="col-xl-5">

                    <div class="section-card">

                        <div class="section-header">

                            <div>

                                <div class="section-title">

                                    <i class="bi bi-exclamation-triangle-fill text-danger me-2"></i>

                                    Low Stock Alerts

                                </div>

                                <span class="section-subtitle">

                                    <?= number_format(count($lowStock)) ?>
                                    item<?= count($lowStock) != 1 ? 's' : '' ?>
                                    at or below
                                    <?= number_format($threshold) ?>

                                </span>

                            </div>

                        </div>


                        <div class="section-body">

                            <?php if (empty($lowStock)): ?>

                                <div class="empty-state">

                                    <div
                                        class="empty-icon"
                                        style="background:#e8f5e9;color:#198754;"
                                    >
                                        <i class="bi bi-check-lg"></i>
                                    </div>

                                    <div class="fw-semibold">
                                        Stock looks healthy
                                    </div>

                                    <div class="small">
                                        No products are currently at or below the selected threshold.
                                    </div>

                                </div>

                            <?php else: ?>

                                <?php foreach ($lowStock as $stock): ?>

                                    <?php

                                    $stockQty =
                                        (float) $stock['product_quantity'];

                                    $critical =
                                        $stockQty <= max(
                                            1,
                                            intdiv($threshold, 2)
                                        );

                                    ?>

                                    <div class="stock-row <?= $critical ? 'critical' : '' ?>">

                                        <div class="min-w-0">

                                            <div
                                                class="stock-name text-truncate"
                                                title="<?= e($stock['product_name']) ?>"
                                            >
                                                <?= e($stock['product_name']) ?>
                                            </div>

                                            <div class="stock-meta">

                                                Rack:
                                                <?= e($stock['product_rack'] ?: '—') ?>

                                                <span class="mx-1">·</span>

                                                Item:
                                                <?= e($stock['item_no'] ?: '—') ?>

                                            </div>

                                        </div>


                                        <div class="stock-qty">

                                            <?= formatQty($stockQty) ?>

                                        </div>

                                    </div>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 ADDITIONAL SUMMARY
            ================================================== -->

            <div class="row g-3 mb-4">

                <div class="col-md-4">

                    <div class="section-card">

                        <div class="section-body">

                            <div class="text-muted small">
                                Average Order Value
                            </div>

                            <div class="fs-4 fw-bold mt-1">
                                <?= money($summary['average_order']) ?>
                            </div>

                            <div class="text-muted small mt-1">
                                Revenue ÷ orders
                            </div>

                        </div>

                    </div>

                </div>


                <div class="col-md-4">

                    <div class="section-card">

                        <div class="section-body">

                            <div class="text-muted small">
                                Average Daily Revenue
                            </div>

                            <div class="fs-4 fw-bold mt-1">
                                <?= money($summary['average_daily']) ?>
                            </div>

                            <div class="text-muted small mt-1">
                                Based on selected period
                            </div>

                        </div>

                    </div>

                </div>


                <div class="col-md-4">

                    <div class="section-card">

                        <div class="section-body">

                            <div class="text-muted small">
                                Product Lines Sold
                            </div>

                            <div class="fs-4 fw-bold mt-1">
                                <?= number_format($summary['product_lines']) ?>
                            </div>

                            <div class="text-muted small mt-1">
                                Unique products sold
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 SOLD BELOW COST
            ================================================== -->

            <div class="section-card">

                <div class="section-header">

                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                        <div>

                            <div class="section-title">

                                <i class="bi bi-arrow-down-circle-fill text-danger me-2"></i>

                                Sold Below Cost

                            </div>

                            <span class="section-subtitle">
                                Products where selling price is below current unit cost
                            </span>

                        </div>


                        <?php if (!empty($lossSales)): ?>

                            <div class="loss-summary">

                                <span class="loss-pill">

                                    <i class="bi bi-exclamation-circle"></i>

                                    <?= number_format($summary['loss_products']) ?>
                                    product<?= $summary['loss_products'] != 1 ? 's' : '' ?>

                                </span>

                                <span class="loss-pill">

                                    <?= money($summary['loss_amount']) ?> loss

                                </span>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>


                <div class="section-body">

                    <?php if (empty($lossSales)): ?>

                        <div class="empty-state">

                            <div
                                class="empty-icon"
                                style="background:#e8f5e9;color:#198754;"
                            >
                                <i class="bi bi-check-lg"></i>
                            </div>

                            <div class="fw-semibold">
                                No loss-making sales
                            </div>

                            <div class="small">
                                No products were sold below cost during this period.
                            </div>

                        </div>

                    <?php else: ?>

                        <div class="table-responsive">

                            <table
                                class="table table-hover align-middle mb-0"
                                id="lossTable"
                                width="100%"
                            >

                                <thead>

                                    <tr>

                                        <th>Product</th>

                                        <th class="text-end">
                                            Units
                                        </th>

                                        <th class="text-end">
                                            Selling Price
                                        </th>

                                        <th class="text-end">
                                            Cost
                                        </th>

                                        <th class="text-end">
                                            Loss
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                    <?php foreach ($lossSales as $loss): ?>

                                        <tr>

                                            <td>

                                                <div class="fw-semibold">
                                                    <?= e($loss['product_name']) ?>
                                                </div>

                                            </td>


                                            <td class="text-end">

                                                <?= formatQty($loss['units_sold']) ?>

                                            </td>


                                            <td class="text-end">

                                                <?= money($loss['product_price']) ?>

                                            </td>


                                            <td class="text-end">

                                                <?= money($loss['product_cost']) ?>

                                            </td>


                                            <td class="text-end">

                                                <span class="fw-bold text-danger">

                                                    -<?= money($loss['loss_amount']) ?>

                                                </span>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                </div>

            </div>


        </div>

    </div>

</div>


<script>

/* ============================================================
   SALES DASHBOARD JAVASCRIPT
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {


    /* ========================================================
       QUICK DATE FILTERS
       ======================================================== */

    const filterForm =
        document.getElementById('salesFilterForm');

    const fromInput =
        filterForm?.querySelector('[name="from_date"]');

    const toInput =
        filterForm?.querySelector('[name="to_date"]');


    function localDateString(date) {

        const year =
            date.getFullYear();

        const month =
            String(date.getMonth() + 1).padStart(2, '0');

        const day =
            String(date.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    }


    document
        .querySelectorAll('.quick-range')
        .forEach(function (button) {

            button.addEventListener('click', function () {

                if (!fromInput || !toInput) {
                    return;
                }

                const range =
                    button.dataset.range;

                const today =
                    new Date();

                today.setHours(
                    0,
                    0,
                    0,
                    0
                );

                let from =
                    new Date(today);


                if (range === 'today') {

                    from =
                        new Date(today);

                }

                else if (range === '7') {

                    from =
                        new Date(today);

                    from.setDate(
                        from.getDate() - 6
                    );

                }

                else if (range === '30') {

                    from =
                        new Date(today);

                    from.setDate(
                        from.getDate() - 29
                    );

                }

                else if (range === 'month') {

                    from =
                        new Date(
                            today.getFullYear(),
                            today.getMonth(),
                            1
                        );

                }

                else if (range === 'year') {

                    from =
                        new Date(
                            today.getFullYear(),
                            0,
                            1
                        );

                }


                fromInput.value =
                    localDateString(from);

                toInput.value =
                    localDateString(today);

                filterForm.submit();

            });

        });


    /* ========================================================
       DATE VALIDATION
       ======================================================== */

    if (filterForm) {

        filterForm.addEventListener(
            'submit',
            function (event) {

                if (
                    fromInput &&
                    toInput &&
                    fromInput.value &&
                    toInput.value &&
                    fromInput.value > toInput.value
                ) {

                    event.preventDefault();

                    alert(
                        'The From Date cannot be later than the To Date.'
                    );

                }

            }
        );

    }


    /* ========================================================
       DATA TABLE
       ======================================================== */

    if (
        window.jQuery &&
        $('#lossTable').length
    ) {

        $('#lossTable').DataTable({

            pageLength: 10,

            lengthChange: false,

            searching: true,

            ordering: true,

            info: true,

            autoWidth: false,

            order: [
                [4, 'desc']
            ],

            language: {

                search: '',

                searchPlaceholder:
                    'Search products...',

                emptyTable:
                    'No loss-making products found.',

                zeroRecords:
                    'No matching products found.',

                info:
                    'Showing _START_ to _END_ of _TOTAL_ products',

                infoEmpty:
                    'No products to display'

            }

        });

    }


    /* ========================================================
       SALES CHART
       ======================================================== */

    const chartElement =
        document.getElementById(
            'salesTrendChart'
        );


    if (
        chartElement &&
        typeof Chart !== 'undefined'
    ) {

        const labels =
            <?= json_encode(
                $trendLabels,
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES
            ) ?>;

        const revenue =
            <?= json_encode(
                $trendRevenue,
                JSON_NUMERIC_CHECK
            ) ?>;

        const cost =
            <?= json_encode(
                $trendCost,
                JSON_NUMERIC_CHECK
            ) ?>;

        const profit =
            <?= json_encode(
                $trendProfit,
                JSON_NUMERIC_CHECK
            ) ?>;


        new Chart(
            chartElement,
            {

                type: 'line',

                data: {

                    labels: labels,

                    datasets: [

                        {
                            label: 'Revenue',

                            data: revenue,

                            borderColor: '#0d6efd',

                            backgroundColor:
                                'rgba(13,110,253,.08)',

                            borderWidth: 2,

                            tension: .35,

                            fill: true,

                            pointRadius: 2,

                            pointHoverRadius: 5
                        },


                        {
                            label: 'Cost',

                            data: cost,

                            borderColor: '#fd7e14',

                            backgroundColor:
                                'rgba(253,126,20,.05)',

                            borderWidth: 2,

                            tension: .35,

                            fill: true,

                            pointRadius: 2,

                            pointHoverRadius: 5,

                            borderDash: [5, 4]
                        },


                        {
                            label: 'Profit',

                            data: profit,

                            borderColor: '#198754',

                            backgroundColor:
                                'transparent',

                            borderWidth: 2,

                            tension: .35,

                            fill: false,

                            pointRadius: 2,

                            pointHoverRadius: 5
                        }

                    ]

                },


                options: {

                    responsive: true,

                    maintainAspectRatio: false,

                    interaction: {

                        mode: 'index',

                        intersect: false

                    },


                    scales: {

                        x: {

                            grid: {

                                display: false

                            },

                            ticks: {

                                maxTicksLimit: 12,

                                font: {

                                    size: 10

                                }

                            }

                        },


                        y: {

                            beginAtZero: true,

                            grid: {

                                color:
                                    'rgba(0,0,0,.06)'

                            },

                            ticks: {

                                font: {

                                    size: 10

                                },

                                callback:
                                    function(value) {

                                        return '₱' +
                                            Number(value)
                                                .toLocaleString(
                                                    'en-PH',
                                                    {
                                                        maximumFractionDigits: 0
                                                    }
                                                );

                                    }

                            }

                        }

                    },


                    plugins: {

                        legend: {

                            position: 'bottom',

                            labels: {

                                usePointStyle: true,

                                pointStyle: 'circle',

                                padding: 18,

                                font: {

                                    size: 11

                                }

                            }

                        },


                        tooltip: {

                            backgroundColor:
                                'rgba(33,37,41,.94)',

                            padding: 12,

                            displayColors: true,

                            callbacks: {

                                label:
                                    function(context) {

                                        const value =
                                            Number(
                                                context.raw || 0
                                            );

                                        return ' ' +
                                            context.dataset.label +
                                            ': ₱' +
                                            value.toLocaleString(
                                                'en-PH',
                                                {
                                                    minimumFractionDigits: 2,
                                                    maximumFractionDigits: 2
                                                }
                                            );

                                    }

                            }

                        }

                    }

                }

            }

        );

    }

});


/* ============================================================
   REFRESH BUTTON
   ============================================================ */

function refreshPage(button)
{
    if (!button) {
        window.location.reload();
        return;
    }

    const icon =
        button.querySelector('i');

    if (icon) {
        icon.classList.add('spin-refresh');
    }

    button.disabled = true;

    setTimeout(function () {

        window.location.reload();

    }, 150);

}


/* ============================================================
   REFRESH ANIMATION
   ============================================================ */

(function () {

    const style =
        document.createElement('style');

    style.textContent = `
        .spin-refresh {
            animation: salesRefreshSpin .7s linear infinite;
        }

        @keyframes salesRefreshSpin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }
    `;

    document.head.appendChild(style);

})();

</script>


<?php
include "SuperAdminFooters.php";
?>

