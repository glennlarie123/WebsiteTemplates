<?php
// includes/footer_bootstrap.php
// Closes all tags opened by header_bootstrap.php
?>

            </div><!-- /.container-fluid -->
        </main>
        
        <footer class="footer mt-auto footer-light py-3">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 small text-muted">JINFATS ENTERPRISES &copy; <?= date('Y') ?></div>
                    <div class="col-md-6 text-md-right small">
                        <span class="text-muted">Inventory Management System</span>
                    </div>
                </div>
            </div>
        </footer>
    </div><!-- /#layoutSidenav_content -->
</div><!-- /#layoutSidenav -->

<script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
<script>
(function($) {
    "use strict";
    $("#sidebarToggle").on("click", function(e) {
        e.preventDefault();
        $("body").toggleClass("sidenav-toggled");
    });
})(jQuery);

$(document).ready(function() {
    // Sizes a DataTable's internal scroll body to fill exactly the space
    // left between it and the footer, so the table scrolls internally
    // instead of the whole page scrolling.
    function fitTableScroll($table) {
        var $wrapper = $table.closest('.dataTables_wrapper');
        var $scrollBody = $wrapper.find('.dataTables_scrollBody');
        if (!$scrollBody.length) { return; }

        var windowHeight = $(window).height();
        var scrollBodyTop = $scrollBody.offset().top;

        // DataTables' own info/pagination row(s) below the scroll body
        var belowInWrapper = 0;
        $scrollBody.nextAll().each(function() {
            belowInWrapper += $(this).outerHeight(true);
        });

        // Anything after this table's card (e.g. products.php's own pagination)
        var $card = $table.closest('.card');
        var afterCard = 0;
        if ($card.length) {
            $card.nextAll().each(function() {
                afterCard += $(this).outerHeight(true);
            });
        }

        var footerHeight = $('footer.footer').outerHeight(true) || 0;
        var breathingRoom = 32; // card/container bottom padding, margins

        var available = windowHeight - scrollBodyTop - belowInWrapper - afterCard - footerHeight - breathingRoom;
        var finalHeight = Math.max(available, 220);
        $scrollBody.css({ height: finalHeight + 'px', maxHeight: finalHeight + 'px' });
    }

    $('.datatable').each(function() {
        var $table = $(this);
        $table.DataTable({
            pageLength: 10,
            lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
            language: { search: "", searchPlaceholder: "Search records..." },
            scrollY: '200px',   // placeholder height, immediately re-fit below
            scrollCollapse: true
        });

        // DataTables recalculates its own scroll geometry on every redraw
        // (search, sort, page change) which would otherwise undo our fixed
        // height, so re-apply it after each one.
        $table.on('draw.dt', function() { fitTableScroll($table); });
        fitTableScroll($table);
    });

    var resizeTimer;
    $(window).on('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            $('.datatable').each(function() { fitTableScroll($(this)); });
        }, 150);
    });
});
</script>
</body>
</html>