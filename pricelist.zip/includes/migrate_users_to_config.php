<?php
// tools/migrate_users_to_config.php
//
// ONE-TIME migration. Run this once, from the command line, on the server
// where the existing single-database app (and its .env / DB_* vars) still
// works: `php tools/migrate_users_to_config.php`
//
// It connects with the OLD db.php credentials, reads the existing
// table_user rows, and writes them into config/app_config.json --
// preserving each user's existing bcrypt password_hash exactly as-is
// (nobody's password changes). It also registers the current database as
// Store #1 in the new store registry.
//
// After running this and confirming login works, delete this script (or
// at least move it out of the web root) -- it has no auth of its own and
// isn't meant to be reachable over HTTP.

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die("This script is for command-line use only (php tools/migrate_users_to_config.php).\n");
}

require_once __DIR__ . '/../db.php';           // old single-DB connection ($pdo), still works pre-migration
require_once __DIR__ . '/../includes/store_db.php'; // save_app_config(), APP_CONFIG_PATH

if (file_exists(APP_CONFIG_PATH)) {
    fwrite(STDERR, "config/app_config.json already exists -- refusing to overwrite it.\n");
    fwrite(STDERR, "Delete or rename it first if you really want to re-run this migration.\n");
    exit(1);
}

$users_stmt = $pdo->query('SELECT user_id, user_username AS username, user_password AS password_hash, role, is_active FROM table_user');
$rows = $users_stmt->fetchAll();

if (!$rows) {
    fwrite(STDERR, "No rows found in table_user -- nothing to migrate. Aborting so nothing empty gets written.\n");
    exit(1);
}

$users = [];
foreach ($rows as $r) {
    $users[] = [
        'user_id'       => (int)$r['user_id'],
        'username'      => $r['username'],
        'password_hash' => $r['password_hash'], // already a bcrypt hash -- copied verbatim, unchanged
        'role'          => $r['role'],
        'is_active'     => (bool)((int)$r['is_active']),
    ];
}

$db_name = getenv('DB_NAME') ?: 'jw_inventory';

$config = [
    'users' => $users,
    'stores' => [
        [
            'store_id'   => 1,
            'store_name' => 'Store 1',
            'db_name'    => $db_name,
        ],
    ],
    'next_store_id' => 2,
];

save_app_config($config);

$count = count($users);
echo "Wrote config/app_config.json with {$count} user(s), migrated verbatim from table_user.\n";
echo "Registered the existing database ('{$db_name}') as Store 1.\n";
echo "Log in with your existing username/password -- nothing changed there.\n";
echo "You can rename \"Store 1\" by editing config/app_config.json directly.\n";
echo "\nWhen you've confirmed login works, delete or move this script out of the web root.\n";
