<?php

function _mysqli_conn($db) {
    return ($db instanceof MySQLiStore) ? $db->conn : $db;
}


/**
 * ============================================================
 * DAILY SALES
 * ============================================================
 *
 * Sales source:
 *   stock_movements + table_product
 *
 * Revenue:
 *   quantity × product_price
 *
 * Transactions:
 *   DISTINCT reference_no
 *
 */
function get_daily_sales($db, string $start, string $end): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT
            DATE(sm.movement_date) AS report_date,

            COUNT(DISTINCT sm.reference_no) AS transactions,

            COALESCE(
                SUM(sm.quantity * p.product_price),
                0
            ) AS net_income,

            COALESCE(
                SUM(sm.quantity),
                0
            ) AS items_sold,

            COALESCE(
                SUM(sm.quantity * p.product_price),
                0
            ) AS gross_sales,

            0 AS discounts_given

        FROM stock_movements sm

        JOIN table_product p
            ON sm.product_id = p.product_id

        WHERE sm.transaction_type = 'OUT'
          AND (sm.remarks IS NULL OR sm.remarks NOT LIKE 'LOSS:%')
          AND sm.movement_date >= ?
          AND sm.movement_date < DATE_ADD(?, INTERVAL 1 DAY)

        GROUP BY DATE(sm.movement_date)

        ORDER BY report_date DESC
    ");

    $stmt->bind_param('ss', $start, $end);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


/**
 * ============================================================
 * COST OF GOODS SOLD
 * ============================================================
 *
 * COGS:
 *   quantity × product_cost
 *
 */
function get_cogs($db, string $start, string $end): float {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT
            COALESCE(
                SUM(sm.quantity * p.product_cost),
                0
            )

        FROM stock_movements sm

        JOIN table_product p
            ON sm.product_id = p.product_id

        WHERE sm.transaction_type = 'OUT'
          AND (sm.remarks IS NULL OR sm.remarks NOT LIKE 'LOSS:%')
          AND sm.movement_date >= ?
          AND sm.movement_date < DATE_ADD(?, INTERVAL 1 DAY)
    ");

    $stmt->bind_param('ss', $start, $end);
    $stmt->execute();

    return (float)($stmt->get_result()->fetch_row()[0] ?? 0);
}


/**
 * ============================================================
 * MONTHLY SALES
 * ============================================================
 */
function get_monthly_sales($db, int $year): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT
            YEAR(sm.movement_date) AS yr,
            MONTH(sm.movement_date) AS mn,
            MONTHNAME(sm.movement_date) AS month_name,

            COUNT(DISTINCT sm.reference_no) AS transactions,

            COALESCE(
                SUM(sm.quantity * p.product_price),
                0
            ) AS net_income,

            COALESCE(
                SUM(sm.quantity * p.product_price),
                0
            ) AS gross_sales

        FROM stock_movements sm

        JOIN table_product p
            ON sm.product_id = p.product_id

        WHERE sm.transaction_type = 'OUT'
          AND (sm.remarks IS NULL OR sm.remarks NOT LIKE 'LOSS:%')
          AND YEAR(sm.movement_date) = ?

        GROUP BY
            YEAR(sm.movement_date),
            MONTH(sm.movement_date),
            MONTHNAME(sm.movement_date)

        ORDER BY
            YEAR(sm.movement_date),
            MONTH(sm.movement_date)
    ");

    $stmt->bind_param('i', $year);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


/**
 * ============================================================
 * SPENDING
 * ============================================================
 *
 * This remains based on inbound purchases because this is
 * inventory purchasing/spending, not sales.
 *
 */
function get_spending($db, string $start, string $end): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT
            DATE(ib.received_date) AS report_date,

            COUNT(DISTINCT ib.inbound_id) AS deliveries,

            SUM(iid.total_cost) AS total_spending,

            SUM(iid.quantity_received) AS units_received

        FROM inventory_inbound ib

        JOIN inventory_inbound_details iid
            ON ib.inbound_id = iid.inbound_id

        WHERE ib.status = 'Received'
          AND ib.received_date >= ?
          AND ib.received_date < DATE_ADD(?, INTERVAL 1 DAY)

        GROUP BY DATE(ib.received_date)

        ORDER BY report_date DESC
    ");

    $stmt->bind_param('ss', $start, $end);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


/**
 * ============================================================
 * LOSSES
 * ============================================================
 */
function get_losses($db, string $start, string $end): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT
            DATE(sm.movement_date) AS report_date,

            sm.remarks AS loss_reason,

            SUM(sm.quantity) AS units_lost,

            SUM(sm.quantity * p.product_cost) AS loss_amount

        FROM stock_movements sm

        JOIN table_product p
            ON sm.product_id = p.product_id

        WHERE sm.transaction_type = 'OUT'
          AND sm.remarks LIKE 'LOSS:%'
          AND sm.movement_date >= ?
          AND sm.movement_date < DATE_ADD(?, INTERVAL 1 DAY)

        GROUP BY
            DATE(sm.movement_date),
            sm.remarks

        ORDER BY report_date DESC
    ");

    $stmt->bind_param('ss', $start, $end);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


/**
 * ============================================================
 * PROFIT / LOSS SNAPSHOT
 * ============================================================
 *
 * Revenue:
 *   stock_movements OUT × product_price
 *
 * Spending:
 *   inventory inbound
 *
 * Loss:
 *   stock_movements LOSS × product_cost
 *
 */
function get_pl_snapshot($db, int $year): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT

            m.yr,
            m.mn,
            m.month_name,

            m.net_income,

            COALESCE(
                sp.total_spending,
                0
            ) AS total_spending,

            COALESCE(
                ls.total_loss,
                0
            ) AS total_loss,

            (
                m.net_income
                - COALESCE(sp.total_spending, 0)
                - COALESCE(ls.total_loss, 0)
            ) AS net_profit

        FROM (

            SELECT

                YEAR(sm.movement_date) AS yr,

                MONTH(sm.movement_date) AS mn,

                MONTHNAME(sm.movement_date) AS month_name,

                SUM(
                    sm.quantity * p.product_price
                ) AS net_income

            FROM stock_movements sm

            JOIN table_product p
                ON sm.product_id = p.product_id

            WHERE sm.transaction_type = 'OUT'

              AND (
                    sm.remarks IS NULL
                    OR sm.remarks NOT LIKE 'LOSS:%'
                  )

              AND YEAR(sm.movement_date) = ?

            GROUP BY
                YEAR(sm.movement_date),
                MONTH(sm.movement_date),
                MONTHNAME(sm.movement_date)

        ) m

        LEFT JOIN (

            SELECT

                YEAR(ib.received_date) AS yr,

                MONTH(ib.received_date) AS mn,

                SUM(iid.total_cost) AS total_spending

            FROM inventory_inbound ib

            JOIN inventory_inbound_details iid
                ON ib.inbound_id = iid.inbound_id

            WHERE ib.status = 'Received'

            GROUP BY
                YEAR(ib.received_date),
                MONTH(ib.received_date)

        ) sp

            ON m.yr = sp.yr
           AND m.mn = sp.mn

        LEFT JOIN (

            SELECT

                YEAR(sm.movement_date) AS yr,

                MONTH(sm.movement_date) AS mn,

                SUM(
                    sm.quantity * p.product_cost
                ) AS total_loss

            FROM stock_movements sm

            JOIN table_product p
                ON sm.product_id = p.product_id

            WHERE sm.transaction_type = 'OUT'
              AND sm.remarks LIKE 'LOSS:%'

            GROUP BY
                YEAR(sm.movement_date),
                MONTH(sm.movement_date)

        ) ls

            ON m.yr = ls.yr
           AND m.mn = ls.mn

        ORDER BY
            m.yr,
            m.mn
    ");

    $stmt->bind_param('i', $year);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


/**
 * ============================================================
 * TOP SELLERS
 * ============================================================
 */
function get_top_sellers(
    $db,
    int $year,
    int $month,
    int $limit = 10
): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT

            sm.product_id,

            p.product_name,

            SUM(sm.quantity) AS total_qty_sold,

            SUM(
                sm.quantity * p.product_price
            ) AS total_revenue

        FROM stock_movements sm

        JOIN table_product p
            ON sm.product_id = p.product_id

        WHERE sm.transaction_type = 'OUT'

          AND (
                sm.remarks IS NULL
                OR sm.remarks NOT LIKE 'LOSS:%'
              )

          AND YEAR(sm.movement_date) = ?
          AND MONTH(sm.movement_date) = ?

          AND p.product_name IS NOT NULL

        GROUP BY
            sm.product_id,
            p.product_name

        ORDER BY
            total_qty_sold DESC

        LIMIT ?
    ");

    $stmt->bind_param('iii', $year, $month, $limit);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}


/**
 * ============================================================
 * LOW SELLERS
 * ============================================================
 */
function get_low_sellers(
    $db,
    int $year,
    int $month,
    int $limit = 20
): array {

    $c = _mysqli_conn($db);

    $stmt = $c->prepare("
        SELECT

            p.product_id,

            p.product_name,

            COALESCE(
                SUM(sm.quantity),
                0
            ) AS total_qty_sold,

            COALESCE(
                SUM(
                    sm.quantity * p.product_price
                ),
                0.00
            ) AS total_revenue

        FROM table_product p

        LEFT JOIN stock_movements sm
            ON p.product_id = sm.product_id

            AND sm.transaction_type = 'OUT'

            AND (
                sm.remarks IS NULL
                OR sm.remarks NOT LIKE 'LOSS:%'
            )

            AND YEAR(sm.movement_date) = ?

            AND MONTH(sm.movement_date) = ?

        WHERE p.product_availability = 1

          AND p.product_name IS NOT NULL

        GROUP BY
            p.product_id,
            p.product_name

        ORDER BY
            total_qty_sold ASC,
            p.product_name

        LIMIT ?
    ");

    $stmt->bind_param('iii', $year, $month, $limit);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}