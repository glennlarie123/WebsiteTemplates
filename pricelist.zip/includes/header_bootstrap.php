
<?php
// includes/header_bootstrap.php
// DIONS HARDWARE — Main Bootstrap Layout
// Must be included AFTER auth_mysqli.php

$me = current_user();
$__active_store = function_exists('get_active_store') ? get_active_store() : null;
$nav_active = $active_nav ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?= htmlspecialchars($page_title ?? 'DIONS HARDWARE Portal') ?></title>

    <!-- Bootstrap -->
        <link rel="icon" type="image" href="img/dhlogo.png">
    
    <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        crossorigin="anonymous"
    >

    <!-- DataTables -->
    <link
        rel="stylesheet"
        href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"
        crossorigin="anonymous"
    >

    <!-- Theme -->
    <link rel="stylesheet" href="assets/bootstrap-theme.css">

    <!-- Font Awesome -->
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js"
        crossorigin="anonymous">
    </script>

    <style>
        /* =========================================================
           DIONS HARDWARE — GLOBAL HEADER / SIDEBAR
           ========================================================= */

        :root {
            --jinfats-primary: #f59e0b;
            --jinfats-primary-dark: #d97706;
            --jinfats-sidebar: #111827;
            --jinfats-sidebar-soft: #1f2937;
            --jinfats-sidebar-hover: #273449;
            --jinfats-border: #334155;
            --jinfats-text: #e5e7eb;
            --jinfats-muted: #94a3b8;
            --jinfats-content: #0f172a;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            background: var(--jinfats-content);
        }

        /* =========================================================
           TOP NAVIGATION
           ========================================================= */

        .topnav {
            height: 64px;
            min-height: 64px;

            background:
                linear-gradient(
                    135deg,
                    #111827 0%,
                    #172033 55%,
                    #1e293b 100%
                ) !important;

            border-bottom: 1px solid rgba(255,255,255,0.07);
            box-shadow: 0 4px 18px rgba(0,0,0,0.18);

            z-index: 1030;
        }

        .topnav .navbar-brand {
            display: flex;
            align-items: center;

            height: 64px;
            padding: 0 22px;

            font-size: 0.95rem;
            font-weight: 800;
            letter-spacing: 0.08em;

            color: #ffffff !important;

            border-right: 1px solid rgba(255,255,255,0.06);
        }

        .topnav .navbar-brand::before {
            content: "";
            width: 4px;
            height: 25px;

            margin-right: 11px;

            border-radius: 10px;
            background: var(--jinfats-primary);
        }

        /* Sidebar toggle */

        #sidebarToggle {
            width: 42px;
            height: 42px;

            display: flex;
            align-items: center;
            justify-content: center;

            margin-left: 10px;

            border-radius: 10px !important;

            color: #cbd5e1 !important;
            background: transparent !important;

            transition:
                background .2s ease,
                color .2s ease,
                transform .2s ease;
        }

        #sidebarToggle:hover {
            color: #ffffff !important;
            background: rgba(255,255,255,0.08) !important;
            transform: translateY(-1px);
        }

        /* Active store */

        .topnav .store-link {
            display: inline-flex;
            align-items: center;

            padding: 7px 12px;

            color: #cbd5e1 !important;
            font-size: 0.82rem;

            border-radius: 8px;

            transition: all .2s ease;
        }

        .topnav .store-link:hover {
            color: #ffffff !important;
            background: rgba(255,255,255,0.06);
            text-decoration: none;
        }

        .topnav .store-link i {
            color: var(--jinfats-primary);
        }

        /* User button */

        .dropdown-user > a {
            width: 42px;
            height: 42px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 50% !important;

            color: #cbd5e1 !important;
            background: rgba(255,255,255,0.04) !important;

            transition: all .2s ease;
        }

        .dropdown-user > a:hover,
        .dropdown-user.show > a {
            color: #ffffff !important;
            background: rgba(245,158,11,0.15) !important;
        }

        .dropdown-user > a::after {
            display: none;
        }

        /* =========================================================
           USER DROPDOWN
           ========================================================= */

        .dropdown-user .dropdown-menu {
            min-width: 230px;

            margin-top: 10px;

            padding: 8px;

            background: #1e293b;

            border: 1px solid rgba(255,255,255,0.08) !important;
            border-radius: 12px;

            box-shadow:
                0 18px 45px rgba(0,0,0,0.35),
                0 4px 12px rgba(0,0,0,0.18);
        }

        .dropdown-user .dropdown-header {
            padding: 12px 13px;
        }

        .dropdown-user-details-name {
            color: #ffffff;
            font-weight: 700;
            font-size: 0.88rem;
        }

        .dropdown-user-details-email {
            margin-top: 2px;
            font-size: 0.75rem;
            color: var(--jinfats-muted) !important;
            text-transform: capitalize;
        }

        .dropdown-user .dropdown-divider {
            border-color: rgba(255,255,255,0.07);
        }

        .dropdown-user .dropdown-item {
            display: flex;
            align-items: center;

            padding: 9px 11px;

            color: #cbd5e1;

            border-radius: 8px;

            font-size: 0.84rem;

            transition: all .18s ease;
        }

        .dropdown-user .dropdown-item:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.07);
        }

        .dropdown-item-icon {
            width: 30px;

            margin-right: 7px;

            color: #94a3b8;
        }

        .dropdown-item:hover .dropdown-item-icon {
            color: var(--jinfats-primary);
        }

        /* =========================================================
           SIDEBAR
           ========================================================= */

        #layoutSidenav_nav {
            width: 250px;
        }

        .sidenav {
            width: 250px !important;

            background:
                linear-gradient(
                    180deg,
                    #111827 0%,
                    #0f172a 100%
                ) !important;

            border-right: 1px solid rgba(255,255,255,0.06);

            box-shadow:
                8px 0 30px rgba(0,0,0,0.12) !important;
        }

        .sidenav-menu {
            padding: 18px 12px;
        }

        .sidenav-menu-heading {
            padding: 14px 13px 7px;

            color: #64748b !important;

            font-size: 0.65rem;
            font-weight: 800;

            letter-spacing: 0.12em;
            text-transform: uppercase;
        }

        /* Navigation links */

        .sidenav .nav-link {
            position: relative;

            display: flex;
            align-items: center;

            min-height: 46px;

            margin: 3px 0;
            padding: 9px 12px;

            color: #94a3b8 !important;

            font-size: 0.84rem;
            font-weight: 500;

            border-radius: 9px;

            transition:
                color .2s ease,
                background .2s ease,
                transform .2s ease;
        }

        .sidenav .nav-link:hover {
            color: #ffffff !important;
            background: rgba(255,255,255,0.055);

            transform: translateX(2px);
        }

        /* Icons */

        .sidenav .nav-link-icon {
            width: 34px;
            min-width: 34px;

            display: flex;
            align-items: center;
            justify-content: center;

            margin-right: 5px;

            font-size: 0.9rem;

            color: #64748b;

            transition: color .2s ease;
        }

        .sidenav .nav-link:hover .nav-link-icon {
            color: #cbd5e1;
        }

        /* Active navigation */

        .sidenav .nav-link.active {
            color: #ffffff !important;

            background:
                linear-gradient(
                    90deg,
                    rgba(245,158,11,0.18),
                    rgba(245,158,11,0.07)
                );

            box-shadow:
                inset 0 0 0 1px rgba(245,158,11,0.08);
        }

        .sidenav .nav-link.active::before {
            content: "";

            position: absolute;
            left: 0;
            top: 8px;
            bottom: 8px;

            width: 3px;

            border-radius: 0 5px 5px 0;

            background: var(--jinfats-primary);

            box-shadow: 0 0 10px rgba(245,158,11,0.45);
        }

        .sidenav .nav-link.active .nav-link-icon {
            color: var(--jinfats-primary);
        }

        /* =========================================================
           SIDEBAR FOOTER
           ========================================================= */

        .sidenav-footer {
            padding: 15px 18px;

            background: rgba(0,0,0,0.12);

            border-top: 1px solid rgba(255,255,255,0.05);
        }

        .sidenav-footer-subtitle {
            margin-bottom: 3px;

            color: #64748b;

            font-size: 0.65rem;
            font-weight: 700;

            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        .sidenav-footer-title {
            overflow: hidden;

            color: #cbd5e1;

            font-size: 0.78rem;
            font-weight: 600;

            text-overflow: ellipsis;
            white-space: nowrap;
        }

        /* =========================================================
           CONTENT AREA
           ========================================================= */

        #layoutSidenav_content {
            min-width: 0;
        }

        #layoutSidenav_content main {
            min-height: calc(100vh - 64px);
        }

        .container-fluid {
            padding-left: 25px;
            padding-right: 25px;
        }

        /* =========================================================
           FLASH MESSAGE
           ========================================================= */

        .alert {
            border-radius: 10px;
            border-width: 1px;

            box-shadow: 0 5px 15px rgba(0,0,0,0.12);
        }

        /* =========================================================
           MOBILE
           ========================================================= */

        @media (max-width: 991.98px) {

            .topnav .navbar-brand {
                padding-left: 14px;
                padding-right: 14px;

                font-size: 0.82rem;
            }

            #layoutSidenav_nav {
                width: 250px;
            }

            .container-fluid {
                padding-left: 15px;
                padding-right: 15px;
            }
        }

        @media (max-width: 575.98px) {

            .topnav {
                height: 58px;
                min-height: 58px;
            }

            .topnav .navbar-brand {
                height: 58px;

                padding-left: 8px;
                padding-right: 8px;

                font-size: 0.72rem;
                letter-spacing: 0.04em;
            }

            .topnav .navbar-brand::before {
                width: 3px;
                height: 20px;

                margin-right: 7px;
            }

            #sidebarToggle {
                width: 38px;
                height: 38px;

                margin-left: 3px;
            }

            .dropdown-user > a {
                width: 38px;
                height: 38px;
            }

            .dropdown-user {
                margin-right: 4px !important;
            }

            #layoutSidenav_content main {
                min-height: calc(100vh - 58px);
            }
        }
    </style>
</head>

<body class="nav-fixed">

<!-- =========================================================
     TOP NAVIGATION
     ========================================================= -->
<nav class="topnav navbar navbar-expand shadow navbar-dark" id="sidenavAccordion">

    <a class="navbar-brand" href="index">
        
        DIONS HARDWARE
    </a>

    <button
        class="btn btn-icon btn-transparent-dark order-1 order-lg-0 mr-lg-2"
        id="sidebarToggle"
        type="button"
        aria-label="Toggle sidebar"
    >
        <i class="fas fa-bars"></i>
    </button>

    <?php if ($me): ?>

        <!-- Active Store -->
        <div class="form-inline mr-auto d-none d-lg-flex">

            <?php if ($__active_store): ?>

                <a
                    href="db_select"
                    class="store-link"
                    title="Switch store"
                >
                    <i class="fas fa-store mr-2"></i>
                    <?= htmlspecialchars($__active_store['store_name']) ?>
                    <i class="fas fa-random ml-2"
                       style="font-size:0.65rem;"></i>
                </a>

            <?php else: ?>

                <a
                    href="db_select"
                    class="store-link"
                >
                    <i class="fas fa-store-slash mr-2"></i>
                    No store selected
                    <span class="ml-1">→</span>
                </a>

            <?php endif; ?>

        </div>

        <!-- User Menu -->
        <ul class="navbar-nav align-items-center ml-auto">

            <li class="nav-item dropdown no-caret mr-3 dropdown-user">

                <a
                    class="btn btn-icon btn-transparent-dark dropdown-toggle"
                    id="navbarDropdownUser"
                    href="#"
                    role="button"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                    aria-label="User menu"
                >
                    <i class="fas fa-user-circle fa-lg"></i>
                </a>

                <div
                    class="dropdown-menu dropdown-menu-right border-0 shadow animated--fade-in-up"
                    aria-labelledby="navbarDropdownUser"
                >

                    <h6 class="dropdown-header d-flex align-items-center">

                        <div class="dropdown-user-details">

                            <div class="dropdown-user-details-name">
                                <?= htmlspecialchars($me['username']) ?>
                            </div>

                            <div class="dropdown-user-details-email">
                                <?= htmlspecialchars($me['role']) ?>
                            </div>

                        </div>

                    </h6>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item" href="logout.php">

                        <div class="dropdown-item-icon">
                            <i class="fas fa-sign-out-alt"></i>
                        </div>

                        Logout

                    </a>

                </div>

            </li>

        </ul>

    <?php endif; ?>

</nav>


<!-- =========================================================
     MAIN LAYOUT
     ========================================================= -->
<div id="layoutSidenav">

    <?php if ($me): ?>

    <!-- =====================================================
         SIDEBAR
         ===================================================== -->
    <div id="layoutSidenav_nav">

        <nav class="sidenav shadow-right sidenav-dark">

            <div class="sidenav-menu">

                <div class="nav accordion" id="accordionSidenav">

                    <!-- CORE -->
                    <div class="sidenav-menu-heading">
                        Core
                    </div>

                    <a
                        class="nav-link <?= $nav_active === 'dashboard' ? 'active' : '' ?>"
                        href="home.php"
                    >
                        <div class="nav-link-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        Dashboard
                    </a>

                    <a
                        class="nav-link <?= $nav_active === 'products' ? 'active' : '' ?>"
                        href="products.php"
                    >
                        <div class="nav-link-icon">
                            <i class="fas fa-boxes"></i>
                        </div>
                        Products
                    </a>

                    <a
                        class="nav-link <?= $nav_active === 'reports' ? 'active' : '' ?>"
                        href="reports.php"
                    >
                        <div class="nav-link-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        Reports
                    </a>


                    <?php if ($me['role'] === 'admin'): ?>

                        <!-- ADMINISTRATION -->
                        <div class="sidenav-menu-heading">
                            Administration
                        </div>

                        <a
                            class="nav-link <?= $nav_active === 'stores' ? 'active' : '' ?>"
                            href="stores.php"
                        >
                            <div class="nav-link-icon">
                                <i class="fas fa-store"></i>
                            </div>
                            Stores
                        </a>

                    <?php endif; ?>

                </div>

            </div>


            <!-- SIDEBAR FOOTER -->
            <div class="sidenav-footer">

                <div class="sidenav-footer-content">

                    <div class="sidenav-footer-subtitle">
                        Logged in as
                    </div>

                    <div class="sidenav-footer-title">
                        <?= htmlspecialchars($me['username']) ?>
                    </div>

                </div>

            </div>

        </nav>

    </div>

    <?php endif; ?>


    <!-- =====================================================
         CONTENT AREA
         ===================================================== -->
    <div id="layoutSidenav_content">

        <main>

            <div class="container-fluid mt-4">

                <!-- Flash Messages -->
                <?php if (!empty($_SESSION['flash'])): ?>

                    <div
                        class="alert alert-<?= htmlspecialchars($_SESSION['flash']['type']) === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show"
                        role="alert"
                    >

                        <?= htmlspecialchars($_SESSION['flash']['message']) ?>

                        <button
                            type="button"
                            class="close"
                            data-dismiss="alert"
                            aria-label="Close"
                        >
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>

                    <?php unset($_SESSION['flash']); ?>

                <?php endif; ?>