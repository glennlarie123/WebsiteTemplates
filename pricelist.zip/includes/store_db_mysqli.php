<?php
require_once __DIR__ . '/db_mysqli.php';
define('APP_CONFIG_PATH', __DIR__ . '/../config/app_config.json');
function app_config(): array {
    if (!file_exists(APP_CONFIG_PATH)) {
        http_response_code(500);
        die('Configuration file missing: config/app_config.json');
    }
    $raw = file_get_contents(APP_CONFIG_PATH);
    $decoded = json_decode((string)$raw, true);
    if (!is_array($decoded)) {
        http_response_code(500);
        die('Configuration file is corrupt (invalid JSON)');
    }
    return $decoded + ['users' => [], 'stores' => [], 'next_store_id' => 1];
}
function save_app_config(array $config): void {
    $dir = dirname(APP_CONFIG_PATH);
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
        throw new RuntimeException('Could not create config directory.');
    }
    $tmp = $dir . '/.app_config.json.tmp.' . bin2hex(random_bytes(4));
    $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new RuntimeException('Failed to encode configuration as JSON.');
    }
    if (file_put_contents($tmp, $json, LOCK_EX) === false) {
        throw new RuntimeException('Failed to write temporary configuration file.');
    }
    chmod($tmp, 0640);
    if (!rename($tmp, APP_CONFIG_PATH)) {
        @unlink($tmp);
        throw new RuntimeException('Failed to save configuration file.');
    }
}
function db_credentials(): array {
    return [
        'host' => getenv('DB_HOST') ?: 'localhost',
        'user' => getenv('DB_USER') ?: 'root',
        'pass' => getenv('DB_PASS') ?: '',
    ];
}
function connect_store_oop(string $db_name): MySQLiStore {
    return new MySQLiStore($db_name);
}
function connect_store_proc(string $db_name): mysqli {
    return db_connect_mysqli($db_name);
}
function connect_server_mysqli(): mysqli {
    $c = db_credentials();
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $mysqli = new mysqli($c['host'], $c['user'], $c['pass']);
    $mysqli->set_charset('utf8mb4');
    return $mysqli;
}
function create_database_if_missing(string $db_name): void {
    if (!preg_match('/^[a-zA-Z0-9_]{1,64}$/', $db_name)) {
        throw new InvalidArgumentException('Invalid database name: ' . $db_name);
    }
    $mysqli = connect_server_mysqli();
    $mysqli->query("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $mysqli->close();
}
function drop_database(string $db_name): void {
    if (!preg_match('/^[a-zA-Z0-9_]{1,64}$/', $db_name)) {
        throw new InvalidArgumentException('Invalid database name: ' . $db_name);
    }
    $mysqli = connect_server_mysqli();
    $mysqli->query("DROP DATABASE IF EXISTS `$db_name`");
    $mysqli->close();
}
function get_active_store(): ?array {
    if (empty($_SESSION['active_store_id'])) {
        return null;
    }
    $config = app_config();
    foreach ($config['stores'] as $s) {
        if ((int)$s['store_id'] === (int)$_SESSION['active_store_id']) {
            return $s;
        }
    }
    return null;
}
function require_active_store(): MySQLiStore {
    $store = get_active_store();
    if (!$store) {
        header('Location: db_select.php');
        exit;
    }
    try {
        return connect_store_oop($store['db_name']);
    } catch (mysqli_sql_exception $e) {
        error_log('Store DB connection failed (' . $store['db_name'] . '): ' . $e->getMessage());
        http_response_code(500);
        die("Could not connect to this store's database. Contact an admin.");
    }
}
function require_active_store_proc(): mysqli {
    $store = get_active_store();
    if (!$store) {
        header('Location: db_select.php');
        exit;
    }
    try {
        return connect_store_proc($store['db_name']);
    } catch (mysqli_sql_exception $e) {
        error_log('Store DB connection failed (' . $store['db_name'] . '): ' . $e->getMessage());
        http_response_code(500);
        die("Could not connect to this store's database. Contact an admin.");
    }
}
