<?php
// includes/user_repo.php
// Shared user-table queries. `table_user` is the single source of truth for
// accounts — see migration_003_unify_user_table.sql for why the old `users`
// table no longer exists.

// Used by both users.php and user_form.php to enforce the same rule: the last
// active admin can't be deleted, disabled, or demoted. Keeping one copy means
// the two screens can't drift apart on what "last admin" means.
function count_active_admins(PDO $pdo): int
{
    return (int)$pdo->query("SELECT COUNT(*) FROM table_user WHERE role = 'admin' AND is_active = 1")->fetchColumn();
}
