<?php
// products.php — product catalog, view/edit only.
// DEMONSTRATES PROCEDURAL MySQLi APPROACH via raw mysqli handle + helpers

require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_login();

require_once __DIR__ . '/includes/store_db_mysqli.php';

// ---------------------------------------------------------------------------
// PROCEDURAL APPROACH: acquire raw mysqli handle
// ---------------------------------------------------------------------------
$mysqli = require_active_store_proc();
$store = get_active_store();

// Search by product name
$search = trim($_GET['q'] ?? '');

// Category filter
$category_filter = $_GET['category'] ?? 'all';

if (
    $category_filter !== 'all' &&
    $category_filter !== 'none' &&
    !ctype_digit((string)$category_filter)
) {
    $category_filter = 'all';
}

// Sort whitelist
$sort_options = [
    'name_asc'   => 'p.product_name ASC',
    'name_desc'  => 'p.product_name DESC',
    'cost_asc'   => 'cost ASC',
    'cost_desc'  => 'cost DESC',
    'price_asc'  => 'price ASC',
    'price_desc' => 'price DESC',
];

$sort = $_GET['sort'] ?? 'name_asc';

if (!isset($sort_options[$sort])) {
    $sort = 'name_asc';
}


// ---------------------------------------------------------------------------
// Build WHERE clause
// ---------------------------------------------------------------------------

$where = 'p.product_name IS NOT NULL';

$params = [];
$types = '';

if ($category_filter === 'none') {

    $where .= ' AND p.category_id IS NULL';

} elseif ($category_filter !== 'all') {

    $where .= ' AND p.category_id = ?';

    $params[] = (int)$category_filter;
    $types .= 'i';
}

if ($search !== '') {

    $where .= ' AND p.product_name LIKE ?';

    $params[] = '%' . $search . '%';
    $types .= 's';
}


// ---------------------------------------------------------------------------
// Count total
// ---------------------------------------------------------------------------

$count_sql = "
    SELECT COUNT(*)
    FROM table_product p
    WHERE $where
";

if ($types) {

    $count_stmt = db_prepare_exec(
        $mysqli,
        $count_sql,
        $types,
        ...$params
    );

    $count_row = $count_stmt->fetch_row();

} else {

    $count_row = $mysqli
        ->query($count_sql)
        ->fetch_row();
}

$total_products = (int)$count_row[0];


// ---------------------------------------------------------------------------
// Pagination
// ---------------------------------------------------------------------------

$per_page = 100;

$total_pages = max(
    1,
    (int)ceil($total_products / $per_page)
);

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

if ($page < 1) {
    $page = 1;
}

if ($page > $total_pages) {
    $page = $total_pages;
}

$offset = ($page - 1) * $per_page;


// ---------------------------------------------------------------------------
// Fetch products
// ---------------------------------------------------------------------------

$sql = "
    SELECT
        p.product_id AS id,
        p.product_name AS name,
        p.item_no AS itemNo,
        COALESCE(p.product_cost, 0) AS cost,
        COALESCE(p.product_price, 0) AS price,
        c.category_name AS categoryName
    FROM table_product p
    LEFT JOIN table_category c
        ON p.category_id = c.category_id
    WHERE $where
    ORDER BY {$sort_options[$sort]}
    LIMIT $per_page
    OFFSET $offset
";

if ($types) {

    $products_res = db_prepare_exec(
        $mysqli,
        $sql,
        $types,
        ...$params
    );

} else {

    $products_res = $mysqli->query($sql);
}

$products = $products_res->fetch_all(MYSQLI_ASSOC);


// ---------------------------------------------------------------------------
// Categories
// ---------------------------------------------------------------------------

$categories = $mysqli
    ->query("
        SELECT
            category_id AS id,
            category_name AS name
        FROM table_category
        ORDER BY category_name
    ")
    ->fetch_all(MYSQLI_ASSOC);


// ---------------------------------------------------------------------------
// Uncategorized count
// ---------------------------------------------------------------------------

$uncategorized_count = (int)db_fetch_scalar(
    $mysqli,
    "
    SELECT COUNT(*)
    FROM table_product
    WHERE category_id IS NULL
      AND product_name IS NOT NULL
    "
);


// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

$page_title = 'Products · JINFATS ENTERPRISES';
$active_nav = 'products';

require __DIR__ . '/includes/header_bootstrap.php';
?>


<style>

```css
/* =========================================================
   JINFATS ENTERPRISES
   PRODUCT CATALOG — DARK GOLD BRAND THEME
   ========================================================= */

:root {
    --brand-gold: #d4a017;
    --brand-gold-light: #e3bb45;
    --brand-gold-soft: #b88912;
    --brand-gold-dark: #8f6908;

    --bg-main: #10110e;
    --bg-card: #161813;
    --bg-card-soft: #1b1d17;
    --bg-hover: #20221b;

    --border: rgba(255, 255, 255, .065);
    --border-gold: rgba(212, 160, 23, .18);

    --text-main: #f5f3eb;
    --text-soft: #d2cfc2;
    --text-muted: #969285;
    --text-dim: #68665c;

    --success: #59b982;
    --danger: #cf6259;

    --shadow:
        0 10px 30px rgba(0, 0, 0, .18);

    --shadow-heavy:
        0 16px 42px rgba(0, 0, 0, .30);
}


/* =========================================================
   PAGE
   ========================================================= */

.products-page {
    padding-bottom: 35px;

    color: var(--text-main);
}


/* =========================================================
   PAGE HEADER
   ========================================================= */

.products-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;

    gap: 20px;

    margin-bottom: 24px;
}

.products-title-wrapper {
    display: flex;
    align-items: center;

    gap: 14px;
}


/* Gold title icon */

.products-title-icon {
    position: relative;

    width: 48px;
    height: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    overflow: hidden;

    border-radius: 13px;

    background:
        linear-gradient(
            145deg,
            rgba(212, 160, 23, .16),
            rgba(212, 160, 23, .045)
        );

    border:
        1px solid rgba(212, 160, 23, .23);

    color: var(--brand-gold-light);

    font-size: 20px;

    box-shadow:
        0 8px 20px rgba(0, 0, 0, .18);
}

.products-title-icon::after {
    content: "";

    position: absolute;

    width: 60px;
    height: 60px;

    right: -30px;
    bottom: -35px;

    border-radius: 50%;

    background:
        rgba(212, 160, 23, .10);
}


/* Title */

.products-title {
    margin: 0;

    color: var(--text-main);

    font-size: 26px;
    font-weight: 750;

    letter-spacing: -.45px;
}

.products-subtitle {
    margin: 5px 0 0;

    color: var(--text-muted);

    font-size: 13px;
    line-height: 1.5;
}

.products-store {
    color: var(--brand-gold-light);

    font-weight: 700;
}


/* =========================================================
   SUMMARY CARDS
   ========================================================= */

.product-summary {
    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 14px;

    margin-bottom: 18px;
}

.product-summary-card {
    position: relative;

    min-height: 91px;

    overflow: hidden;

    padding: 17px 19px;

    border:
        1px solid var(--border);

    border-radius: 13px;

    background:
        linear-gradient(
            145deg,
            rgba(255, 255, 255, .035),
            rgba(255, 255, 255, .015)
        );

    box-shadow:
        0 6px 20px rgba(0, 0, 0, .12);

    transition:
        transform .2s ease,
        border-color .2s ease,
        background .2s ease;
}

.product-summary-card:hover {
    transform: translateY(-2px);

    border-color:
        rgba(212, 160, 23, .16);

    background:
        linear-gradient(
            145deg,
            rgba(212, 160, 23, .045),
            rgba(255, 255, 255, .015)
        );
}


/* Gold corner decoration */

.product-summary-card::after {
    content: "";

    position: absolute;

    width: 95px;
    height: 95px;

    right: -48px;
    bottom: -50px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(212, 160, 23, .13) 0%,
            rgba(212, 160, 23, .035) 45%,
            transparent 70%
        );
}

.product-summary-label {
    position: relative;
    z-index: 1;

    display: block;

    margin-bottom: 7px;

    color: var(--text-dim);

    font-size: 10px;
    font-weight: 800;

    letter-spacing: .75px;

    text-transform: uppercase;
}

.product-summary-value {
    position: relative;
    z-index: 1;

    color: var(--text-main);

    font-size: 23px;
    font-weight: 750;

    line-height: 1;
}


/* =========================================================
   FILTER CARD
   ========================================================= */

.product-filter-card {
    margin-bottom: 18px;

    overflow: hidden;

    border:
        1px solid var(--border);

    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            rgba(255, 255, 255, .032),
            rgba(255, 255, 255, .014)
        );

    box-shadow: var(--shadow);
}


/* Filter header */

.product-filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 14px 19px;

    border-bottom:
        1px solid rgba(255, 255, 255, .055);

    background:
        rgba(0, 0, 0, .08);
}

.product-filter-title {
    display: flex;
    align-items: center;

    gap: 9px;

    margin: 0;

    color: var(--text-soft);

    font-size: 13px;
    font-weight: 750;
}

.product-filter-title i {
    color: var(--brand-gold-light);
}

.product-filter-description {
    color: var(--text-dim);

    font-size: 11px;
}


/* Filter body */

.product-filter-body {
    padding: 16px 19px;
}

.product-filter-form {
    display: flex;
    align-items: center;

    flex-wrap: wrap;

    gap: 9px;
}


/* =========================================================
   SEARCH
   ========================================================= */

.product-search {
    width: 310px;
}

.product-search .input-group {
    width: 100%;
}

.product-search .form-control {
    height: 37px;

    border:
        1px solid var(--border);

    border-right: 0;

    border-radius: 8px 0 0 8px;

    background:
        rgba(0, 0, 0, .17);

    color: var(--text-soft);

    font-size: 12px;

    box-shadow: none;

    transition:
        border-color .18s ease,
        background .18s ease,
        box-shadow .18s ease;
}

.product-search .form-control::placeholder {
    color: var(--text-dim);
}

.product-search .form-control:focus {
    border-color:
        rgba(212, 160, 23, .38);

    background:
        rgba(0, 0, 0, .22);

    box-shadow:
        0 0 0 .15rem
        rgba(212, 160, 23, .065);
}

.product-search .input-group-append .btn {
    height: 37px;

    min-width: 42px;

    border:
        1px solid var(--border);

    border-radius: 0 8px 8px 0;

    color: var(--text-muted);

    background:
        rgba(255, 255, 255, .025);

    transition:
        color .18s ease,
        background .18s ease,
        border-color .18s ease;
}

.product-search .input-group-append .btn:hover {
    color: var(--brand-gold-light);

    background:
        rgba(212, 160, 23, .075);

    border-color:
        rgba(212, 160, 23, .18);
}


/* =========================================================
   FILTER SELECTS
   ========================================================= */

.product-filter-select {
    height: 37px;

    min-width: 180px;

    padding-left: 11px;
    padding-right: 30px;

    border:
        1px solid var(--border);

    border-radius: 8px;

    background-color:
        #171914;

    color: var(--text-soft);

    font-size: 12px;

    box-shadow: none;

    cursor: pointer;

    transition:
        border-color .18s ease,
        background .18s ease,
        box-shadow .18s ease;
}

.product-filter-select:hover {
    border-color:
        rgba(212, 160, 23, .18);
}

.product-filter-select:focus {
    border-color:
        rgba(212, 160, 23, .38);

    background-color:
        #191b15;

    color: var(--text-main);

    box-shadow:
        0 0 0 .15rem
        rgba(212, 160, 23, .065);
}

.product-filter-select option {
    background: #171914;
    color: var(--text-soft);
}


/* Clear button */

.product-clear-btn {
    height: 37px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    gap: 6px;

    padding:
        0 12px;

    border:
        1px solid rgba(207, 98, 89, .25);

    border-radius: 8px;

    color:
        #d88a83;

    background:
        rgba(207, 98, 89, .045);

    font-size: 11px;
    font-weight: 650;

    transition:
        background .18s ease,
        border-color .18s ease,
        color .18s ease,
        transform .18s ease;
}

.product-clear-btn:hover {
    color: #f0aaa4;

    background:
        rgba(207, 98, 89, .10);

    border-color:
        rgba(207, 98, 89, .38);

    transform:
        translateY(-1px);
}


/* =========================================================
   PRODUCTS TABLE CARD
   ========================================================= */

.products-table-card {
    overflow: hidden;

    border:
        1px solid var(--border);

    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            rgba(255, 255, 255, .032),
            rgba(255, 255, 255, .012)
        );

    box-shadow:
        var(--shadow-heavy);
}


/* =========================================================
   TABLE HEADER
   ========================================================= */

.products-table-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 15px 20px;

    border-bottom:
        1px solid rgba(255, 255, 255, .065);

    background:
        rgba(0, 0, 0, .08);
}

.products-table-title {
    display: flex;
    align-items: center;

    gap: 9px;

    margin: 0;

    color: var(--text-main);

    font-size: 14px;
    font-weight: 750;
}

.products-table-title i {
    color: var(--brand-gold-light);
}


/* Product count badge */

.products-count {
    display: inline-flex;
    align-items: center;

    min-height: 24px;

    padding:
        4px 10px;

    border-radius: 20px;

    background:
        rgba(212, 160, 23, .075);

    border:
        1px solid rgba(212, 160, 23, .14);

    color:
        var(--brand-gold-light);

    font-size: 10px;
    font-weight: 800;

    letter-spacing: .45px;
}


/* =========================================================
   TABLE
   ========================================================= */

.products-table {
    width: 100%;

    margin: 0;

    color: var(--text-soft);
}

.products-table thead th {
    padding:
        12px 20px;

    background:
        rgba(0, 0, 0, .13);

    border-top: 0;

    border-bottom:
        1px solid rgba(255, 255, 255, .07);

    color:
        var(--text-dim);

    font-size: 10px;
    font-weight: 800;

    letter-spacing: .65px;

    text-transform: uppercase;

    white-space: nowrap;
}

.products-table tbody td {
    padding:
        13px 20px;

    border-top:
        1px solid rgba(255, 255, 255, .042);

    color:
        var(--text-soft);

    font-size: 12px;

    vertical-align: middle;
}

.products-table tbody tr {
    position: relative;

    transition:
        background .18s ease;
}

.products-table tbody tr:hover {
    background:
        rgba(212, 160, 23, .025);
}

.products-table tbody tr:hover td {
    border-top-color:
        rgba(212, 160, 23, .07);
}


/* =========================================================
   SKU
   ========================================================= */

.product-sku {
    display: inline-flex;
    align-items: center;

    gap: 6px;

    min-height: 25px;

    padding:
        4px 8px;

    border-radius: 6px;

    background:
        rgba(212, 160, 23, .045);

    border:
        1px solid rgba(212, 160, 23, .10);

    color:
        var(--brand-gold-light);

    font-family:
        "SFMono-Regular",
        Consolas,
        "Liberation Mono",
        monospace;

    font-size: 10.5px;
    font-weight: 650;

    white-space: nowrap;
}

.product-sku i {
    color:
        var(--brand-gold-dark);

    font-size: 9px;
}


/* =========================================================
   PRODUCT NAME
   ========================================================= */

.product-name-wrapper {
    display: flex;
    align-items: center;

    gap: 10px;
}

.product-icon {
    width: 32px;
    height: 32px;

    flex: 0 0 32px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background:
        rgba(255, 255, 255, .035);

    border:
        1px solid rgba(255, 255, 255, .035);

    color:
        var(--text-dim);

    font-size: 12px;

    transition:
        color .18s ease,
        background .18s ease,
        border-color .18s ease;
}

.product-name-wrapper:hover .product-icon {
    color:
        var(--brand-gold-light);

    background:
        rgba(212, 160, 23, .065);

    border-color:
        rgba(212, 160, 23, .11);
}

.product-name-link {
    color:
        var(--text-soft) !important;

    font-size: 12px;
    font-weight: 650;

    text-decoration: none;

    transition:
        color .18s ease;
}

.product-name-link:hover {
    color:
        var(--brand-gold-light) !important;

    text-decoration: none;
}


/* =========================================================
   CATEGORY
   ========================================================= */

.product-category {
    display: inline-block;

    max-width: 220px;

    padding:
        5px 8px;

    overflow: hidden;

    border:
        1px solid rgba(255, 255, 255, .045);

    border-radius: 6px;

    background:
        rgba(255, 255, 255, .025);

    color:
        var(--text-muted);

    font-size: 10.5px;

    text-overflow: ellipsis;

    white-space: nowrap;
}


/* =========================================================
   PRICES
   ========================================================= */

.product-cost {
    color:
        var(--text-muted);

    font-variant-numeric:
        tabular-nums;
}

.product-price {
    color:
        var(--text-soft);

    font-weight: 650;

    font-variant-numeric:
        tabular-nums;
}

.product-sale-price {
    color:
        #75c894;

    font-weight: 750;

    font-variant-numeric:
        tabular-nums;
}


/* =========================================================
   EMPTY STATE
   ========================================================= */

.products-empty {
    padding:
        60px 20px;

    text-align: center;
}

.products-empty-icon {
    width: 60px;
    height: 60px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin:
        0 auto 15px;

    border-radius: 15px;

    background:
        rgba(255, 255, 255, .03);

    border:
        1px solid rgba(255, 255, 255, .045);

    color:
        var(--text-dim);

    font-size: 22px;
}

.products-empty-title {
    margin:
        0 0 6px;

    color:
        var(--text-soft);

    font-size: 14px;
    font-weight: 700;
}

.products-empty-text {
    margin: 0;

    color:
        var(--text-dim);

    font-size: 11px;
}


/* =========================================================
   PAGINATION
   ========================================================= */

.products-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 15px;

    margin-top: 14px;
}

.products-pagination-info {
    color:
        var(--text-dim);

    font-size: 11px;
}

.products-pagination-info strong {
    color:
        var(--text-muted);

    font-weight: 700;
}

.products-pagination .pagination {
    margin: 0;
}

.products-pagination .page-link {
    min-height: 32px;

    display: flex;
    align-items: center;
    justify-content: center;

    padding:
        5px 11px;

    border:
        1px solid rgba(255, 255, 255, .065);

    background:
        rgba(255, 255, 255, .025);

    color:
        var(--text-muted);

    font-size: 10px;

    transition:
        color .18s ease,
        background .18s ease,
        border-color .18s ease,
        transform .18s ease;
}

.products-pagination .page-link:hover {
    color:
        var(--brand-gold-light);

    background:
        rgba(212, 160, 23, .07);

    border-color:
        rgba(212, 160, 23, .16);

    transform:
        translateY(-1px);
}

.products-pagination .page-item.active .page-link {
    border-color:
        rgba(212, 160, 23, .22);

    background:
        rgba(212, 160, 23, .11);

    color:
        var(--brand-gold-light);

    font-weight: 750;
}


/* =========================================================
   MOBILE TABLE
   ========================================================= */

@media (max-width: 992px) {

    .products-header {
        flex-direction: column;
    }

    .product-summary {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }

    .product-search {
        width: 100%;
    }
}


@media (max-width: 768px) {

    .products-title {
        font-size: 22px;
    }

    .products-subtitle {
        font-size: 12px;
    }

    .product-summary {
        grid-template-columns: 1fr;
    }

    .product-filter-header {
        align-items: flex-start;

        flex-direction: column;

        gap: 5px;
    }

    .product-filter-form {
        align-items: stretch;

        flex-direction: column;
    }

    .product-search,
    .product-filter-select,
    .product-clear-btn {
        width: 100%;

        min-width: 0;
    }

    .products-table {
        min-width: 700px;
    }

    .products-table-header {
        padding:
            14px 15px;
    }

    .products-table thead th,
    .products-table tbody td {
        padding-left: 15px;
        padding-right: 15px;
    }

    .products-pagination {
        align-items: stretch;

        flex-direction: column;
    }

    .products-pagination nav {
        width: 100%;
    }

    .products-pagination .pagination {
        justify-content: center;
    }
}


@media (max-width: 480px) {

    .products-title-wrapper {
        gap: 10px;
    }

    .products-title-icon {
        width: 41px;
        height: 41px;

        font-size: 17px;
    }

    .products-title {
        font-size: 20px;
    }

    .products-subtitle {
        font-size: 11px;
    }

    .product-summary-card {
        min-height: 84px;

        padding:
            15px 16px;
    }

    .product-summary-value {
        font-size: 21px;
    }

    .product-filter-body {
        padding: 14px;
    }

    .products-table {
        min-width: 650px;
    }

    .products-table-header {
        padding:
            13px 14px;
    }
}


/* =========================================================
   SCROLLBAR
   ========================================================= */

.products-page .table-responsive::-webkit-scrollbar {
    height: 7px;
}

.products-page .table-responsive::-webkit-scrollbar-track {
    background:
        rgba(255, 255, 255, .02);
}

.products-page .table-responsive::-webkit-scrollbar-thumb {
    border-radius: 10px;

    background:
        rgba(212, 160, 23, .25);
}

.products-page .table-responsive::-webkit-scrollbar-thumb:hover {
    background:
        rgba(212, 160, 23, .40);
}
```


</style>


<div class="products-page">


    <!-- =====================================================
         PAGE HEADER
    ====================================================== -->

    <div class="products-header">

        <div class="products-title-wrapper">

            <div class="products-title-icon">
                <i class="fas fa-boxes"></i>
            </div>

            <div>

                <h2 class="products-title">
                    Product Catalog
                </h2>

                <p class="products-subtitle">
                    Browse and manage products for
                    <span class="products-store">
                        <?= htmlspecialchars($store['store_name'] ?? '—') ?>
                    </span>
                </p>

            </div>

        </div>

    </div>


    <!-- =====================================================
         SUMMARY
    ====================================================== -->

    <div class="product-summary">

        <div class="product-summary-card">

            <span class="product-summary-label">
                Total Products
            </span>

            <span class="product-summary-value">
                <?= number_format($total_products) ?>
            </span>

        </div>


        <div class="product-summary-card">

            <span class="product-summary-label">
                Categories
            </span>

            <span class="product-summary-value">
                <?= number_format(count($categories)) ?>
            </span>

        </div>


        <div class="product-summary-card">

            <span class="product-summary-label">
                Uncategorized
            </span>

            <span class="product-summary-value">
                <?= number_format($uncategorized_count) ?>
            </span>

        </div>

    </div>


    <!-- =====================================================
         FILTERS
    ====================================================== -->

    <div class="product-filter-card">

        <div class="product-filter-header">

            <h3 class="product-filter-title">
                <i class="fas fa-sliders-h"></i>
                Catalog Filters
            </h3>

            <span class="product-filter-description">
                Search, filter, and sort your products.
            </span>

        </div>


        <div class="product-filter-body">

            <form method="GET"
                  class="product-filter-form">


                <!-- Search -->

                <div class="product-search">

                    <div class="input-group">

                        <input type="text"
                               name="q"
                               class="form-control"
                               value="<?= htmlspecialchars($search) ?>"
                               placeholder="Search product name...">

                        <div class="input-group-append">

                            <button type="submit"
                                    class="btn btn-outline-light">

                                <i class="fas fa-search"></i>

                            </button>

                        </div>

                    </div>

                </div>


                <!-- Category -->

                <select name="category"
                        class="custom-select product-filter-select"
                        onchange="this.form.submit()">

                    <option value="all"
                        <?= $category_filter === 'all' ? 'selected' : '' ?>>
                        All Categories
                    </option>

                    <option value="none"
                        <?= $category_filter === 'none' ? 'selected' : '' ?>>
                        Uncategorized (<?= $uncategorized_count ?>)
                    </option>

                    <?php foreach ($categories as $c): ?>

                        <option value="<?= (int)$c['id'] ?>"
                            <?= (string)$category_filter === (string)$c['id'] ? 'selected' : '' ?>>

                            <?= htmlspecialchars($c['name']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>


                <!-- Sort -->

                <select name="sort"
                        class="custom-select product-filter-select"
                        onchange="this.form.submit()">

                    <option value="name_asc"
                        <?= $sort === 'name_asc' ? 'selected' : '' ?>>
                        Name (A–Z)
                    </option>

                    <option value="name_desc"
                        <?= $sort === 'name_desc' ? 'selected' : '' ?>>
                        Name (Z–A)
                    </option>

                    <option value="cost_asc"
                        <?= $sort === 'cost_asc' ? 'selected' : '' ?>>
                        Cost (Low–High)
                    </option>

                    <option value="cost_desc"
                        <?= $sort === 'cost_desc' ? 'selected' : '' ?>>
                        Cost (High–Low)
                    </option>

                    <option value="price_asc"
                        <?= $sort === 'price_asc' ? 'selected' : '' ?>>
                        Price (Low–High)
                    </option>

                    <option value="price_desc"
                        <?= $sort === 'price_desc' ? 'selected' : '' ?>>
                        Price (High–Low)
                    </option>

                </select>


                <!-- Clear -->

                <?php if (
                    $search !== '' ||
                    $category_filter !== 'all' ||
                    $sort !== 'name_asc'
                ): ?>

                    <a href="products.php"
                       class="btn btn-outline-danger product-clear-btn">

                        <i class="fas fa-times"></i>

                        Clear Filters

                    </a>

                <?php endif; ?>


            </form>

        </div>

    </div>


    <!-- =====================================================
         PRODUCTS TABLE
    ====================================================== -->

    <div class="products-table-card">


        <!-- Table Header -->

        <div class="products-table-header">

            <h3 class="products-table-title">

                <i class="fas fa-box-open"></i>

                Products

            </h3>

            <span class="products-count">

                <?= number_format($total_products) ?>

                PRODUCT<?= $total_products !== 1 ? 'S' : '' ?>

            </span>

        </div>


        <div class="table-responsive">

            <table class="table products-table datatable mb-0">

                <thead>

                    <tr>

                        <th>
                            SKU
                        </th>

                        <th>
                            Product Name
                        </th>

                        <th>
                            Category
                        </th>

                        <th class="text-right">
                            Base Cost
                        </th>

                        <th class="text-right">
                            Base Price
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php foreach ($products as $p): ?>

                        <tr>


                            <!-- SKU -->

                            <td>

                                <?php if ($p['itemNo'] !== null && $p['itemNo'] !== ''): ?>

                                    <span class="product-sku">

                                        <i class="fas fa-barcode"></i>

                                        <?= htmlspecialchars($p['itemNo']) ?>

                                    </span>

                                <?php else: ?>

                                    <span class="text-muted">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- Product -->

                            <td>

                                <div class="product-name-wrapper">

                                    <div class="product-icon">

                                        <i class="fas fa-box"></i>

                                    </div>

                                    <a href="product_form.php?id=<?= (int)$p['id'] ?>"
                                       class="product-name-link">

                                        <?= htmlspecialchars($p['name']) ?>

                                    </a>

                                </div>

                            </td>


                            <!-- Category -->

                            <td>

                                <?php if (!empty($p['categoryName'])): ?>

                                    <span class="product-category">

                                        <?= htmlspecialchars($p['categoryName']) ?>

                                    </span>

                                <?php else: ?>

                                    <span class="text-muted">
                                        Uncategorized
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- Cost -->

                            <td class="text-right">

                                <span class="product-cost">

                                    ₱<?= number_format($p['cost'], 2) ?>

                                </span>

                            </td>


                            <!-- Price -->

                            <td class="text-right">

                                <span class="product-sale-price">

                                    ₱<?= number_format($p['price'], 2) ?>

                                </span>

                            </td>


                        </tr>

                    <?php endforeach; ?>


                    <!-- Empty -->

                    <?php if (!$products): ?>

                        <tr>

                            <td colspan="5">

                                <div class="products-empty">

                                    <div class="products-empty-icon">

                                        <i class="fas fa-box-open"></i>

                                    </div>


                                    <?php if ($search !== ''): ?>

                                        <h4 class="products-empty-title">
                                            No products found
                                        </h4>

                                        <p class="products-empty-text">

                                            No products match
                                            "<strong><?= htmlspecialchars($search) ?></strong>".

                                        </p>

                                    <?php else: ?>

                                        <h4 class="products-empty-title">
                                            No products found
                                        </h4>

                                        <p class="products-empty-text">
                                            No products match the selected filters.
                                        </p>

                                    <?php endif; ?>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


    <!-- =====================================================
         PAGINATION
    ====================================================== -->

    <?php if ($total_pages > 1): ?>

        <?php

        $base_qs =
            'category=' . urlencode((string)$category_filter) .
            '&sort=' . urlencode($sort) .
            '&q=' . urlencode($search);

        $showing_start = $offset + 1;

        $showing_end = min(
            $offset + $per_page,
            $total_products
        );

        ?>


        <div class="products-pagination">


            <span class="products-pagination-info">

                Showing

                <strong>
                    <?= number_format($showing_start) ?>
                    –
                    <?= number_format($showing_end) ?>
                </strong>

                of

                <strong>
                    <?= number_format($total_products) ?>
                </strong>

                products

            </span>


            <nav>

                <ul class="pagination pagination-sm">


                    <?php if ($page > 1): ?>

                        <li class="page-item">

                            <a class="page-link"
                               href="?<?= $base_qs ?>&page=<?= $page - 1 ?>">

                                <i class="fas fa-chevron-left mr-1"></i>
                                Prev

                            </a>

                        </li>

                    <?php endif; ?>


                    <li class="page-item active">

                        <span class="page-link">

                            Page
                            <?= $page ?>
                            of
                            <?= $total_pages ?>

                        </span>

                    </li>


                    <?php if ($page < $total_pages): ?>

                        <li class="page-item">

                            <a class="page-link"
                               href="?<?= $base_qs ?>&page=<?= $page + 1 ?>">

                                Next
                                <i class="fas fa-chevron-right ml-1"></i>

                            </a>

                        </li>

                    <?php endif; ?>


                </ul>

            </nav>

        </div>

    <?php endif; ?>


</div>


<?php require __DIR__ . '/includes/footer_bootstrap.php'; ?>
