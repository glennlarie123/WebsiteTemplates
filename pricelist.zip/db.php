<?php
// includes/db_mysqli.php
// MySQLi replacement for db.php — dual OOP / Procedural API

// ---------------------------------------------------------------------------
// OOP: Connection manager class
// ---------------------------------------------------------------------------
class MySQLiStore {
    public mysqli $conn;
    private string $db_name;

    public function __construct(string $db_name) {
        if (!preg_match('/^[a-zA-Z0-9_]{1,64}$/', $db_name)) {
            throw new InvalidArgumentException('Invalid database name: ' . $db_name);
        }
        $this->db_name = $db_name;

        $host = getenv('DB_HOST') ?: 'jg5.861.mytemp.website';
        $user = getenv('DB_USER') ?: 'dions_pricelist';
        $pass = getenv('DB_PASS') ?: 'f0vpBs}!U2FZM*PL';

        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $this->conn = new mysqli($host, $user, $pass, $db_name);
        $this->conn->set_charset('utf8mb4');
    }

    /** OOP prepared query with spread params */
    public function prepared_query(string $sql, string $types, ...$params): mysqli_result {
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        return $stmt->get_result();
    }

    /** OOP scalar fetch (replaces PDO fetchColumn) */
    public function fetch_scalar(string $sql, string $types = '', ...$params) {
        if ($types === '') {
            $res = $this->conn->query($sql);
        } else {
            $res = $this->prepared_query($sql, $types, ...$params);
        }
        $row = $res->fetch_row();
        return $row[0] ?? null;
    }

    /** OOP fetch single row */
    public function fetch_row(string $sql, string $types = '', ...$params): ?array {
        $res = ($types === '') ? $this->conn->query($sql) : $this->prepared_query($sql, $types, ...$params);
        $row = $res->fetch_assoc();
        return $row ?: null;
    }

    /** OOP fetch all */
    public function fetch_all(string $sql, string $types = '', ...$params): array {
        $res = ($types === '') ? $this->conn->query($sql) : $this->prepared_query($sql, $types, ...$params);
        return $res->fetch_all(MYSQLI_ASSOC);
    }

    /** Raw query (procedural style via OOP object) */
    public function query(string $sql): mysqli_result {
        return $this->conn->query($sql);
    }

    /** Escape string */
    public function escape(string $str): string {
        return $this->conn->real_escape_string($str);
    }

    public function close(): void {
        $this->conn->close();
    }
}

// ---------------------------------------------------------------------------
// Procedural: Standalone helper functions (thin wrappers around mysqli)
// ---------------------------------------------------------------------------

/** Procedural: connect to a named database, returns raw mysqli handle */
function db_connect_mysqli(string $db_name): mysqli {
    $tmp = new MySQLiStore($db_name);
    return $tmp->conn; // return the raw handle; caller manages lifecycle
}

/** Procedural: prepare + execute + get_result */
function db_prepare_exec(mysqli $conn, string $sql, string $types, ...$params): mysqli_result {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    return $stmt->get_result();
}

/** Procedural: fetch single scalar */
function db_fetch_scalar(mysqli $conn, string $sql, string $types = '', ...$params) {
    $res = ($types === '') ? $conn->query($sql) : db_prepare_exec($conn, $sql, $types, ...$params);
    $row = $res->fetch_row();
    return $row[0] ?? null;
}

/** Procedural: fetch single associative row */
function db_fetch_row(mysqli $conn, string $sql, string $types = '', ...$params): ?array {
    $res = ($types === '') ? $conn->query($sql) : db_prepare_exec($conn, $sql, $types, ...$params);
    $row = $res->fetch_assoc();
    return $row ?: null;
}

/** Procedural: fetch all rows */
function db_fetch_all(mysqli $conn, string $sql, string $types = '', ...$params): array {
    $res = ($types === '') ? $conn->query($sql) : db_prepare_exec($conn, $sql, $types, ...$params);
    return $res->fetch_all(MYSQLI_ASSOC);
}

/** Procedural: escape */
function db_escape(mysqli $conn, string $str): string {
    return $conn->real_escape_string($str);
}