<?php
// db_select.php — store/tenant picker.

require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_login();

require_once __DIR__ . '/includes/store_db_mysqli.php';


/* =========================================================
   STORE SELECTION
   ========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'select_store'
) {

    verify_csrf();

    $store_id = (int)($_POST['store_id'] ?? 0);

    $config = app_config();

    $found = false;

    foreach ($config['stores'] as $s) {

        if ((int)$s['store_id'] === $store_id) {

            $found = true;
            break;
        }
    }

    if ($found) {

        $_SESSION['active_store_id'] = $store_id;

        header('Location: home.php');
        exit;
    }
}


$config = app_config();

$stores = $config['stores'];

$user = current_user();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1, shrink-to-fit=no"
    >

    <title>Select Store · DIONS HARDWARE</title>


    <!-- Bootstrap -->
    <link rel="icon" type="image" href="img/dhlogo.png">

    <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        crossorigin="anonymous"
    >


    <!-- Font Awesome -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        crossorigin="anonymous"
    >


    <link
        rel="stylesheet"
        href="assets/bootstrap-theme.css"
    >


    <style>

        /* =========================================================
           JINFATS STORE SELECTOR
           ========================================================= */

        :root {

            --primary: #fbbf24;
            --primary-dark: #d97706;

            --bg-dark: #020617;
            --bg-mid: #0f172a;

            --card: rgba(15, 23, 42, .90);

            --border: rgba(148, 163, 184, .18);

            --text: #f8fafc;
            --muted: #94a3b8;

        }


        * {
            box-sizing: border-box;
        }


        html,
        body {

            width: 100%;
            min-height: 100%;

        }


        body {

            margin: 0;

            min-height: 100vh;

            display: flex;

            align-items: center;
            justify-content: center;

            padding: 25px;

            color: var(--text);

            background:

                radial-gradient(
                    circle at 12% 18%,
                    rgba(251, 191, 36, .09),
                    transparent 30%
                ),

                radial-gradient(
                    circle at 88% 82%,
                    rgba(59, 130, 246, .08),
                    transparent 30%
                ),

                linear-gradient(
                    135deg,
                    #020617 0%,
                    #0f172a 50%,
                    #111827 100%
                );

            font-family:
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                Roboto,
                Arial,
                sans-serif;

            overflow-x: hidden;

        }


        /* =========================================================
           BACKGROUND ICONS
           ========================================================= */

        .background-icons {

            position: fixed;

            inset: 0;

            overflow: hidden;

            pointer-events: none;

            z-index: 0;

        }


        .floating-icon {

            position: absolute;

            color: rgba(251, 191, 36, .07);

            font-size: 44px;

            animation:
                floatIcon 15s infinite ease-in-out;

        }


        .floating-icon:nth-child(1) {

            left: 6%;
            top: 14%;

            animation-duration: 17s;

        }


        .floating-icon:nth-child(2) {

            left: 17%;
            top: 72%;

            font-size: 31px;

            animation-duration: 12s;

            animation-delay: -4s;

        }


        .floating-icon:nth-child(3) {

            left: 30%;
            top: 22%;

            font-size: 52px;

            animation-duration: 19s;

            animation-delay: -8s;

        }


        .floating-icon:nth-child(4) {

            left: 48%;
            top: 85%;

            font-size: 35px;

            animation-duration: 14s;

            animation-delay: -5s;

        }


        .floating-icon:nth-child(5) {

            left: 64%;
            top: 13%;

            font-size: 48px;

            animation-duration: 18s;

            animation-delay: -7s;

        }


        .floating-icon:nth-child(6) {

            left: 76%;
            top: 67%;

            font-size: 34px;

            animation-duration: 13s;

            animation-delay: -2s;

        }


        .floating-icon:nth-child(7) {

            left: 88%;
            top: 26%;

            font-size: 54px;

            animation-duration: 20s;

            animation-delay: -10s;

        }


        .floating-icon:nth-child(8) {

            left: 94%;
            top: 87%;

            font-size: 28px;

            animation-duration: 11s;

            animation-delay: -3s;

        }


        @keyframes floatIcon {

            0% {

                transform:
                    translate3d(0, 0, 0)
                    rotate(0deg);

            }

            25% {

                transform:
                    translate3d(20px, -30px, 0)
                    rotate(8deg);

            }

            50% {

                transform:
                    translate3d(-15px, -55px, 0)
                    rotate(-8deg);

            }

            75% {

                transform:
                    translate3d(25px, -25px, 0)
                    rotate(5deg);

            }

            100% {

                transform:
                    translate3d(0, 0, 0)
                    rotate(0deg);

            }

        }


        /* =========================================================
           BACKGROUND GLOW
           ========================================================= */

        .background-glow {

            position: fixed;

            width: 430px;
            height: 430px;

            border-radius: 50%;

            background:
                radial-gradient(
                    circle,
                    rgba(251, 191, 36, .07),
                    transparent 70%
                );

            filter: blur(15px);

            pointer-events: none;

            animation:
                glowMove 13s infinite alternate ease-in-out;

        }


        @keyframes glowMove {

            0% {

                transform:
                    translate(-200px, -100px);

            }

            100% {

                transform:
                    translate(200px, 130px);

            }

        }


        /* =========================================================
           MAIN WRAPPER
           ========================================================= */

        .store-wrapper {

            position: relative;

            z-index: 10;

            width: 100%;

            max-width: 580px;

            animation:
                pageAppear .65s ease-out;

        }


        @keyframes pageAppear {

            from {

                opacity: 0;

                transform:
                    translateY(25px)
                    scale(.98);

            }

            to {

                opacity: 1;

                transform:
                    translateY(0)
                    scale(1);

            }

        }


        /* =========================================================
           MAIN CARD
           ========================================================= */

        .picker-card {

            position: relative;

            width: 100%;

            padding: 34px;

            background:
                linear-gradient(
                    145deg,
                    rgba(30, 41, 59, .94),
                    rgba(15, 23, 42, .94)
                );

            border:

                1px solid
                var(--border);

            border-radius: 20px;

            box-shadow:

                0 35px 80px
                rgba(0,0,0,.45),

                0 0 0 1px
                rgba(255,255,255,.015);

            backdrop-filter:
                blur(18px);

            -webkit-backdrop-filter:
                blur(18px);

            overflow: hidden;

        }


        .picker-card::before {

            content: "";

            position: absolute;

            left: 0;
            top: 0;

            width: 100%;
            height: 3px;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    var(--primary),
                    transparent
                );

        }


        /* =========================================================
           HEADER
           ========================================================= */

        .picker-header {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 20px;

            margin-bottom: 25px;

        }


        .brand-area {

            display: flex;

            align-items: center;

            gap: 13px;

            min-width: 0;

        }


        .brand-icon {

            flex: 0 0 auto;

            width: 52px;
            height: 52px;

            display: flex;

            align-items: center;
            justify-content: center;

            color: #111827;

            background:
                linear-gradient(
                    135deg,
                    #fbbf24,
                    #f59e0b
                );

            border-radius: 14px;

            font-size: 21px;

            box-shadow:
                0 8px 25px
                rgba(245,158,11,.20);

            animation:
                iconPulse 3s infinite ease-in-out;

        }


        @keyframes iconPulse {

            0%,
            100% {

                transform:
                    translateY(0);

            }

            50% {

                transform:
                    translateY(-4px);

            }

        }


        .brand-name {

            margin: 0;

            color: #fff;

            font-size: 1.12rem;

            font-weight: 800;

            letter-spacing: .08em;

        }


        .brand-label {

            margin-top: 3px;

            color: var(--muted);

            font-size: .70rem;

            text-transform: uppercase;

            letter-spacing: .08em;

        }


        /* =========================================================
           LOGOUT BUTTON
           ========================================================= */

        .logout-btn {

            flex: 0 0 auto;

            display: inline-flex;

            align-items: center;

            gap: 7px;

            color: #94a3b8;

            background:
                rgba(2,6,23,.45);

            border:
                1px solid
                rgba(148,163,184,.18);

            border-radius: 9px;

            padding:
                8px 11px;

            font-size: .72rem;

            transition:
                all .2s ease;

        }


        .logout-btn:hover {

            color: #f87171;

            background:
                rgba(127,29,29,.15);

            border-color:
                rgba(248,113,113,.25);

            text-decoration: none;

            transform:
                translateY(-1px);

        }


        /* =========================================================
           INTRO
           ========================================================= */

        .intro {

            padding:

                14px 16px;

            margin-bottom: 22px;

            color: #94a3b8;

            background:
                rgba(2,6,23,.28);

            border:
                1px solid
                rgba(148,163,184,.10);

            border-radius: 11px;

            font-size: .78rem;

            line-height: 1.6;

        }


        .intro i {

            margin-right: 7px;

            color: var(--primary);

        }


        /* =========================================================
           STORE SECTION
           ========================================================= */

        .section-title {

            display: flex;

            align-items: center;

            justify-content: space-between;

            margin-bottom: 11px;

        }


        .section-title-left {

            display: flex;

            align-items: center;

            gap: 8px;

            color: #e2e8f0;

            font-size: .78rem;

            font-weight: 700;

            text-transform: uppercase;

            letter-spacing: .06em;

        }


        .section-title-left i {

            color: var(--primary);

        }


        .store-count {

            color: #64748b;

            font-size: .68rem;

        }


        /* =========================================================
           STORE BUTTON
           ========================================================= */

        .store-list {

            display: flex;

            flex-direction: column;

            gap: 9px;

        }


        .store-btn {

            position: relative;

            width: 100%;

            min-height: 65px;

            display: flex;

            align-items: center;

            gap: 14px;

            padding:
                10px 14px;

            color: #f8fafc;

            background:
                linear-gradient(
                    135deg,
                    rgba(2,6,23,.65),
                    rgba(15,23,42,.55)
                );

            border:
                1px solid
                #334155;

            border-radius: 11px;

            text-align: left;

            cursor: pointer;

            overflow: hidden;

            transition:
                transform .2s ease,
                border-color .2s ease,
                background .2s ease,
                box-shadow .2s ease;

        }


        .store-btn::after {

            content: "";

            position: absolute;

            left: -100%;

            top: 0;

            width: 60%;
            height: 100%;

            background:
                linear-gradient(
                    90deg,
                    transparent,
                    rgba(255,255,255,.05),
                    transparent
                );

            transform:
                skewX(-20deg);

            transition:
                left .5s ease;

        }


        .store-btn:hover {

            color: #ffffff;

            border-color:
                rgba(251,191,36,.65);

            background:
                linear-gradient(
                    135deg,
                    rgba(251,191,36,.08),
                    rgba(15,23,42,.70)
                );

            transform:
                translateX(4px);

            box-shadow:
                0 7px 22px
                rgba(0,0,0,.20);

        }


        .store-btn:hover::after {

            left: 130%;

        }


        /* Store icon */

        .store-icon {

            flex: 0 0 auto;

            width: 39px;
            height: 39px;

            display: flex;

            align-items: center;
            justify-content: center;

            color: #fbbf24;

            background:
                rgba(251,191,36,.08);

            border:
                1px solid
                rgba(251,191,36,.12);

            border-radius: 9px;

            font-size: .88rem;

            transition:
                all .2s ease;

        }


        .store-btn:hover .store-icon {

            color: #111827;

            background:
                var(--primary);

            border-color:
                var(--primary);

            transform:
                scale(1.05);

        }


        .store-info {

            min-width: 0;

            flex: 1;

        }


        .store-name {

            display: block;

            color: #f8fafc;

            font-size: .86rem;

            font-weight: 700;

            white-space: nowrap;

            overflow: hidden;

            text-overflow: ellipsis;

        }


        .store-description {

            display: block;

            margin-top: 3px;

            color: #64748b;

            font-size: .68rem;

        }


        .store-arrow {

            flex: 0 0 auto;

            color: #475569;

            transition:
                transform .2s ease,
                color .2s ease;

        }


        .store-btn:hover .store-arrow {

            color: var(--primary);

            transform:
                translateX(4px);

        }


        /* =========================================================
           EMPTY STATE
           ========================================================= */

        .empty-state {

            padding: 35px 20px;

            text-align: center;

            background:
                rgba(2,6,23,.28);

            border:
                1px dashed
                #334155;

            border-radius: 12px;

        }


        .empty-icon {

            width: 55px;
            height: 55px;

            margin:
                0 auto 13px;

            display: flex;

            align-items: center;
            justify-content: center;

            color: #64748b;

            background:
                rgba(100,116,139,.08);

            border-radius: 50%;

            font-size: 20px;

        }


        .empty-title {

            margin-bottom: 5px;

            color: #cbd5e1;

            font-size: .85rem;

            font-weight: 700;

        }


        .empty-text {

            margin-bottom: 0;

            color: #64748b;

            font-size: .72rem;

        }


        /* =========================================================
           CREATE STORE BUTTON
           ========================================================= */

        .create-store-btn {

            width: 100%;

            height: 45px;

            display: flex;

            align-items: center;
            justify-content: center;

            gap: 8px;

            margin-top: 13px;

            color: #111827;

            background:
                linear-gradient(
                    135deg,
                    #fbbf24,
                    #f59e0b
                );

            border: none;

            border-radius: 9px;

            font-size: .76rem;

            font-weight: 800;

            letter-spacing: .03em;

            transition:
                transform .2s ease,
                box-shadow .2s ease;

        }


        .create-store-btn:hover {

            color: #111827;

            text-decoration: none;

            transform:
                translateY(-2px);

            box-shadow:
                0 10px 25px
                rgba(245,158,11,.22);

        }


        /* =========================================================
           FOOTER
           ========================================================= */

        .security-note {

            display: flex;

            align-items: center;
            justify-content: center;

            gap: 6px;

            margin-top: 21px;

            color: #475569;

            font-size: .66rem;

        }


        .security-note i {

            color: #22c55e;

        }


        .copyright {

            margin-top: 14px;

            color: #334155;

            font-size: .63rem;

            text-align: center;

        }


        /* =========================================================
           MOBILE
           ========================================================= */

        @media (max-width: 575.98px) {

            body {

                padding: 12px;

                align-items: center;

            }


            .picker-card {

                padding:
                    25px 19px 23px;

                border-radius: 16px;

            }


            .picker-header {

                align-items: flex-start;

                margin-bottom: 20px;

            }


            .brand-icon {

                width: 45px;
                height: 45px;

                border-radius: 11px;

                font-size: 18px;

            }


            .brand-name {

                font-size: .94rem;

            }


            .brand-label {

                font-size: .59rem;

            }


            .logout-btn span {

                display: none;

            }


            .logout-btn {

                width: 36px;
                height: 36px;

                padding: 0;

                justify-content: center;

            }


            .intro {

                font-size: .72rem;

                padding:
                    12px 13px;

            }


            .store-btn {

                min-height: 61px;

            }


            .store-name {

                font-size: .80rem;

            }


            .store-description {

                font-size: .63rem;

            }


            .floating-icon {

                font-size:
                    30px !important;

            }

        }


        /* =========================================================
           REDUCED MOTION
           ========================================================= */

        @media (prefers-reduced-motion: reduce) {

            *,
            *::before,
            *::after {

                animation-duration:
                    .01ms !important;

                animation-iteration-count:
                    1 !important;

                transition-duration:
                    .01ms !important;

            }

        }

    </style>

</head>


<body>


<!-- =============================================================
     ANIMATED BACKGROUND
     ============================================================= -->

<div class="background-icons">

    <i class="floating-icon fas fa-box"></i>

    <i class="floating-icon fas fa-barcode"></i>

    <i class="floating-icon fas fa-warehouse"></i>

    <i class="floating-icon fas fa-cubes"></i>

    <i class="floating-icon fas fa-truck"></i>

    <i class="floating-icon fas fa-chart-line"></i>

    <i class="floating-icon fas fa-shopping-cart"></i>

    <i class="floating-icon fas fa-boxes"></i>

</div>


<div class="background-glow"></div>


<!-- =============================================================
     STORE SELECTOR
     ============================================================= -->

<div class="store-wrapper">

    <div class="picker-card">


        <!-- HEADER -->

        <div class="picker-header">

            <div class="brand-area">

                <div class="">

                                    <img 
    src="img/dhlogo.png" 
    alt="Dions Hardware Logo"
    style="
        display: block;
        width: auto;
        max-width: 70%;
        height: auto;
        max-height: 90px;
        margin: 0 auto 15px;
        object-fit: contain;
    "
>

                </div>

                <div>

                    <h1 class="brand-name">
                        DIONS HARDWARE
                    </h1>

                    <div class="brand-label">
                        Business Management Portal
                    </div>

                </div>

            </div>


            <a
                href="logout.php"
                class="logout-btn"
                title="Log out"
            >

                <i class="fas fa-sign-out-alt"></i>

                <span>
                    Log out
                    <?= $user
                        ? ' (' . htmlspecialchars($user['username']) . ')'
                        : ''
                    ?>
                </span>

            </a>

        </div>


        <!-- INTRODUCTION -->

        <div class="intro">

            <i class="fas fa-info-circle"></i>

            Choose the store you want to manage.
            Each store operates independently with its own
            products, prices, inventory, and sales history.

        </div>


        <!-- STORE LIST -->

        <div class="section-title">

            <div class="section-title-left">

                <i class="fas fa-store"></i>

                <span>Select Store</span>

            </div>

            <?php if ($stores): ?>

                <span class="store-count">

                    <?= count($stores) ?>

                    <?= count($stores) === 1
                        ? 'store'
                        : 'stores'
                    ?>

                </span>

            <?php endif; ?>

        </div>


        <?php if (!$stores): ?>

            <!-- EMPTY STATE -->

            <div class="empty-state">

                <div class="empty-icon">

                    <i class="fas fa-store-slash"></i>

                </div>

                <div class="empty-title">
                    No Stores Available
                </div>

                <p class="empty-text">

                    No stores have been configured
                    for this system yet.

                </p>

            </div>


        <?php else: ?>


            <!-- STORE FORM -->

            <form method="POST">

                <?= csrf_field() ?>

                <input
                    type="hidden"
                    name="action"
                    value="select_store"
                >


                <div class="store-list">

                    <?php foreach ($stores as $s): ?>

                        <button
                            type="submit"
                            name="store_id"
                            value="<?= (int)$s['store_id'] ?>"
                            class="store-btn"
                        >

                            <div class="store-icon">

                                <i class="fas fa-store"></i>

                            </div>


                            <div class="store-info">

                                <span class="store-name">

                                    <?= htmlspecialchars(
                                        $s['store_name']
                                    ) ?>

                                </span>

                                <span class="store-description">

                                    Open store dashboard

                                </span>

                            </div>


                            <i
                                class="store-arrow fas fa-chevron-right"
                            ></i>

                        </button>

                    <?php endforeach; ?>

                </div>

            </form>


        <?php endif; ?>


        <!-- ADMIN CREATE STORE -->

        <?php if (
            !$stores &&
            ($user['role'] ?? '') === 'admin'
        ): ?>

            <a
                href="db_import.php"
                class="create-store-btn"
            >

                <i class="fas fa-plus-circle"></i>

                Import / Create Your First Store

            </a>

        <?php endif; ?>


        <!-- SECURITY -->

        <div class="security-note">

            <i class="fas fa-shield-alt"></i>

            Secure multi-store environment

        </div>

    </div>


    <div class="copyright">

        &copy; <?= date('Y') ?>
        DIONS HARDWARE

    </div>

</div>


</body>

</html>
