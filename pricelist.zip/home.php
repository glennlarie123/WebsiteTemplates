<?php
require_once __DIR__ . '/includes/auth_mysqli.php';
start_secure_session();
require_login();

require_once __DIR__ . '/includes/store_db_mysqli.php';
require_once __DIR__ . '/includes/report_queries_mysqli.php';

if (!defined('DEFAULT_LOW_STOCK_THRESHOLD')) {
    define('DEFAULT_LOW_STOCK_THRESHOLD', 10);
}


function money($amount)
{
    $amount = (float) $amount;

    $sign = $amount < 0 ? '-' : '';

    return $sign . CURRENCY_SYMBOL . number_format(abs($amount), 2);
}


/**
 * Escape HTML.
 */
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


/**
 * Execute a prepared statement and return result.
 */
function executeQuery($conn, $sql, $types = '', $params = [])
{
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return false;
    }

    if ($types !== '' && !empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return false;
    }

    $result = mysqli_stmt_get_result($stmt);

    mysqli_stmt_close($stmt);

    return $result;
}


/**
 * Validate YYYY-MM-DD date.
 */
function validDate($date)
{
    if (!is_string($date) || $date === '') {
        return false;
    }

    $dt = DateTime::createFromFormat('Y-m-d', $date);

    return $dt !== false && $dt->format('Y-m-d') === $date;
}


/**
 * Format quantity without unnecessary decimals.
 */
function formatQty($quantity)
{
    $quantity = (float) $quantity;

    if (floor($quantity) == $quantity) {
        return number_format($quantity, 0);
    }

    return number_format($quantity, 2);
}


/**
 * Get product image URL.
 */
function productImage($path)
{
    $path = trim((string) $path);

    if ($path === '') {
        return '../img/no-image.png';
    }

    return '../' . ltrim($path, '/');
}


/**
 * ============================================================
 * PORTED REPORT FUNCTIONS (from SuperAdminFiles.php)
 * ============================================================
 * NOTE: these are plain top-level function declarations, so PHP
 * hoists them at compile time — they can be called from anywhere
 * else in this file regardless of where they're defined. The bug
 * in the previous version wasn't function order, it was that
 * $db / $range_from / $range_to were used before those VARIABLES
 * were assigned (see the "PORTED CALCULATIONS" block near the
 * bottom of this file, right before STORE INFORMATION).
 *
 * Consider moving these into includes/report_queries_mysqli.php
 * alongside get_daily_sales()/get_top_sellers()/etc. so they're
 * reusable from other pages too — kept here for now to match
 * where get_sales_summary() already landed.
 * ============================================================
 */

/**
 * Pulls named fields out of a DB row regardless of whether the
 * row came back associative (['sale_date' => ...]) or
 * numeric-indexed (['sale_date' => ..] vs [0 => ..]) — this
 * $db wrapper's fetch_all() returns numeric-indexed rows (same
 * convention as fetch_row(), which is why [$a, $b] = ...->fetch_row()
 * works elsewhere in this file), so we map by position here.
 *
 * @param array $row  A single row from fetch_all()/fetch_row()
 * @param array $keys Column names IN THE SAME ORDER as the SELECT
 */
function normalize_row($row, array $keys): array
{
    $out = [];

    $i = 0;

    foreach ($keys as $key) {

        if (is_array($row) && array_key_exists($key, $row)) {
            $out[$key] = $row[$key];
        } elseif (is_array($row) && array_key_exists($i, $row)) {
            $out[$key] = $row[$i];
        } else {
            $out[$key] = null;
        }

        $i++;
    }

    return $out;
}


function get_sales_summary($db, string $from, string $to): array
{
    $range_start = $from . ' 00:00:00';
    $range_end   = $to . ' 23:59:59';

    $row = $db->prepared_query(
        "
        SELECT
            COALESCE(SUM(sm.quantity), 0) AS units_sold,
            COALESCE(SUM(sm.quantity * p.product_price), 0) AS revenue,
            COALESCE(SUM(sm.quantity * p.product_cost), 0) AS cost,
            COUNT(DISTINCT sm.reference_no) AS orders,
            COUNT(DISTINCT sm.product_id) AS product_lines
        FROM stock_movements sm
        INNER JOIN table_product p
            ON p.product_id = sm.product_id
        WHERE sm.transaction_type = 'OUT'
          AND sm.movement_date BETWEEN ? AND ?
        ",
        'ss',
        $range_start,
        $range_end
    )->fetch_row();

    return [
        'units_sold'    => (float) ($row[0] ?? 0),
        'revenue'       => (float) ($row[1] ?? 0),
        'cost'          => (float) ($row[2] ?? 0),
        'orders'        => (int)   ($row[3] ?? 0),
        'product_lines' => (int)   ($row[4] ?? 0),
    ];
}


/**
 * Derives net/average/margin figures from a summary + day count.
 * Mirrors the "CALCULATED VALUES" block from SuperAdminFiles.php.
 * THIS WAS MISSING BEFORE — get_sales_summary() alone doesn't
 * compute net/average_order/average_daily/margin_pct.
 */
function derive_summary_metrics(array $summary, int $selected_days): array
{
    $summary['net'] =
        $summary['revenue'] - $summary['cost'];

    $summary['average_order'] =
        $summary['orders'] > 0
            ? $summary['revenue'] / $summary['orders']
            : 0.0;

    $summary['average_daily'] =
        $selected_days > 0
            ? $summary['revenue'] / $selected_days
            : 0.0;

    $summary['margin_pct'] =
        $summary['revenue'] > 0
            ? ($summary['net'] / $summary['revenue']) * 100
            : 0.0;

    return $summary;
}


/**
 * Day-by-day units / revenue / cost / profit.
 * THIS WAS MISSING BEFORE.
 *
 * NOTE: uses $db->prepared_query(...)->fetch_all() to collect
 * multiple rows. If your $db wrapper's "return all rows" method
 * has a different name (check whatever get_daily_sales() calls
 * internally in report_queries_mysqli.php), swap it in here.
 */
function get_daily_trend($db, string $from, string $to): array
{
    $range_start = $from . ' 00:00:00';
    $range_end   = $to . ' 23:59:59';

    $rows = $db->prepared_query(
        "
        SELECT
            DATE(sm.movement_date) AS sale_date,
            COALESCE(SUM(sm.quantity), 0) AS units,
            COALESCE(SUM(sm.quantity * p.product_price), 0) AS revenue,
            COALESCE(SUM(sm.quantity * p.product_cost), 0) AS cost
        FROM stock_movements sm
        INNER JOIN table_product p
            ON p.product_id = sm.product_id
        WHERE sm.transaction_type = 'OUT'
          AND sm.movement_date BETWEEN ? AND ?
        GROUP BY DATE(sm.movement_date)
        ORDER BY sale_date ASC
        ",
        'ss',
        $range_start,
        $range_end
    )->fetch_all(); // ADJUST: fetch-all method name if different in your $db wrapper

    $trend = [];

    foreach ($rows as $raw) {

        $r = normalize_row($raw, ['sale_date', 'units', 'revenue', 'cost']);

        $trend[] = [
            'date'    => $r['sale_date'],
            'units'   => (float) $r['units'],
            'revenue' => (float) $r['revenue'],
            'cost'    => (float) $r['cost'],
            'profit'  => (float) $r['revenue'] - (float) $r['cost'],
        ];
    }

    return $trend;
}


/**
 * Top sellers with revenue + image (for a ranked list with thumbnails).
 * THIS WAS MISSING BEFORE. Different from get_top_sellers(), which
 * only returns qty sold.
 */
function get_top_sellers_detailed($db, string $from, string $to, int $limit = 10): array
{
    $range_start = $from . ' 00:00:00';
    $range_end   = $to . ' 23:59:59';

    $rows = $db->prepared_query(
        "
        SELECT
            p.product_id,
            p.product_name,
            p.product_img_path,
            SUM(sm.quantity) AS units_sold,
            SUM(sm.quantity * p.product_price) AS revenue
        FROM stock_movements sm
        INNER JOIN table_product p
            ON p.product_id = sm.product_id
        WHERE sm.transaction_type = 'OUT'
          AND sm.movement_date BETWEEN ? AND ?
        GROUP BY p.product_id, p.product_name, p.product_img_path
        ORDER BY units_sold DESC
        LIMIT ?
        ",
        'ssi',
        $range_start,
        $range_end,
        $limit
    )->fetch_all(); // ADJUST: fetch-all method name if different in your $db wrapper

    $keys = ['product_id', 'product_name', 'product_img_path', 'units_sold', 'revenue'];

    return array_map(
        fn($raw) => normalize_row($raw, $keys),
        $rows
    );
}


/**
 * Low stock alerts for the active store.
 * THIS WAS MISSING BEFORE.
 */
function get_low_stock($db, int $threshold, int $limit = 15): array
{
    $rows = $db->prepared_query(
        "
        SELECT
            product_id,
            product_name,
            product_quantity,
            product_rack,
            item_no
        FROM table_product
        WHERE product_availability = 1
          AND product_quantity <= ?
        ORDER BY product_quantity ASC
        LIMIT ?
        ",
        'ii',
        $threshold,
        $limit
    )->fetch_all(); // ADJUST: fetch-all method name if different in your $db wrapper

    $keys = ['product_id', 'product_name', 'product_quantity', 'product_rack', 'item_no'];

    return array_map(
        fn($raw) => normalize_row($raw, $keys),
        $rows
    );
}


/**
 * Products sold below cost, with per-product detail.
 * THIS WAS MISSING BEFORE.
 */
function get_loss_sales($db, string $from, string $to): array
{
    $range_start = $from . ' 00:00:00';
    $range_end   = $to . ' 23:59:59';

    $rows = $db->prepared_query(
        "
        SELECT
            p.product_id,
            p.product_name,
            SUM(sm.quantity) AS units_sold,
            p.product_price,
            p.product_cost,
            SUM(sm.quantity * (p.product_cost - p.product_price)) AS loss_amount
        FROM stock_movements sm
        INNER JOIN table_product p
            ON p.product_id = sm.product_id
        WHERE sm.transaction_type = 'OUT'
          AND sm.movement_date BETWEEN ? AND ?
          AND p.product_price < p.product_cost
        GROUP BY p.product_id, p.product_name, p.product_price, p.product_cost
        ORDER BY loss_amount DESC
        ",
        'ss',
        $range_start,
        $range_end
    )->fetch_all(); // ADJUST: fetch-all method name if different in your $db wrapper

    $keys = ['product_id', 'product_name', 'units_sold', 'product_price', 'product_cost', 'loss_amount'];

    return array_map(
        fn($raw) => normalize_row($raw, $keys),
        $rows
    );
}


// ============================================================
// STORE SWITCHING
// ============================================================

if (isset($_GET['switch_store'])) {

    $switch_id = (int)$_GET['switch_store'];

    $config = app_config();

    foreach ($config['stores'] as $s) {

        if ((int)$s['store_id'] === $switch_id) {

            $_SESSION['active_store_id'] = $switch_id;

            header('Location: index.php');
            exit;
        }
    }
}


// ============================================================
// ACTIVE STORE DATABASE
// ============================================================

$db = require_active_store();


// ============================================================
// INVENTORY SUMMARY
// ============================================================

$total_products = (int)$db->fetch_scalar("
    SELECT COUNT(*)
    FROM table_product
    WHERE product_name IS NOT NULL
");

$total_categories = (int)$db->fetch_scalar("
    SELECT COUNT(*)
    FROM table_category
");

$uncategorized = (int)$db->fetch_scalar("
    SELECT COUNT(*)
    FROM table_product
    WHERE category_id IS NULL
      AND product_name IS NOT NULL
");

$out_of_stock = (int)$db->fetch_scalar("
    SELECT COUNT(*)
    FROM table_product
    WHERE product_name IS NOT NULL
      AND product_quantity <= 0
");


// ============================================================
// DATE VARIABLES
// ============================================================

$today       = date('Y-m-d');
$month_start = date('Y-m-01');

$this_year  = (int)date('Y');
$this_month = (int)date('n');


// ============================================================
// TODAY
// ============================================================

$today_row = $db->prepared_query(
    "
SELECT
    COUNT(*),
    COALESCE(SUM(tp.product_price * sm.quantity), 0)
FROM stock_movements sm
JOIN table_product tp
    ON tp.product_id = sm.product_id
WHERE DATE(sm.movement_date) = ?

    ",
    's',
    $today
)->fetch_row();

[$today_invoices, $today_revenue] = $today_row;


// ============================================================
// MONTH REVENUE
// ============================================================

$month_revenue = (float)$db->fetch_scalar(
    "
    SELECT COALESCE(
        SUM(sm.quantity * tp.product_price),
        0
    )
    FROM stock_movements sm
    JOIN table_product tp
        ON sm.product_id = tp.product_id
    WHERE sm.transaction_type = 'OUT'
      AND sm.movement_date >= ?
    ",
    's',
    $month_start
);


// ============================================================
// MONTH SPENDING
// ============================================================

$spending_amount = (float)$db->fetch_scalar(
    "
SELECT COALESCE(
    SUM(sm.quantity * tp.product_cost),
    0
)
FROM stock_movements sm
JOIN table_product tp
    ON sm.product_id = tp.product_id
WHERE sm.transaction_type = 'OUT'
  AND sm.movement_date >= ?
    ",
    's',
    $month_start
);


// ============================================================
// MONTH COGS
// ============================================================

$cogs_amount = get_cogs(
    $db,
    $month_start,
    $today
);


// ============================================================
// MONTH LOSSES
// ============================================================

$loss_amount = (float)$db->fetch_scalar(
    "
    SELECT COALESCE(
        SUM(sm.quantity * p.product_cost),
        0
    )
    FROM stock_movements sm
    JOIN table_product p
        ON sm.product_id = p.product_id
    WHERE sm.remarks LIKE 'LOSS:%'
      AND sm.movement_date >= ?
    ",
    's',
    $month_start
);


// ============================================================
// NET PROFIT
// ============================================================

$net_profit_mtd =
    $month_revenue
    - $cogs_amount
    - $loss_amount;


// ============================================================
// TOP / LOW SELLERS
// ============================================================

$top_sellers = get_top_sellers(
    $db,
    $this_year,
    $this_month,
    5
);

$low_sellers = get_low_sellers(
    $db,
    $this_year,
    $this_month,
    5
);


// ============================================================
// DAILY SERIES HELPER
// ============================================================

function fill_series_daily(
    array $rows,
    string $from,
    string $to,
    string $date_key,
    string $value_key
): array {

    $by_date = [];

    foreach ($rows as $r) {

        $raw = $r[$date_key] ?? null;

        if ($raw === null) {
            continue;
        }

        $d = date(
            'Y-m-d',
            strtotime((string)$raw)
        );

        $by_date[$d] =
            (float)($r[$value_key] ?? 0);
    }


    $labels = [];
    $data   = [];

    $cursor = new DateTime($from);
    $end    = new DateTime($to);

    while ($cursor <= $end) {

        $d = $cursor->format('Y-m-d');

        $labels[] = $cursor->format('M j');

        $data[] =
            $by_date[$d] ?? 0.0;

        $cursor->modify('+1 day');
    }

    return [$labels, $data];
}


// ============================================================
// MONTHLY SALES
// ============================================================

$monthly_sales_rows =
    get_daily_sales(
        $db,
        $month_start,
        $today
    );

[
    $monthly_labels,
    $monthly_data
] = fill_series_daily(
    $monthly_sales_rows,
    $month_start,
    $today,
    'report_date',
    'net_income'
);


// ============================================================
// CUSTOM DATE RANGE
// ============================================================

$default_from =
    date(
        'Y-m-d',
        strtotime('-6 days')
    );

$range_from =
    $_GET['from'] ?? $default_from;

$range_to =
    $_GET['to'] ?? $today;


if (
    !preg_match(
        '/^\d{4}-\d{2}-\d{2}$/',
        $range_from
    )
) {
    $range_from = $default_from;
}


if (
    !preg_match(
        '/^\d{4}-\d{2}-\d{2}$/',
        $range_to
    )
) {
    $range_to = $today;
}


if ($range_from > $range_to) {

    [
        $range_from,
        $range_to
    ] = [
        $range_to,
        $range_from
    ];
}


// ============================================================
// RANGE REPORTS
// ============================================================

$range_sales_rows =
    get_daily_sales(
        $db,
        $range_from,
        $range_to
    );

$range_spending_rows =
    get_spending(
        $db,
        $range_from,
        $range_to
    );

$range_loss_rows =
    get_losses(
        $db,
        $range_from,
        $range_to
    );


$range_revenue =
    array_sum(
        array_column(
            $range_sales_rows,
            'net_income'
        )
    );


$range_transactions =
    (int)array_sum(
        array_column(
            $range_sales_rows,
            'transactions'
        )
    );


$range_spending_tot =
    array_sum(
        array_column(
            $range_spending_rows,
            'total_spending'
        )
    );


$range_loss_tot =
    array_sum(
        array_column(
            $range_loss_rows,
            'loss_amount'
        )
    );


$range_cogs =
    get_cogs(
        $db,
        $range_from,
        $range_to
    );


$range_net =
    $range_revenue
    - $range_cogs
    - $range_loss_tot;


[
    $range_labels,
    $range_data
] = fill_series_daily(
    $range_sales_rows,
    $range_from,
    $range_to,
    'report_date',
    'net_income'
);


/**
 * ============================================================
 * PORTED CALCULATIONS (from SuperAdminFiles.php)
 * ============================================================
 * Placed here — AFTER $db and $range_from/$range_to both exist.
 * This is the fix: previously this whole block ran near the top
 * of the file, before $db was assigned and before $range_from/
 * $range_to were computed, which caused a fatal error (null
 * $db) and undefined-variable warnings.
 * ============================================================
 */

$threshold = isset($_GET['low_stock'])
    ? max(0, (int) $_GET['low_stock'])
    : DEFAULT_LOW_STOCK_THRESHOLD;

$selected_days =
    (new DateTime($range_from))->diff(new DateTime($range_to))->days + 1;

$range_summary = get_sales_summary($db, $range_from, $range_to);
$range_summary = derive_summary_metrics($range_summary, $selected_days);

$range_is_profit = $range_summary['net'] >= 0;

$daily_trend_detailed = get_daily_trend($db, $range_from, $range_to);

$trend_labels  = [];
$trend_revenue = [];
$trend_cost    = [];
$trend_profit  = [];
$trend_units   = [];

foreach ($daily_trend_detailed as $day) {
    $trend_labels[]  = date('M j', strtotime($day['date']));
    $trend_revenue[] = round($day['revenue'], 2);
    $trend_cost[]    = round($day['cost'], 2);
    $trend_profit[]  = round($day['profit'], 2);
    $trend_units[]   = round($day['units'], 2);
}

$top_sellers_detailed = get_top_sellers_detailed($db, $range_from, $range_to, 10);

$max_units = 0.0;

foreach ($top_sellers_detailed as $seller) {
    $max_units = max($max_units, (float) $seller['units_sold']);
}

$low_stock = get_low_stock($db, $threshold, 15);

$loss_sales = get_loss_sales($db, $range_from, $range_to);

$loss_units_detailed  = 0.0;
$loss_amount_detailed = 0.0;

foreach ($loss_sales as $loss_row) {
    $loss_units_detailed  += (float) $loss_row['units_sold'];
    $loss_amount_detailed += (float) $loss_row['loss_amount'];
}

$loss_products_count = count($loss_sales);


// ============================================================
// STORE INFORMATION
// ============================================================

$config = app_config();

$all_stores =
    $config['stores'];

$active_store_id =
    (int)($_SESSION['active_store_id'] ?? 0);

$active_store_name =
    'Unknown';


foreach ($all_stores as $s) {

    if (
        (int)$s['store_id']
        === $active_store_id
    ) {

        $active_store_name =
            $s['store_name'];

        break;
    }
}


$is_admin =
    (current_user()['role'] ?? '')
    === 'admin';


// ============================================================
// PAGE
// ============================================================

$page_title =
    'Dashboard · DIONS HARDWARE';

$active_nav =
    'dashboard';

require __DIR__ . '/includes/header_bootstrap.php';

?>


<style>

```css
/* ============================================================
   DIONS HARDWARE — DARK GOLD DASHBOARD THEME
   ============================================================ */

:root {
    --brand-gold: #b8860b;
    --brand-gold-light: #d4a017;
    --brand-gold-bright: #e2b93b;
    --brand-gold-dark: #765a08;

    --bg-main: #10110e;
    --bg-card: #181a15;
    --bg-card-soft: #1d1f19;
    --bg-input: #20221c;

    --border: rgba(212, 160, 23, 0.18);
    --border-soft: rgba(255, 255, 255, 0.07);

    --text-primary: #f5f2e8;
    --text-secondary: #c9c4b3;
    --text-muted: #898473;
    --text-dark-muted: #676354;

    --success: #52b788;
    --success-soft: rgba(82, 183, 136, .12);

    --danger: #dc6b62;
    --danger-soft: rgba(220, 107, 98, .12);

    --warning: #d4a017;
    --warning-soft: rgba(212, 160, 23, .12);

    --shadow-sm: 0 4px 14px rgba(0, 0, 0, .18);
    --shadow-md: 0 8px 28px rgba(0, 0, 0, .24);
    --shadow-gold: 0 6px 20px rgba(184, 134, 11, .10);
}


/* ============================================================
   DASHBOARD BASE
   ============================================================ */

.dashboard-page {
    padding-bottom: 40px;
}


/* ============================================================
   PAGE HEADER
   ============================================================ */

.dashboard-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 24px;
}

.dashboard-heading {
    display: flex;
    align-items: center;
    gap: 14px;
}

.dashboard-heading-icon {
    width: 50px;
    height: 50px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            rgba(212, 160, 23, .20),
            rgba(184, 134, 11, .07)
        );

    border: 1px solid rgba(212, 160, 23, .30);

    color: var(--brand-gold-bright);

    font-size: 20px;

    box-shadow:
        inset 0 1px 0 rgba(255,255,255,.05),
        var(--shadow-gold);
}

.dashboard-title {
    margin: 0;

    color: var(--text-primary);

    font-size: 26px;
    font-weight: 750;

    letter-spacing: -.5px;
}

.dashboard-subtitle {
    margin: 5px 0 0;

    color: var(--text-muted);

    font-size: 12px;
}

.dashboard-store-name {
    color: var(--brand-gold-bright);
    font-weight: 700;
}

.dashboard-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.dashboard-actions .btn {
    min-height: 34px;

    padding: 6px 12px;

    border-radius: 8px;

    font-size: 11px;
    font-weight: 650;

    transition:
        color .18s ease,
        background .18s ease,
        border-color .18s ease,
        transform .18s ease,
        box-shadow .18s ease;
}

.dashboard-actions .btn:hover {
    transform: translateY(-1px);

    border-color: rgba(212,160,23,.55);

    color: var(--brand-gold-bright);

    background: rgba(212,160,23,.08);

    box-shadow: var(--shadow-gold);
}


/* ============================================================
   STORE SWITCHER
   ============================================================ */

.store-switcher {
    margin-bottom: 22px;

    padding: 16px 18px;

    border: 1px solid var(--border);

    border-radius: 13px;

    background:
        linear-gradient(
            145deg,
            rgba(212,160,23,.055),
            rgba(255,255,255,.015)
        );

    box-shadow: var(--shadow-sm);
}

.store-switcher-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    margin-bottom: 11px;
}

.store-switcher-label {
    color: var(--text-secondary);

    font-size: 11px;
    font-weight: 700;

    text-transform: uppercase;
    letter-spacing: .45px;
}

.store-switcher-label i {
    color: var(--brand-gold-light);
}

.store-switcher-count {
    color: var(--text-dark-muted);
    font-size: 10px;
}

.store-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.store-button {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 8px 12px;

    border-radius: 8px;

    border: 1px solid var(--border-soft);

    background: rgba(255,255,255,.025);

    color: var(--text-muted);

    font-size: 11px;
    font-weight: 650;

    text-decoration: none;

    transition:
        background .18s ease,
        border-color .18s ease,
        color .18s ease,
        transform .18s ease;
}

.store-button:hover {
    transform: translateY(-1px);

    border-color: rgba(212,160,23,.42);

    background: rgba(212,160,23,.08);

    color: var(--brand-gold-bright);

    text-decoration: none;
}

.store-button.active {
    border-color: rgba(212,160,23,.48);

    background:
        linear-gradient(
            135deg,
            rgba(212,160,23,.18),
            rgba(184,134,11,.07)
        );

    color: var(--brand-gold-bright);

    box-shadow:
        inset 0 1px 0 rgba(255,255,255,.04),
        var(--shadow-gold);
}

.store-status-dot {
    width: 7px;
    height: 7px;

    flex: 0 0 7px;

    border-radius: 50%;

    background: #55564e;
}

.store-button.active .store-status-dot {
    background: var(--success);

    box-shadow:
        0 0 0 3px rgba(82,183,136,.10),
        0 0 8px rgba(82,183,136,.35);
}


/* ============================================================
   KPI CARDS
   ============================================================ */

.dashboard-kpi {
    position: relative;

    height: 100%;
    overflow: hidden;

    border: 1px solid var(--border-soft);

    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            #1c1e18 0%,
            #151711 100%
        );

    box-shadow: var(--shadow-md);

    transition:
        transform .2s ease,
        border-color .2s ease,
        box-shadow .2s ease;
}

.dashboard-kpi:hover {
    transform: translateY(-3px);

    border-color: rgba(212,160,23,.30);

    box-shadow:
        0 12px 32px rgba(0,0,0,.28),
        0 0 20px rgba(184,134,11,.06);
}

.dashboard-kpi::before {
    content: "";

    position: absolute;

    left: 0;
    top: 0;

    width: 100%;
    height: 2px;

    background:
        linear-gradient(
            90deg,
            var(--brand-gold-dark),
            var(--brand-gold-light),
            transparent
        );

    opacity: .85;
}

.dashboard-kpi::after {
    content: "";

    position: absolute;

    width: 150px;
    height: 150px;

    right: -70px;
    bottom: -75px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(212,160,23,.10),
            transparent 68%
        );

    pointer-events: none;
}

.dashboard-kpi-body {
    position: relative;
    z-index: 1;

    padding: 20px;
}

.kpi-top {
    display: flex;
    align-items: center;
    justify-content: space-between;

    margin-bottom: 13px;
}

.kpi-icon {
    width: 37px;
    height: 37px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background:
        linear-gradient(
            145deg,
            rgba(212,160,23,.16),
            rgba(184,134,11,.05)
        );

    border: 1px solid rgba(212,160,23,.17);

    color: var(--brand-gold-light);

    font-size: 14px;
}

.kpi-trend {
    color: var(--text-dark-muted);

    font-size: 9px;
    font-weight: 750;

    text-transform: uppercase;

    letter-spacing: .7px;
}

.kpi-label {
    margin-bottom: 6px;

    color: var(--text-muted);

    font-size: 10px;
    font-weight: 750;

    text-transform: uppercase;

    letter-spacing: .7px;
}

.kpi-value {
    margin-bottom: 6px;

    color: var(--text-primary);

    font-size: 24px;
    font-weight: 750;

    line-height: 1.2;

    letter-spacing: -.45px;

    font-variant-numeric: tabular-nums;
}

.kpi-value.success {
    color: var(--success);
}

.kpi-value.danger {
    color: var(--danger);
}

.kpi-description {
    color: var(--text-dark-muted);
    font-size: 10px;
}


/* KPI STATUS ACCENTS */

.kpi-accent-success::before {
    background:
        linear-gradient(
            90deg,
            rgba(82,183,136,.75),
            rgba(82,183,136,.20),
            transparent
        );
}

.kpi-accent-warning::before {
    background:
        linear-gradient(
            90deg,
            var(--brand-gold-dark),
            var(--brand-gold-light),
            transparent
        );
}

.kpi-accent-danger::before {
    background:
        linear-gradient(
            90deg,
            rgba(220,107,98,.75),
            rgba(220,107,98,.20),
            transparent
        );
}

.kpi-accent-primary::before {
    background:
        linear-gradient(
            90deg,
            var(--brand-gold-dark),
            var(--brand-gold-light),
            transparent
        );
}


/* ============================================================
   GENERAL DASHBOARD CARDS
   ============================================================ */

.dashboard-card {
    height: 100%;
    overflow: hidden;

    border: 1px solid var(--border-soft);

    border-radius: 14px;

    background:
        linear-gradient(
            145deg,
            #1a1c17,
            #151611
        );

    box-shadow: var(--shadow-md);

    transition:
        border-color .2s ease,
        box-shadow .2s ease;
}

.dashboard-card:hover {
    border-color: rgba(212,160,23,.20);
}

.dashboard-card-header {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 10px;

    padding: 15px 18px;

    border-bottom: 1px solid rgba(212,160,23,.10);

    color: var(--text-primary);

    font-size: 12px;
    font-weight: 750;

    background:
        linear-gradient(
            90deg,
            rgba(212,160,23,.045),
            transparent
        );
}

.dashboard-card-header i {
    margin-right: 7px;

    color: var(--brand-gold-light);
}

.dashboard-card-header.success {
    color: var(--success);
}

.dashboard-card-header.success i {
    color: var(--success);
}

.dashboard-card-header.danger {
    color: var(--danger);
}

.dashboard-card-header.danger i {
    color: var(--danger);
}

.dashboard-card-body {
    padding: 18px;
}


/* ============================================================
   CHART
   ============================================================ */

.chart-box {
    position: relative;

    width: 100%;
    height: 310px;

    padding: 6px;

    border-radius: 11px;

    border: 1px solid rgba(212,160,23,.07);

    background:
        linear-gradient(
            180deg,
            rgba(8,9,7,.72),
            rgba(20,21,17,.50)
        );
}

.chart-box canvas {
    display: block;

    width: 100% !important;
    height: 100% !important;
}


/* ============================================================
   CHART TABLE
   ============================================================ */

.mini-table {
    width: 100%;

    margin-top: 12px;

    border-collapse: collapse;

    color: var(--text-muted);

    font-size: 9px;

    table-layout: fixed;
}

.mini-table th,
.mini-table td {
    padding: 6px 4px;

    border-bottom: 1px solid rgba(212,160,23,.07);

    text-align: center;

    white-space: nowrap;
}

.mini-table th {
    color: var(--text-dark-muted);

    font-weight: 650;
}

.mini-table td {
    color: var(--text-secondary);

    font-weight: 600;

    font-variant-numeric: tabular-nums;
}


/* ============================================================
   BREAKDOWN LIST
   ============================================================ */

.dashboard-list {
    list-style: none;

    padding: 0;
    margin: 0;
}

.dashboard-list-item {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 12px;

    padding: 12px 0;

    border-bottom: 1px solid rgba(212,160,23,.07);

    color: var(--text-secondary);

    font-size: 11px;
}

.dashboard-list-item:first-child {
    padding-top: 0;
}

.dashboard-list-item:last-child {
    padding-bottom: 0;
    border-bottom: 0;
}

.dashboard-list-label {
    display: flex;

    align-items: center;

    gap: 8px;
}

.dashboard-list-dot {
    width: 7px;
    height: 7px;

    flex: 0 0 7px;

    border-radius: 50%;

    background: var(--brand-gold-light) !important;

    box-shadow:
        0 0 6px rgba(212,160,23,.18);
}

.dashboard-list-value {
    color: var(--text-primary);

    font-weight: 750;

    font-variant-numeric: tabular-nums;

    white-space: nowrap;
}

.dashboard-list-value.success {
    color: var(--success);
}

.dashboard-list-value.warning {
    color: var(--brand-gold-light);
}

.dashboard-list-value.danger {
    color: var(--danger);
}


/* ============================================================
   DATE RANGE / SALES FILTER
   ============================================================ */

.range-card {
    margin-top: 0;
}

.range-header {
    align-items: flex-start;
    flex-wrap: wrap;
}

.range-title {
    display: flex;

    align-items: center;

    gap: 8px;
}

.range-title i {
    color: var(--brand-gold-light);
}

.range-form {
    display: flex;

    align-items: center;

    flex-wrap: wrap;

    gap: 10px;

    padding: 14px 16px;

    background:
        linear-gradient(
            145deg,
            rgba(212,160,23,.07),
            rgba(255,255,255,.018)
        );

    border: 1px solid rgba(212,160,23,.15);

    border-radius: 12px;

    box-shadow: var(--shadow-sm);
}

.range-form .range-title {
    display: flex;

    align-items: center;

    gap: 7px;

    color: var(--text-primary);

    font-size: 13px;
    font-weight: 700;

    white-space: nowrap;
}

.range-form .range-title i {
    color: var(--brand-gold-light);

    font-size: 13px;
}

.sales-date-filter {
    display: flex;

    align-items: center;

    gap: 8px;
}

.sales-date-filter label {
    margin: 0;

    color: var(--text-muted);

    font-size: 11px;
    font-weight: 600;
}

.sales-date-filter .form-control {
    width: 155px;
    height: 39px;

    padding: 6px 10px;

    background: var(--bg-input) !important;

    color: var(--text-primary) !important;

    border: 1px solid rgba(212,160,23,.18) !important;

    border-radius: 8px;

    font-size: 12px;
    font-weight: 550;

    box-shadow: inset 0 1px 2px rgba(0,0,0,.20);

    color-scheme: dark;

    transition:
        border-color .2s ease,
        box-shadow .2s ease,
        background .2s ease;
}

.sales-date-filter .form-control:hover {
    border-color: rgba(212,160,23,.38) !important;

    background: #25271f !important;
}

.sales-date-filter .form-control:focus {
    background: #25271f !important;

    color: var(--text-primary) !important;

    border-color: var(--brand-gold-light) !important;

    box-shadow:
        0 0 0 3px rgba(212,160,23,.10),
        inset 0 1px 2px rgba(0,0,0,.20);

    outline: none;
}

.sales-date-filter input[type="date"]::-webkit-calendar-picker-indicator {
    cursor: pointer;

    opacity: .65;

    filter: sepia(1) saturate(.8);
}

.sales-date-filter input[type="date"]::-webkit-calendar-picker-indicator:hover {
    opacity: 1;
}

.range-form .apply-btn {
    height: 39px;

    padding: 0 17px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    gap: 7px;

    border: 1px solid rgba(226,185,59,.35);

    border-radius: 8px;

    background:
        linear-gradient(
            135deg,
            #c7950d,
            #a97705
        );

    color: #17140b;

    font-size: 12px;
    font-weight: 750;

    box-shadow:
        0 4px 10px rgba(0,0,0,.20),
        0 3px 12px rgba(184,134,11,.12);

    transition:
        transform .15s ease,
        box-shadow .2s ease,
        filter .2s ease;
}

.range-form .apply-btn:hover {
    transform: translateY(-1px);

    filter: brightness(1.08);

    box-shadow:
        0 6px 14px rgba(0,0,0,.25),
        0 5px 18px rgba(184,134,11,.18);
}

.range-form .apply-btn:active {
    transform: translateY(0);
}


/* ============================================================
   RANGE SUMMARY
   ============================================================ */

.range-summary {
    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 10px;

    margin-bottom: 17px;
}

.range-stat {
    position: relative;

    padding: 13px;

    overflow: hidden;

    border-radius: 10px;

    border: 1px solid rgba(212,160,23,.10);

    background:
        linear-gradient(
            145deg,
            rgba(212,160,23,.055),
            rgba(255,255,255,.012)
        );
}

.range-stat::before {
    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 30px;
    height: 2px;

    background: var(--brand-gold-light);
}

.range-stat-label {
    display: block;

    margin-bottom: 5px;

    color: var(--text-muted);

    font-size: 9px;
    font-weight: 750;

    text-transform: uppercase;

    letter-spacing: .55px;
}

.range-stat-value {
    color: var(--text-primary);

    font-size: 16px;
    font-weight: 750;

    font-variant-numeric: tabular-nums;
}

.range-stat-value.success {
    color: var(--success);
}

.range-stat-value.warning {
    color: var(--brand-gold-light);
}

.range-stat-value.danger {
    color: var(--danger);
}


/* ============================================================
   SELLER LIST
   ============================================================ */

.seller-list {
    list-style: none;

    padding: 0;
    margin: 0;
}

.seller-item {
    display: flex;

    align-items: center;

    gap: 10px;

    padding: 10px 0;

    border-bottom: 1px solid rgba(212,160,23,.07);
}

.seller-item:last-child {
    border-bottom: 0;
}

.seller-rank {
    width: 27px;
    height: 27px;

    display: flex;

    align-items: center;
    justify-content: center;

    flex: 0 0 27px;

    border-radius: 8px;

    background: rgba(255,255,255,.035);

    border: 1px solid rgba(255,255,255,.05);

    color: var(--text-muted);

    font-size: 9px;
    font-weight: 800;
}

.seller-item:first-child .seller-rank {
    background:
        linear-gradient(
            145deg,
            rgba(212,160,23,.20),
            rgba(184,134,11,.06)
        );

    border-color: rgba(212,160,23,.25);

    color: var(--brand-gold-bright);

    box-shadow:
        0 0 10px rgba(184,134,11,.08);
}

.seller-name {
    flex: 1;

    min-width: 0;

    overflow: hidden;

    color: var(--text-secondary);

    font-size: 11px;
    font-weight: 650;

    text-overflow: ellipsis;

    white-space: nowrap;
}

.seller-qty {
    color: var(--text-muted);

    font-size: 10px;

    white-space: nowrap;

    font-variant-numeric: tabular-nums;
}

.seller-footer {
    display: block;

    margin-top: 14px;

    color: var(--brand-gold-light);

    font-size: 10px;
    font-weight: 650;

    text-decoration: none;

    transition: color .18s ease;
}

.seller-footer:hover {
    color: var(--brand-gold-bright);

    text-decoration: none;
}


/* ============================================================
   EMPTY STATE
   ============================================================ */

.dashboard-empty {
    padding: 40px 15px;

    text-align: center;

    color: var(--text-muted);

    font-size: 11px;
}

.dashboard-empty i {
    display: block;

    margin-bottom: 10px;

    color: var(--brand-gold-dark);

    font-size: 24px;
}


/* ============================================================
   RESPONSIVE
   ============================================================ */

@media (max-width: 992px) {

    .dashboard-header {
        align-items: flex-start;

        flex-direction: column;
    }

    .dashboard-actions {
        width: 100%;
    }

    .range-summary {
        grid-template-columns:
            repeat(2, 1fr);
    }
}


@media (max-width: 768px) {

    .dashboard-page {
        padding-bottom: 25px;
    }

    .dashboard-title {
        font-size: 22px;
    }

    .dashboard-heading-icon {
        width: 44px;
        height: 44px;

        font-size: 18px;
    }

    .dashboard-actions {
        gap: 8px;
    }

    .dashboard-actions .btn {
        flex: 1;

        min-height: 38px;
    }

    .store-switcher-header {
        align-items: flex-start;

        flex-direction: column;

        gap: 4px;
    }

    .store-button {
        min-height: 36px;
    }

    .chart-box {
        height: 270px;
    }

    .range-header {
        flex-direction: column;

        gap: 12px;
    }

    .range-form {
        width: 100%;

        align-items: stretch;
    }

    .sales-date-filter {
        width: 100%;
    }

    .sales-date-filter .form-control {
        flex: 1;

        min-width: 0;
    }

    .range-form .apply-btn {
        min-height: 39px;
    }
}


@media (max-width: 576px) {

    .dashboard-heading {
        align-items: flex-start;

        gap: 11px;
    }

    .dashboard-title {
        font-size: 20px;
    }

    .dashboard-subtitle {
        font-size: 11px;
        line-height: 1.5;
    }

    .dashboard-actions {
        display: grid;

        grid-template-columns:
            repeat(2, 1fr);
    }

    .dashboard-actions .btn {
        width: 100%;
    }

    .store-switcher {
        padding: 14px;
    }

    .store-buttons {
        display: grid;

        grid-template-columns:
            repeat(2, 1fr);
    }

    .store-button {
        justify-content: center;

        padding: 9px 8px;
    }

    .dashboard-kpi-body {
        padding: 17px;
    }

    .kpi-value {
        font-size: 21px;
    }

    .dashboard-card-body {
        padding: 15px;
    }

    .range-summary {
        grid-template-columns:
            repeat(2, 1fr);

        gap: 8px;
    }

    .range-stat {
        padding: 11px;
    }

    .range-stat-value {
        font-size: 14px;
    }

    .range-form {
        display: flex;

        flex-direction: column;

        align-items: stretch;

        padding: 13px;
    }

    .range-form .range-title {
        margin-bottom: 2px;
    }

    .sales-date-filter {
        display: grid;

        grid-template-columns:
            1fr auto 1fr;

        gap: 7px;
    }

    .sales-date-filter .form-control {
        width: 100%;
    }

    .range-form .apply-btn {
        width: 100%;
    }

    .chart-box {
        height: 235px;
    }

    .mini-table {
        font-size: 8px;
    }
}


@media (max-width: 480px) {

    .dashboard-heading-icon {
        width: 40px;
        height: 40px;

        border-radius: 11px;

        font-size: 16px;
    }

    .dashboard-title {
        font-size: 19px;
    }

    .dashboard-actions {
        grid-template-columns: 1fr 1fr;
    }

    .range-form {
        padding: 12px;
    }

    .sales-date-filter {
        display: flex;

        flex-direction: column;

        align-items: stretch;
    }

    .sales-date-filter label {
        margin: 2px 0 -3px;
    }

    .range-summary {
        gap: 7px;
    }
}
```


</style>


<div class="dashboard-page">


    <!-- ========================================================
         HEADER
    ========================================================= -->

    <div class="dashboard-header">

        <div class="dashboard-heading">

            <div class="dashboard-heading-icon">
                <i class="fas fa-chart-pie"></i>
            </div>

            <div>

                <h1 class="dashboard-title">
                    Dashboard
                </h1>

                <div class="dashboard-subtitle">

                    <span class="dashboard-store-name">
                        <?= htmlspecialchars($active_store_name) ?>
                    </span>

                    <span class="mx-1">·</span>

                    Business performance overview

                </div>

            </div>

        </div>


        <div class="dashboard-actions">

            <a href="products"
               class="btn btn-outline-light btn-sm">

                <i class="fas fa-boxes mr-1"></i>
                Products

            </a>


            <a href="reports"
               class="btn btn-outline-light btn-sm">

                <i class="fas fa-chart-bar mr-1"></i>
                Reports

            </a>


            <?php if ($is_admin): ?>

                <a href="stores"
                   class="btn btn-outline-light btn-sm">

                    <i class="fas fa-store mr-1"></i>
                    Manage Stores

                </a>

            <?php endif; ?>

        </div>

    </div>


    <!-- ========================================================
         STORE SWITCHER
    ========================================================= -->

    <?php if (count($all_stores) > 1): ?>

        <div class="store-switcher">

            <div class="store-switcher-header">

                <span class="store-switcher-label">

                    <i class="fas fa-store mr-1"></i>

                    Active Store

                </span>

                <span class="store-switcher-count">

                    <?= count($all_stores) ?> stores available

                </span>

            </div>


            <div class="store-buttons">

                <?php foreach ($all_stores as $s):

                    $is_active =
                        (int)$s['store_id']
                        === $active_store_id;

                ?>

                    <a
                        href="?switch_store=<?= (int)$s['store_id'] ?>"
                        class="store-button <?= $is_active ? 'active' : '' ?>"
                    >

                        <span class="store-status-dot"></span>

                        <?= htmlspecialchars($s['store_name']) ?>

                    </a>

                <?php endforeach; ?>

            </div>

        </div>

    <?php endif; ?>


    <!-- ========================================================
         KPI CARDS
    ========================================================= -->

    <div class="row">


        <!-- TODAY -->

        <div class="col-xl-3 col-md-6 mb-4">

            <div class="dashboard-kpi kpi-accent-success">

                <div class="dashboard-kpi-body">

                    <div class="kpi-top">

                        <div class="kpi-icon">
                            <i class="fas fa-coins"></i>
                        </div>

                        <span class="kpi-trend">
                            Today
                        </span>

                    </div>


                    <div class="kpi-label">
                        Today's Revenue
                    </div>


                    <div class="kpi-value success">

                        ₱<?= number_format(
                            (float)$today_revenue,
                            2
                        ) ?>

                    </div>


                    <div class="kpi-description">

                        <?= number_format(
                            (int)$today_invoices
                        ) ?>

                        invoices today

                    </div>

                </div>

            </div>

        </div>


        <!-- MONTH -->

        <div class="col-xl-3 col-md-6 mb-4">

            <div class="dashboard-kpi kpi-accent-primary">

                <div class="dashboard-kpi-body">

                    <div class="kpi-top">

                        <div class="kpi-icon">
                            <i class="fas fa-calendar-check"></i>
                        </div>

                        <span class="kpi-trend">
                            MTD
                        </span>

                    </div>


                    <div class="kpi-label">
                        Month Revenue
                    </div>


                    <div class="kpi-value">

                        ₱<?= number_format(
                            $month_revenue,
                            2
                        ) ?>

                    </div>


                    <div class="kpi-description">

                        Since
                        <?= date(
                            'M 1',
                            strtotime($month_start)
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <!-- PROFIT -->

        <div class="col-xl-3 col-md-6 mb-4">

            <div class="dashboard-kpi <?= $net_profit_mtd >= 0 ? 'kpi-accent-success' : 'kpi-accent-danger' ?>">

                <div class="dashboard-kpi-body">

                    <div class="kpi-top">

                        <div class="kpi-icon">

                            <i class="fas fa-chart-line"></i>

                        </div>

                        <span class="kpi-trend">
                            MTD
                        </span>

                    </div>


                    <div class="kpi-label">
                        Net Profit
                    </div>


                    <div class="kpi-value <?= $net_profit_mtd >= 0 ? 'success' : 'danger' ?>">

                        ₱<?= number_format(
                            $net_profit_mtd,
                            2
                        ) ?>

                    </div>


                    <div class="kpi-description">

                        After COGS and losses

                    </div>

                </div>

            </div>

        </div>


        <!-- INVENTORY -->

        <div class="col-xl-3 col-md-6 mb-4">

            <div class="dashboard-kpi kpi-accent-danger">

                <div class="dashboard-kpi-body">

                    <div class="kpi-top">

                        <div class="kpi-icon">

                            <i class="fas fa-exclamation-triangle"></i>

                        </div>

                        <span class="kpi-trend">
                            Inventory
                        </span>

                    </div>


                    <div class="kpi-label">
                        Inventory Alerts
                    </div>


                    <div class="kpi-value danger">

                        <?= number_format(
                            $out_of_stock
                        ) ?>

                    </div>


                    <div class="kpi-description">

                        Out of stock ·
                        <?= number_format(
                            $uncategorized
                        ) ?>

                        uncategorized

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ========================================================
         MONTHLY SALES + BREAKDOWN
    ========================================================= -->

    <div class="row">


        <!-- MONTHLY CHART -->

        <div class="col-lg-8 mb-4">

            <div class="dashboard-card">

                <div class="dashboard-card-header">

                    <span>

                        <i class="fas fa-chart-line"></i>

                        Sales This Month

                    </span>

                    <span class="text-muted small">

                        <?= date('F Y') ?>

                    </span>

                </div>


                <div class="dashboard-card-body">

                    <?php if (empty($monthly_sales_rows)): ?>

                        <div class="dashboard-empty">

                            <i class="fas fa-chart-line"></i>

                            No daily sales records found.

                        </div>

                    <?php else: ?>

                        <div class="chart-box">

                            <canvas id="monthlySalesChart"></canvas>

                        </div>


                        <table class="mini-table">

                            <tr>

                                <?php foreach ($monthly_labels as $lbl): ?>

                                    <th>
                                        <?= htmlspecialchars($lbl) ?>
                                    </th>

                                <?php endforeach; ?>

                            </tr>


                            <tr>

                                <?php foreach ($monthly_data as $val): ?>

                                    <td>

                                        ₱<?= number_format(
                                            $val,
                                            0
                                        ) ?>

                                    </td>

                                <?php endforeach; ?>

                            </tr>

                        </table>

                    <?php endif; ?>

                </div>

            </div>

        </div>


        <!-- BREAKDOWN -->

        <div class="col-lg-4 mb-4">

            <div class="dashboard-card">

                <div class="dashboard-card-header">

                    <span>

                        <i class="fas fa-receipt"></i>

                        Month Breakdown

                    </span>

                </div>


                <div class="dashboard-card-body">

                    <ul class="dashboard-list">


                        <li class="dashboard-list-item">

                            <span class="dashboard-list-label">

                                <span
                                    class="dashboard-list-dot"
                                    style="background:#4ade80;"
                                ></span>

                                Revenue

                            </span>

                            <span class="dashboard-list-value success">

                                ₱<?= number_format(
                                    $month_revenue,
                                    2
                                ) ?>

                            </span>

                        </li>


                        <li class="dashboard-list-item">

                            <span class="dashboard-list-label">

                                <span
                                    class="dashboard-list-dot"
                                    style="background:#facc15;"
                                ></span>

                                Spending

                            </span>

                            <span class="dashboard-list-value warning">

                                ₱<?= number_format(
                                    $spending_amount,
                                    2
                                ) ?>

                            </span>

                        </li>


                        <li class="dashboard-list-item">

                            <span class="dashboard-list-label">

                                <span
                                    class="dashboard-list-dot"
                                    style="background:#f87171;"
                                ></span>

                                Loss

                            </span>

                            <span class="dashboard-list-value danger">

                                ₱<?= number_format(
                                    $loss_amount,
                                    2
                                ) ?>

                            </span>

                        </li>


                        <li class="dashboard-list-item">

                            <span class="dashboard-list-label">

                                <span
                                    class="dashboard-list-dot"
                                    style="background:#60a5fa;"
                                ></span>

                                Net Profit

                            </span>

                            <span class="dashboard-list-value <?= $net_profit_mtd >= 0 ? 'success' : 'danger' ?>">

                                ₱<?= number_format(
                                    $net_profit_mtd,
                                    2
                                ) ?>

                            </span>

                        </li>


                    </ul>

                </div>

            </div>

        </div>

    </div>


    <!-- ========================================================
         DATE RANGE ANALYTICS
    ========================================================= -->

    <div class="row">

        <div class="col-12 mb-4">

            <div class="dashboard-card range-card">


                <div class="dashboard-card-header range-header">

                    <div class="range-title">

                        <i class="fas fa-calendar-alt"></i>

                        <span>
                            Sales by Date Range
                        </span>

                    </div>


                    <form method="get" class="range-form"> <?php if ($active_store_id): ?> <input type="hidden" name="switch_store" value="" > <?php endif; ?> <div class="range-title"> <i class="fas fa-calendar-alt"></i> <span>Date Range</span> </div> <div class="sales-date-filter"> <label for="range_from"> From </label> <input type="date" id="range_from" name="from" value="<?= htmlspecialchars($range_from) ?>" class="form-control" max="<?= htmlspecialchars($today) ?>" > <label for="range_to"> To </label> <input type="date" id="range_to" name="to" value="<?= htmlspecialchars($range_to) ?>" class="form-control" max="<?= htmlspecialchars($today) ?>" > </div> <button type="submit" class="btn btn-primary apply-btn" > <i class="fas fa-filter"></i> <span>Apply</span> </button> </form>

                </div>


                <div class="dashboard-card-body">


                    <!-- RANGE SUMMARY -->

                    <div class="range-summary">


                        <div class="range-stat">

                            <span class="range-stat-label">
                                Revenue
                            </span>

                            <span class="range-stat-value success">

                                ₱<?= number_format(
                                    $range_revenue,
                                    2
                                ) ?>

                            </span>

                        </div>


                        <div class="range-stat">

                            <span class="range-stat-label">
                                Transactions
                            </span>

                            <span class="range-stat-value">

                                <?= number_format(
                                    $range_transactions
                                ) ?>

                            </span>

                        </div>


                        <div class="range-stat">

                            <span class="range-stat-label">
                                Spending
                            </span>

                            <span class="range-stat-value warning">

                                ₱<?= number_format(
                                    $range_spending_tot,
                                    2
                                ) ?>

                            </span>

                        </div>


                        <div class="range-stat">

                            <span class="range-stat-label">
                                Net
                            </span>

                            <span class="range-stat-value <?= $range_net >= 0 ? 'success' : 'danger' ?>">

                                ₱<?= number_format(
                                    $range_net,
                                    2
                                ) ?>

                            </span>

                        </div>


                    </div>


                    <!-- RANGE CHART -->

                    <div class="chart-box">

                        <canvas id="rangeSalesChart"></canvas>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ========================================================
         TOP / LOW SELLERS
    ========================================================= -->

    <div class="row">


        <!-- TOP SELLERS -->

        <div class="col-lg-6 mb-4">

            <div class="dashboard-card">

                <div class="dashboard-card-header success">

                    <span>

                        <i class="fas fa-arrow-up"></i>

                        Top Sellers

                    </span>

                    <span class="small text-muted">

                        <?= date(
                            'F',
                            mktime(
                                0,
                                0,
                                0,
                                $this_month,
                                1
                            )
                        ) ?>

                        <?= $this_year ?>

                    </span>

                </div>


                <div class="dashboard-card-body">


                    <?php if ($top_sellers): ?>

                        <ul class="seller-list">

                            <?php

                            $rank = 1;

                            foreach ($top_sellers as $r):

                            ?>

                                <li class="seller-item">


                                    <span class="seller-rank">

                                        <?= $rank ?>

                                    </span>


                                    <span class="seller-name">

                                        <?= htmlspecialchars(
                                            $r['product_name']
                                            ?? '(unnamed)'
                                        ) ?>

                                    </span>


                                    <span class="seller-qty">

                                        <?= number_format(
                                            (int)$r['total_qty_sold']
                                        ) ?>

                                        sold

                                    </span>


                                </li>


                            <?php

                            $rank++;

                            endforeach;

                            ?>

                        </ul>


                    <?php else: ?>

                        <div class="dashboard-empty">

                            <i class="fas fa-box-open"></i>

                            No sales this month yet.

                        </div>

                    <?php endif; ?>


                    <a
                        href="reports.php?view=top&year=<?= $this_year ?>&month=<?= $this_month ?>"
                        class="seller-footer text-success"
                    >

                        View full report
                        <i class="fas fa-arrow-right ml-1"></i>

                    </a>

                </div>

            </div>

        </div>


        <!-- LOW SELLERS -->

        <div class="col-lg-6 mb-4">

            <div class="dashboard-card">

                <div class="dashboard-card-header danger">

                    <span>

                        <i class="fas fa-arrow-down"></i>

                        Needs Attention

                    </span>

                    <span class="small text-muted">
                        Low Sellers
                    </span>

                </div>


                <div class="dashboard-card-body">


                    <?php if ($low_sellers): ?>

                        <ul class="seller-list">

                            <?php

                            $rank = 1;

                            foreach ($low_sellers as $r):

                            ?>

                                <li class="seller-item">


                                    <span class="seller-rank">

                                        <?= $rank ?>

                                    </span>


                                    <span class="seller-name">

                                        <?= htmlspecialchars(
                                            $r['product_name']
                                            ?? '(unnamed)'
                                        ) ?>

                                    </span>


                                    <span class="seller-qty">

                                        <?= number_format(
                                            (int)$r['total_qty_sold']
                                        ) ?>

                                        sold

                                    </span>


                                </li>


                            <?php

                            $rank++;

                            endforeach;

                            ?>

                        </ul>


                    <?php else: ?>

                        <div class="dashboard-empty">

                            <i class="fas fa-check-circle"></i>

                            No low-selling product data yet.

                        </div>

                    <?php endif; ?>


                    <a
                        href="reports.php?view=low&year=<?= $this_year ?>&month=<?= $this_month ?>"
                        class="seller-footer text-danger"
                    >

                        View full report
                        <i class="fas fa-arrow-right ml-1"></i>

                    </a>

                </div>

            </div>

        </div>

    </div>


</div>


<!-- ============================================================
     CHART.JS
============================================================ -->

<script src="assets/js/chart.umd.min.js"></script>

<script>

(function () {


    const monthlyLabels =
        <?= json_encode($monthly_labels) ?>;

    const monthlyData =
        <?= json_encode($monthly_data) ?>;


    const rangeLabels =
        <?= json_encode($range_labels) ?>;

    const rangeData =
        <?= json_encode($range_data) ?>;


    /* ---------------------------------------------------------
       Global chart defaults
    --------------------------------------------------------- */

    Chart.defaults.font.family =
        'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';

    Chart.defaults.font.size = 10;

    Chart.defaults.color =
        '#64748b';


    /* ---------------------------------------------------------
       Common chart options
    --------------------------------------------------------- */

    const chartDefaults = {

        type: 'line',

        options: {

            responsive: true,

            maintainAspectRatio: false,

            interaction: {

                intersect: false,

                mode: 'index'

            },

            plugins: {

                legend: {
                    display: false
                },

                tooltip: {

                    backgroundColor:
                        'rgba(15,23,42,.96)',

                    borderColor:
                        'rgba(255,255,255,.08)',

                    borderWidth: 1,

                    padding: 10,

                    titleColor:
                        '#f8fafc',

                    bodyColor:
                        '#cbd5e1',

                    displayColors: false,

                    callbacks: {

                        label: function(context) {

                            return ' ₱' +
                                Number(
                                    context.parsed.y || 0
                                ).toLocaleString(
                                    'en-PH',
                                    {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2
                                    }
                                );

                        }

                    }

                }

            },


            scales: {

                x: {

                    grid: {

                        color:
                            'rgba(255,255,255,.035)',

                        drawBorder: false

                    },

                    ticks: {

                        color:
                            '#64748b',

                        maxRotation: 0,

                        autoSkip: true,

                        maxTicksLimit: 12

                    }

                },


                y: {

                    beginAtZero: true,

                    grid: {

                        color:
                            'rgba(255,255,255,.035)',

                        drawBorder: false

                    },

                    ticks: {

                        color:
                            '#64748b',

                        padding: 8,

                        callback: function(value) {

                            return '₱' +
                                Number(value)
                                .toLocaleString();

                        }

                    }

                }

            }


        }

    };


    /* ---------------------------------------------------------
       Initialize chart
    --------------------------------------------------------- */

    function initChart(
        id,
        labels,
        data,
        color,
        background
    ) {

        const canvas =
            document.getElementById(id);

        if (!canvas) {
            return;
        }


        new Chart(
            canvas,
            {

                ...chartDefaults,

                data: {

                    labels: labels,

                    datasets: [

                        {

                            label:
                                'Net Revenue',

                            data: data,

                            borderColor:
                                color,

                            backgroundColor:
                                background,

                            fill: true,

                            tension: .35,

                            borderWidth: 2,

                            pointRadius: 2.5,

                            pointHoverRadius: 5,

                            pointBackgroundColor:
                                color,

                            pointBorderWidth: 0

                        }

                    ]

                }

            }
        );

    }


    /* ---------------------------------------------------------
       Render
    --------------------------------------------------------- */

    setTimeout(function () {

        initChart(
            'monthlySalesChart',
            monthlyLabels,
            monthlyData,
            '#4ade80',
            'rgba(74,222,128,.10)'
        );


        initChart(
            'rangeSalesChart',
            rangeLabels,
            rangeData,
            '#60a5fa',
            'rgba(96,165,250,.10)'
        );

    }, 50);


})();

</script>


<?php require __DIR__ . '/includes/footer_bootstrap.php'; ?>